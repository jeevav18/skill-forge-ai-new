import express, { Request, Response, NextFunction } from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialized Gemini Client
let aiInstance: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== "MY_GEMINI_API_KEY" && apiKey !== "") {
      aiInstance = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
  }
  return aiInstance;
}

// Global Mock Database
const FREELANCERS = [
  {
    id: "f-1",
    name: "Aravind Nair",
    title: "Lead Salesforce Technical Architect",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
    location: "Bangalore, India",
    experience: "12 Years",
    hourlyRate: 85,
    expectedSalary: "₹3,500,000/yr",
    rating: 4.9,
    reviewsCount: 42,
    availability: "Available (30 hrs/wk)",
    skills: ["Salesforce Architect", "Apex Programming", "LWC", "Aura Components", "MuleSoft", "Agentforce", "Copado"],
    certifications: ["Salesforce Certified Technical Architect (CTA)", "Platform Developer II", "Data Cloud Consultant"],
    bio: "Ex-Salesforce CTA. Specializes in multi-cloud architecture, complex MuleSoft integrations, and implementing Agentforce AI agents for enterprise Service Clouds.",
    socials: { github: "github.com/aravind-sf", linkedin: "linkedin.com/in/aravindsf" }
  },
  {
    id: "f-2",
    name: "Priya Sharma",
    title: "Senior Full-Stack React & Node.js Developer",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
    location: "Mumbai, India",
    experience: "6 Years",
    hourlyRate: 50,
    expectedSalary: "₹1,800,000/yr",
    rating: 4.8,
    reviewsCount: 29,
    availability: "Available Immediately",
    skills: ["React", "Next.js", "TypeScript", "Node.js", "Express.js", "Tailwind CSS", "PostgreSQL", "GraphQL"],
    certifications: ["AWS Certified Developer", "Meta Frontend Specialist"],
    bio: "Passionate about building fast, highly responsive React/Next.js single page applications with gorgeous Tailwind interfaces. Skilled in real-time WebSockets and secure API design.",
    socials: { github: "github.com/priyadev", linkedin: "linkedin.com/in/priya-sharma" }
  },
  {
    id: "f-3",
    name: "Marcus Vance",
    title: "AI Engineering & LLM Specialist",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150",
    location: "San Francisco, USA",
    experience: "5 Years",
    hourlyRate: 110,
    expectedSalary: "$165,000/yr",
    rating: 5.0,
    reviewsCount: 18,
    availability: "Part-time (20 hrs/wk)",
    skills: ["Python", "Generative AI", "LLMs", "RAG", "LangChain", "LlamaIndex", "FastAPI", "Vector Databases"],
    certifications: ["Google Cloud Professional Machine Learning Engineer"],
    bio: "Specialist in building semantic search, RAG pipelines, and conversational AI agents. Expert in fine-tuning models and building production-ready GenAI backends.",
    socials: { github: "github.com/marcus-ai", linkedin: "linkedin.com/in/marcusvance" }
  },
  {
    id: "f-4",
    name: "Sarah Lindqvist",
    title: "Salesforce Business Analyst & Flow Expert",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
    location: "Munich, Germany",
    experience: "8 Years",
    hourlyRate: 75,
    expectedSalary: "€95,000/yr",
    rating: 4.7,
    reviewsCount: 31,
    availability: "Available (40 hrs/wk)",
    skills: ["Salesforce Admin", "Flow Builder", "Business Analysis", "Sales Cloud", "Service Cloud", "OmniStudio"],
    certifications: ["Salesforce Certified Administrator", "Advanced Administrator", "Business Analyst"],
    bio: "Translates complex business needs into streamlined Salesforce processes. Expert in Flow Builder, validation rules, and Experience Cloud client portals.",
    socials: { github: "github.com/sarahflow", linkedin: "linkedin.com/in/sarah-lindqvist" }
  },
  {
    id: "f-5",
    name: "Devon Chen",
    title: "Senior Web3 & Smart Contract Developer",
    avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150",
    location: "Singapore",
    experience: "7 Years",
    hourlyRate: 95,
    expectedSalary: "$140,000/yr",
    rating: 4.9,
    reviewsCount: 22,
    availability: "Available for Projects",
    skills: ["Blockchain", "Ethereum", "Solidity", "Rust", "Smart Contracts", "Web3 Applications", "DeFi"],
    certifications: ["Certified Solidity Developer"],
    bio: "Decentralized application architect. Audits and writes secure, gas-optimized Solidity and Rust smart contracts for top-tier DeFi and NFT projects.",
    socials: { github: "github.com/devonweb3", linkedin: "linkedin.com/in/devonchen" }
  },
  {
    id: "f-6",
    name: "Elena Rostova",
    title: "DevOps & Kubernetes Platform Engineer",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150",
    location: "Prague, Czech Republic",
    experience: "9 Years",
    hourlyRate: 80,
    expectedSalary: "€85,000/yr",
    rating: 4.9,
    reviewsCount: 37,
    availability: "Available (25 hrs/wk)",
    skills: ["Docker", "Kubernetes", "Terraform", "GitHub Actions", "Nginx", "Prometheus", "Grafana", "AWS"],
    certifications: ["Certified Kubernetes Administrator (CKA)", "AWS SysOps Administrator"],
    bio: "Builds highly resilient cloud infrastructure and CI/CD pipelines. Expert in infrastructure-as-code, automatic scaling, and monitoring metrics.",
    socials: { github: "github.com/elenacloud", linkedin: "linkedin.com/in/elena-rostova" }
  },
  {
    id: "f-7",
    name: "Rajesh Kumar",
    title: "HubSpot CRM Architect & Integration Specialist",
    avatar: "https://images.unsplash.com/photo-1542909168-82c3e7fdca5c?w=150",
    location: "Chennai, India",
    experience: "5 Years",
    hourlyRate: 45,
    expectedSalary: "₹1,400,000/yr",
    rating: 4.6,
    reviewsCount: 15,
    availability: "Available Immediately",
    skills: ["HubSpot CRM", "API Integration", "Marketing Hub", "Sales Hub", "Zapier", "Workflow Automation"],
    certifications: ["HubSpot CRM Certified Trainer", "HubSpot Sales Software"],
    bio: "Streamlining marketing and sales funnels. Specializes in building advanced custom integrations between HubSpot, custom webhooks, and third-party databases.",
    socials: { github: "github.com/rajeshhub", linkedin: "linkedin.com/in/rajesh-kumar-hub" }
  },
  {
    id: "f-8",
    name: "Carlos Gomez",
    title: "Microsoft Dynamics 365 & Power Platform Consultant",
    avatar: "https://images.unsplash.com/photo-1556157382-97eda2d62296?w=150",
    location: "Madrid, Spain",
    experience: "8 Years",
    hourlyRate: 70,
    expectedSalary: "€78,000/yr",
    rating: 4.8,
    reviewsCount: 26,
    availability: "Available (30 hrs/wk)",
    skills: ["Microsoft Dynamics 365", "Power Platform", "Power Apps", "Power Automate", "Dynamics Sales", "CRM Setup"],
    certifications: ["Microsoft Certified: Power Platform App Maker", "Dynamics 365 Sales Functional Consultant"],
    bio: "Empowers enterprise businesses by deploying custom model-driven Power Apps, building complex automate flows, and configuring modular Dynamics 365 Sales pipelines.",
    socials: { github: "github.com/carlospower", linkedin: "linkedin.com/in/carlos-gomez-dynamics" }
  }
];

const JOBS = [
  {
    id: "j-1",
    title: "Enterprise Salesforce Revenue Cloud (CPQ) Consultant",
    company: "CloudScale Solutions",
    location: "Remote (India / Europe)",
    type: "Contract (6 Months)",
    rate: "$75 - $90 / hr",
    budget: "$25,000+",
    skills: ["Salesforce Architect", "Revenue Cloud", "CPQ", "Flow Builder", "REST API"],
    description: "Looking for an expert consultant to overhaul our current pricing logic and implement Salesforce CPQ/Revenue Cloud. Must have proven experience with bundle configuration, pricing matrices, and experience with custom REST integrations.",
    proposals: 14,
    postedAt: "2 days ago"
  },
  {
    id: "j-2",
    title: "Next.js 15 & Tailwind Frontend Developer for AI Platform",
    company: "BioGen AI Corp",
    location: "Remote (Worldwide)",
    type: "Freelance (Fixed Price)",
    rate: "Fixed Price",
    budget: "$8,500",
    skills: ["React", "Next.js", "TypeScript", "Tailwind CSS", "motion"],
    description: "We are building an intuitive portal for genomic sequence visualization. Need a designer-developer hybrid who can build exceptionally clean, interactive layouts with Framer Motion, and optimize page load performance.",
    proposals: 32,
    postedAt: "1 day ago"
  },
  {
    id: "j-3",
    title: "MuleSoft Integration Specialist (Salesforce to SAP)",
    company: "ApexDigital Logistics",
    location: "Remote (Singapore/Bangalore)",
    type: "Contract (3 Months)",
    rate: "$65 - $80 / hr",
    budget: "$15,000",
    skills: ["MuleSoft", "Salesforce Integration", "SAP CRM", "REST API", "SOAP API"],
    description: "Urgent contract role to link our active Salesforce Sales Cloud pipeline with SAP CRM back-office ERP via MuleSoft. Requires knowledge of AnyPoint Studio, custom dataweave transforms, and secure client-credentials auth.",
    proposals: 9,
    postedAt: "5 hours ago"
  },
  {
    id: "j-4",
    title: "Agentforce AI Implementation & RAG Pipeline Setup",
    company: "FinTech Prime",
    location: "Remote (US/Canada)",
    type: "Freelance / Part-time",
    rate: "$95 - $120 / hr",
    budget: "$18,000",
    skills: ["Generative AI", "Agentforce", "Einstein AI", "Python", "RAG", "Data Cloud"],
    description: "Deploy an intelligent customer support chatbot using Salesforce Agentforce, backed by a custom Python-based RAG pipeline on AWS. Candidate must understand Prompt Builder, Co-Pilot configurations, and vector embeddings.",
    proposals: 21,
    postedAt: "Just now"
  },
  {
    id: "j-5",
    title: "HubSpot Custom CRM Setup & Marketing Automation",
    company: "GrowthLab Agency",
    location: "Remote (Europe)",
    type: "Freelance",
    rate: "$40 - $50 / hr",
    budget: "$4,000",
    skills: ["HubSpot CRM", "Marketing Hub", "Zapier", "Workflow Automation"],
    description: "Configure custom objects, lifecycle stages, deal pipelines, and advanced email nurturing campaigns for an active SaaS enterprise. Require expert setup and Zapier trigger sync with Stripe.",
    proposals: 17,
    postedAt: "3 days ago"
  }
];

const COMPANIES = [
  { name: "CloudScale Solutions", logo: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=120&auto=format&fit=crop&q=60", domain: "CRM Consulting", size: "150-500 employees", rating: 4.8 },
  { name: "BioGen AI Corp", logo: "https://images.unsplash.com/photo-1530026405186-ed1ea0ac7a63?w=120&auto=format&fit=crop&q=60", domain: "Health Tech & AI", size: "50-100 employees", rating: 4.9 },
  { name: "ApexDigital Logistics", logo: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=120&auto=format&fit=crop&q=60", domain: "Global Shipping & ERP", size: "1000+ employees", rating: 4.5 },
  { name: "FinTech Prime", logo: "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=120&auto=format&fit=crop&q=60", domain: "Financial Services", size: "200-500 employees", rating: 4.7 },
  { name: "GrowthLab Agency", logo: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=120&auto=format&fit=crop&q=60", domain: "Marketing & SaaS", size: "10-50 employees", rating: 4.6 }
];

// 1. Natural Language Talent Search API Route
app.post("/api/natural-search", async (req: Request, res: Response): Promise<void> => {
  const { query } = req.body;
  if (!query) {
    res.status(400).json({ error: "Search query is required" });
    return;
  }

  const ai = getGeminiClient();

  if (!ai) {
    // Elegant Offline Mock Matcher
    const lowerQuery = query.toLowerCase();
    const matched = FREELANCERS.map((f) => {
      let score = 50;
      const matchingSkills: string[] = [];
      
      f.skills.forEach((skill) => {
        if (lowerQuery.includes(skill.toLowerCase())) {
          score += 15;
          matchingSkills.push(skill);
        }
      });

      if (lowerQuery.includes("salesforce") && f.title.toLowerCase().includes("salesforce")) {
        score += 20;
      }
      if (lowerQuery.includes("react") && f.skills.includes("React")) {
        score += 20;
      }
      if (lowerQuery.includes("architect") && f.title.toLowerCase().includes("architect")) {
        score += 15;
      }
      if (lowerQuery.includes("india") && f.location.toLowerCase().includes("india")) {
        score += 20;
      }

      // Add a bit of randomness for variation
      score = Math.min(Math.max(score + Math.floor(Math.random() * 10), 10), 99);

      return {
        ...f,
        matchingScore: score,
        matchedSkills: matchingSkills
      };
    })
    .sort((a, b) => b.matchingScore - a.matchingScore);

    res.json({
      query,
      results: matched,
      analysis: `Parsed query offline. Identified skills in request. Found ${matched.filter(m => m.matchingScore > 60).length} strong developer profiles.`,
      suggestedSalary: lowerQuery.includes("salesforce") ? "₹2,500,000 - ₹4,500,000" : lowerQuery.includes("react") ? "₹1,200,000 - ₹2,200,000" : "$90,000 - $140,000",
      offlineMode: true
    });
    return;
  }

  try {
    // Generate actual response using Gemini
    const systemPrompt = `You are an expert recruitment system parsing natural language queries and matching profiles from this database:
    ${JSON.stringify(FREELANCERS, null, 2)}
    
    Given the user's query, return a JSON object with:
    - results: array of objects containing the matched 'id' from the database and a 'matchingScore' (0-100) and 'matchReason' (short sentence explaining why).
    - suggestedSalary: predicted salary range for this query based on market trends (string).
    - analysis: A brief paragraph analyzing the search parameters (experience, skills, geographical filters if any).
    
    Return STRICT, raw JSON matching this schema:
    {
      "results": [{"id": "string", "matchingScore": number, "matchReason": "string"}],
      "suggestedSalary": "string",
      "analysis": "string"
    }`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: query,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    const mergedResults = (parsed.results || []).map((match: any) => {
      const original = FREELANCERS.find((f) => f.id === match.id) || FREELANCERS[0];
      return {
        ...original,
        matchingScore: match.matchingScore || 70,
        matchReason: match.matchReason || "Matches general technical indicators."
      };
    }).sort((a: any, b: any) => b.matchingScore - a.matchingScore);

    res.json({
      query,
      results: mergedResults,
      analysis: parsed.analysis || "Real-time AI matching successfully executed.",
      suggestedSalary: parsed.suggestedSalary || "$85,000 - $130,000",
      offlineMode: false
    });
  } catch (error: any) {
    console.error("Gemini Search Error:", error);
    res.status(500).json({ error: "Failed to perform AI matching search.", details: error.message });
  }
});

// 2. AI Resume Parser / Builder API Route
app.post("/api/analyze-resume", async (req: Request, res: Response): Promise<void> => {
  const { resumeText } = req.body;
  if (!resumeText) {
    res.status(400).json({ error: "Resume text is required" });
    return;
  }

  const ai = getGeminiClient();

  if (!ai) {
    // Mock Response
    res.json({
      parsedName: "Alex Mercer",
      parsedTitle: "Salesforce CRM & React Developer",
      skills: ["Salesforce Admin", "Apex Programming", "LWC", "React", "TypeScript", "Tailwind CSS"],
      certifications: ["Salesforce Certified Administrator", "Salesforce Platform Developer I"],
      experienceSummary: "5+ years streamlining enterprise operations and building modular Web applications.",
      skillGaps: [
        { skill: "MuleSoft Integrations", criticality: "High", advice: "Essential for linking Salesforce and legacy APIs." },
        { skill: "Agentforce / Einstein AI", criticality: "Medium", advice: "High industry demand for AI Agents in Customer Portals." }
      ],
      learningRoadmap: [
        { phase: "Phase 1: Advanced Integration", steps: ["Learn MuleSoft AnyPoint Essentials", "Obtain Integration Architect Cert"] },
        { phase: "Phase 2: Agentforce & AI Tools", steps: ["Complete Trailhead for Agentforce", "Deploy a pilot Agent in developer org"] }
      ],
      careerPath: "CRM Solution Architect / AI Specialist",
      offlineMode: true
    });
    return;
  }

  try {
    const systemPrompt = `You are an AI Career Advisor & Resume Parser. Parse the provided resume or profile and return a detailed JSON assessment.
    Provide:
    - parsedName: Extracted name (string, fallback to "Alex Mercer")
    - parsedTitle: Extracted professional title (string)
    - skills: List of identified technologies/skills (array of strings)
    - certifications: List of certifications found or implied (array of strings)
    - experienceSummary: Brief summary of career history (string)
    - skillGaps: Array of objects with 'skill', 'criticality' (High/Medium/Low), and 'advice' (string)
    - learningRoadmap: Array of objects with 'phase' (string) and 'steps' (array of strings)
    - careerPath: Recommended target career title (string)

    Return STRICT, raw JSON following this schema. Do not include markdown wraps or code fences in the output:
    {
      "parsedName": "string",
      "parsedTitle": "string",
      "skills": ["string"],
      "certifications": ["string"],
      "experienceSummary": "string",
      "skillGaps": [{"skill": "string", "criticality": "string", "advice": "string"}],
      "learningRoadmap": [{"phase": "string", "steps": ["string"]}],
      "careerPath": "string"
    }`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: resumeText,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
      }
    });

    res.json(JSON.parse(response.text || "{}"));
  } catch (error: any) {
    console.error("Resume Parser Error:", error);
    res.status(500).json({ error: "Failed to parse resume.", details: error.message });
  }
});

// 3. AI Interview Coach & Coding Assistant API Route
app.post("/api/interview-coach", async (req: Request, res: Response): Promise<void> => {
  const { domain, history, currentAnswer } = req.body;
  if (!domain) {
    res.status(400).json({ error: "Interview domain is required" });
    return;
  }

  const ai = getGeminiClient();

  if (!ai) {
    // Mock response
    res.json({
      feedback: "Your explanation of the Salesforce LWC Lifecycle hooks is decent, but make sure to explicitly state that the connectedCallback is where you should trigger server-side Apex calls, while the constructor is too early because attributes are not bound yet.",
      rating: "8/10",
      nextQuestion: "Can you explain how state transitions are managed dynamically using lightning-message-service when communicating across multiple sibling components?",
      offlineMode: true
    });
    return;
  }

  try {
    const systemPrompt = `You are a Senior Technical Interviewer in ${domain}. 
    Analyze the conversation history and the candidate's last answer. Provide:
    - feedback: Critique of their answer, highlighting what was good and what was missing or technically inaccurate (detailed string).
    - rating: A score (e.g., '8/10' or '6/10')
    - nextQuestion: A challenging, sequential follow-up question related to ${domain} to keep the mock interview moving.

    Return STRICT, raw JSON following this schema:
    {
      "feedback": "string",
      "rating": "string",
      "nextQuestion": "string"
    }`;

    const contents = `History: ${JSON.stringify(history)}\n\nLatest Candidate Answer: ${currentAnswer || "Started interview."}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
      }
    });

    res.json(JSON.parse(response.text || "{}"));
  } catch (error: any) {
    console.error("Interview Coach Error:", error);
    res.status(500).json({ error: "Failed to run mock interview coach.", details: error.message });
  }
});

// 4. Proposal / Contract Generator Route
app.post("/api/generate-proposal", async (req: Request, res: Response): Promise<void> => {
  const { projectDetails, freelancerBio, type } = req.body;
  if (!projectDetails) {
    res.status(400).json({ error: "Project details are required." });
    return;
  }

  const ai = getGeminiClient();

  if (!ai) {
    res.json({
      proposal: `Dear Team,\n\nI am thrilled to submit my proposal for: "${projectDetails.substring(0, 50)}...". As a seasoned consultant with expertise in ${freelancerBio || "CRM architecture and Frontend integrations"}, I possess the skills to complete this project with absolute precision.\n\n### Scope of Work\n1. Phase 1: Requirements Mapping & Setup\n2. Phase 2: Implementation & QA Tests\n3. Phase 3: Deployment & Handover\n\n### Budget & Timeline\n- Hourly Rate: $85/hr\n- Total Estimated Time: 4-6 weeks\n\nI look forward to discussing how we can collaborate.\n\nSincerely,\nProfessional Consultant`,
      offlineMode: true
    });
    return;
  }

  try {
    const isContract = type === "contract";
    const systemPrompt = isContract 
      ? `You are an AI Contract Drafter. Draft a legally protective, professional freelance contract covering clauses like Independent Contractor Status, Intellectual Property rights, Payment terms, Confidentiality, and Termination.`
      : `You are an expert AI proposal writer. Draft a compelling, highly customized freelance proposal responding to the project requirements. Include cover letter, scope outline, milestones, and estimated hours.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Project Context: ${projectDetails}\nFreelancer Bio/Specialty: ${freelancerBio || "N/A"}`
    });

    res.json({
      proposal: response.text || "Draft generated.",
      offlineMode: false
    });
  } catch (error: any) {
    console.error("Generator Error:", error);
    res.status(500).json({ error: "Failed to generate draft.", details: error.message });
  }
});

// 5. General AI Chat assistant route
app.post("/api/ai-chat", async (req: Request, res: Response): Promise<void> => {
  const { message, history } = req.body;
  if (!message) {
    res.status(400).json({ error: "Message is required." });
    return;
  }

  const ai = getGeminiClient();

  if (!ai) {
    res.json({
      reply: `I am your FreelanceX AI assistant running in offline demo mode. I can assist you with CRM platforms like Salesforce (including Sales/Service clouds, MuleSoft, Lightning Web Components), Web3, AI matching, or general career goals. How can I help you succeed today?`,
      offlineMode: true
    });
    return;
  }

  try {
    const systemPrompt = `You are 'FreelanceX AI Chatbot', an expert virtual advisor on the FreelanceX.ai (SkillForge) platform.
    Help users understand technology careers, CRM architecture (Salesforce LWC, Experience Cloud, MuleSoft, Agentforce), freelancing strategies, or how to use our platform features.
    Keep answers concise, actionable, and formatted nicely in markdown. Mention our built-in AI tools (Resume Parser, Interview Coach, Talent Search) when relevant.`;

    const chat = ai.chats.create({
      model: "gemini-3.5-flash",
      config: {
        systemInstruction: systemPrompt,
      },
      history: (history || []).map((h: any) => ({
        role: h.role,
        parts: [{ text: h.content }]
      }))
    });

    const response = await chat.sendMessage({ message });
    res.json({
      reply: response.text || "I apologize, I am processing too many requests.",
      offlineMode: false
    });
  } catch (error: any) {
    console.error("Chat Error:", error);
    res.status(500).json({ error: "Failed to communicate with AI Chatbot.", details: error.message });
  }
});

// 6. Direct Support & Inquiry Routing API Route
app.post("/api/contact", (req: Request, res: Response) => {
  const { name, email, subject, message } = req.body;
  
  console.log(`[INBOX ROUTING SYSTEM] Forwarding client query to: gopiiniyavan@gmail.com`);
  console.log(`[MESSAGE ENVELOPE] From: ${name || "Anonymous Client"} <${email || "no-reply@skillforge.com"}>`);
  console.log(`[SUBJECT] ${subject || "General Platform Query"}`);
  console.log(`[CONTENT] ${message || "(No message body provided)"}`);
  
  res.json({
    success: true,
    status: "success",
    message: "Query successfully routed to gopiiniyavan@gmail.com",
    timestamp: new Date().toISOString(),
    recipient: "gopiiniyavan@gmail.com"
  });
});

// Serve UI Data
app.get("/api/platform-data", (req: Request, res: Response) => {
  res.json({
    freelancers: FREELANCERS,
    jobs: JOBS,
    companies: COMPANIES
  });
});

// Setup Vite Dev Middleware / Static Build serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`FreelanceX Server running on http://localhost:${PORT}`);
  });
}

startServer();
