import React, { useState, useEffect } from "react";
import { 
  Compass, Sparkles, LayoutDashboard, Info, DollarSign, Bell, Star, MapPin, 
  Mail, MessageSquare, ShieldCheck, Award, Github, Linkedin, ExternalLink, 
  Menu, X, Laptop, Bot, Shield, Loader2, Sparkle, Globe, Calendar, ArrowUpRight,
  KeyRound, Lock, CreditCard, Smartphone, Zap, Eye, EyeOff, Briefcase, HelpCircle, Search
} from "lucide-react";
import { Freelancer, Job, Company, ViewMode } from "./types";
import ExploreTab from "./components/ExploreTab";
import AIWorkspaceTab from "./components/AIWorkspaceTab";
import DashboardsTab from "./components/DashboardsTab";
import AIChatDrawer from "./components/AIChatDrawer";

export default function App() {
  const [viewMode, setViewMode] = useState<ViewMode>("explore");
  const [activeWorkspaceTool, setActiveWorkspaceTool] = useState<any>("search");
  const [activeDashboardTab, setActiveDashboardTab] = useState<any>("freelancer");
  const [activeAcademyDomain, setActiveAcademyDomain] = useState<"ai" | "webdev" | "crm" | "emerging">("ai");
  const [selectedDomain, setSelectedDomain] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [isDashboardLoggedIn, setIsDashboardLoggedIn] = useState(false);

  // Secure Portal Gateway Credentials & States
  const [loginEmail, setLoginEmail] = useState("gopiiniyavan@gmail.com");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginOtp, setLoginOtp] = useState("");
  const [generatedOtp, setGeneratedOtp] = useState("");
  const [loginStep, setLoginStep] = useState(0); // 0 = Password Gate, 1 = OTP Gate
  const [loginError, setLoginError] = useState("");
  const [loginSuccessMessage, setLoginSuccessMessage] = useState("");
  const [loginLoading, setLoginLoading] = useState(false);
  
  // New Enhanced Security & Authentication States
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [isLocked, setIsLocked] = useState(false);
  const [isOnlineSimulated, setIsOnlineSimulated] = useState(true);
  const [googleOneTapOpen, setGoogleOneTapOpen] = useState(false);

  // New Interactive Authentication states for multi-step recovery
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [recoveryEmail, setRecoveryEmail] = useState("gopiiniyavan@gmail.com");
  const [recoveryStep, setRecoveryStep] = useState(0); // 0 = Enter contact, 1 = OTP validation, 2 = New Password, 3 = Success
  const [recoveryType, setRecoveryType] = useState<"email" | "mobile">("email");
  const [recoveryOtpCode, setRecoveryOtpCode] = useState("");
  const [recoveryOtpInput, setRecoveryOtpInput] = useState("");
  const [recoveryEmailTokenCode, setRecoveryEmailTokenCode] = useState("");
  const [recoveryEmailTokenInput, setRecoveryEmailTokenInput] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showRecoveryPassword, setShowRecoveryPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [otpDigits, setOtpDigits] = useState<string[]>(["", "", "", "", "", ""]);
  const [emailDigits, setEmailDigits] = useState<string[]>(["", "", "", "", "", ""]);
  const [resendCountdown, setResendCountdown] = useState(30);
  const [failedVerificationAttempts, setFailedVerificationAttempts] = useState(0);
  const [isCodeExpired, setIsCodeExpired] = useState(false);
  const [recoverySuccess, setRecoverySuccess] = useState(false);
  const [recoveryLoading, setRecoveryLoading] = useState(false);
  const [customPasswordList, setCustomPasswordList] = useState<{[key: string]: string}>({
    "gopiiniyavan@gmail.com": "123456", // Default mock password
    "9876543210": "123456" // Default mock mobile
  });

  // New Interactive Notifications states
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notificationLog, setNotificationLog] = useState([
    { id: "notif-1", title: "Direct Commission Waiver active", message: "100% of recruitment pipelines and secure escrows are free of charges. Sponsored by JEEVA V.", type: "system", isNew: true, date: "Just now" },
    { id: "notif-2", title: "Indian UPI Escrow Gateways enabled", message: "Razorpay and UPI AutoPay direct routing is configured for INR/USD dual currency.", type: "payment", isNew: true, date: "5 mins ago" },
    { id: "notif-3", title: "MNC Fast-Track Recruitment Drive", message: "Google Cloud and Salesforce CRM direct-hire pipelines are currently accepting applicants.", type: "placement", isNew: false, date: "1 hour ago" },
    { id: "notif-4", title: "Global Escrow Dispatcher status", message: "Multi-sig smart contract ledger is 100% synchronized and secure.", type: "security", isNew: false, date: "2 hours ago" }
  ]);

  // New Interactive UPI Escrow Payment states
  const [upiModalOpen, setUpiModalOpen] = useState(false);
  const [selectedPaymentGateway, setSelectedPaymentGateway] = useState("UPI AutoPay");
  const [upiVpa, setUpiVpa] = useState("gopiiniyavan@okaxis");
  const [upiAmount, setUpiAmount] = useState("12500");
  const [upiProvider, setUpiProvider] = useState("gpay");
  const [cardNumber, setCardNumber] = useState("4111 2222 3333 4444");
  const [cardExpiry, setCardExpiry] = useState("12/29");
  const [cardCvv, setCardCvv] = useState("321");
  const [cardName, setCardName] = useState("JEEVA V");
  const [stripeEmail, setStripeEmail] = useState("gopiiniyavan@gmail.com");
  const [paypalEmail, setPaypalEmail] = useState("gopiiniyavan@gmail.com");
  const [upiState, setUpiState] = useState<"idle" | "generating" | "qr_ready" | "verifying" | "success">("idle");
  const [escrowLedger, setEscrowLedger] = useState<any[]>([
    { id: "tx-1", desc: "MNC Google Cloud Escrow Hold", amount: "₹1,85,000", status: "Active Hold", date: "July 18, 2026" },
    { id: "tx-2", desc: "Freelance CPQ Integration Contract", amount: "₹62,250", status: "Released", date: "July 15, 2026" }
  ]);

  const getMaskedEmail = (email: string) => {
    if (!email || !email.includes("@")) return "j*****@gmail.com";
    const [local, domain] = email.split("@");
    const firstChar = local[0] || "j";
    return `${firstChar}*****@${domain}`;
  };

  const getMaskedPhone = () => {
    return "******7890";
  };

  useEffect(() => {
    let interval: any = null;
    if (showForgotPassword && recoveryStep === 2 && resendCountdown > 0) {
      interval = setInterval(() => {
        setResendCountdown((prev) => prev - 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [showForgotPassword, recoveryStep, resendCountdown]);

  const handleDigitChange = (value: string, index: number, type: "otp" | "email") => {
    const cleaned = value.replace(/[^\d]/g, "");
    if (!cleaned && value !== "") return;
    
    const lastChar = cleaned.substring(cleaned.length - 1);
    
    if (type === "otp") {
      const updated = [...otpDigits];
      updated[index] = lastChar;
      setOtpDigits(updated);
      if (lastChar && index < 5) {
        setTimeout(() => {
          document.getElementById(`otp-${index + 1}`)?.focus();
        }, 10);
      }
    } else {
      const updated = [...emailDigits];
      updated[index] = lastChar;
      setEmailDigits(updated);
      if (lastChar && index < 5) {
        setTimeout(() => {
          document.getElementById(`email-reset-${index + 1}`)?.focus();
        }, 10);
      }
    }
  };

  const handleDigitKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number, type: "otp" | "email") => {
    if (e.key === "Backspace") {
      if (type === "otp") {
        if (!otpDigits[index] && index > 0) {
          const updated = [...otpDigits];
          updated[index - 1] = "";
          setOtpDigits(updated);
          setTimeout(() => {
            document.getElementById(`otp-${index - 1}`)?.focus();
          }, 10);
        } else {
          const updated = [...otpDigits];
          updated[index] = "";
          setOtpDigits(updated);
        }
      } else {
        if (!emailDigits[index] && index > 0) {
          const updated = [...emailDigits];
          updated[index - 1] = "";
          setEmailDigits(updated);
          setTimeout(() => {
            document.getElementById(`email-reset-${index - 1}`)?.focus();
          }, 10);
        } else {
          const updated = [...emailDigits];
          updated[index] = "";
          setEmailDigits(updated);
        }
      }
    }
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    setLoginSuccessMessage("");

    // Lock check
    if (isLocked) {
      setLoginError("Your account is temporarily locked due to multiple failed login attempts.");
      return;
    }

    // 1. Validation: Email/Mobile required
    if (!loginEmail || !loginEmail.trim()) {
      setLoginError("Please enter your email address or mobile number.");
      return;
    }

    const emailVal = loginEmail.trim();
    const isEmail = emailVal.includes("@");
    if (isEmail) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(emailVal)) {
        setLoginError("Please enter a valid email address.");
        return;
      }
    } else {
      const cleanedMobile = emailVal.replace(/[^\d+]/g, "");
      const mobileRegex = /^\+?\d{7,15}$/;
      if (!mobileRegex.test(cleanedMobile)) {
        setLoginError("Please enter a valid mobile number.");
        return;
      }
    }

    // 2. Validation: Password required
    if (!loginPassword) {
      setLoginError("Please enter your password.");
      return;
    }

    setLoginLoading(true);

    setTimeout(() => {
      setLoginLoading(false);

      const userKey = emailVal.toLowerCase();
      const accountExists = 
        userKey === "gopiiniyavan@gmail.com" || 
        userKey === "9876543210" || 
        customPasswordList[userKey] !== undefined;

      if (!accountExists) {
        setLoginError("No account found with the provided email or mobile number.");
        return;
      }

      // Check Password
      const correctPassword = 
        userKey === "gopiiniyavan@gmail.com" ? (customPasswordList["gopiiniyavan@gmail.com"] || "123456") :
        userKey === "9876543210" ? (customPasswordList["9876543210"] || "123456") :
        customPasswordList[userKey];

      if (loginPassword === correctPassword) {
        // Correct Password!
        setLoginAttempts(0); // Reset attempts
        setLoginSuccessMessage("Welcome back! Redirecting to your dashboard...");
        setTimeout(() => {
          setIsDashboardLoggedIn(true);
          setViewMode("dashboards");
          setLoginSuccessMessage("");
        }, 1200);
      } else {
        // Wrong password
        const newAttempts = loginAttempts + 1;
        setLoginAttempts(newAttempts);
        if (newAttempts >= 3) {
          setIsLocked(true);
          setLoginError("Your account is temporarily locked due to multiple failed login attempts.");
        } else {
          setLoginError("Incorrect password. Please try again.");
        }
      }
    }, 1000);
  };

  const handleOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    setLoginSuccessMessage("");

    if (!isOnlineSimulated) {
      setLoginError("❌ Internet connection lost. Please try again.");
      return;
    }

    setLoginLoading(true);
    setLoginSuccessMessage("⏳ Signing in... (loading state)");

    setTimeout(() => {
      if (loginOtp === generatedOtp || loginOtp === "123456") {
        setLoginSuccessMessage("✅ Login successful.\n🔄 Redirecting to your dashboard...");
        setTimeout(() => {
          setLoginLoading(false);
          setIsDashboardLoggedIn(true);
          setViewMode("dashboards");
          setLoginSuccessMessage("");
        }, 1200);
      } else {
        setLoginLoading(false);
        setLoginSuccessMessage("");
        setLoginError("❌ Multi-Factor Error: Incorrect OTP code. Access Denied.");
      }
    }, 1000);
  };

  const [freelancers, setFreelancers] = useState<Freelancer[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Custom Indian Currency and Support States
  const [currency, setCurrency] = useState<"USD" | "INR">("INR");
  const [supportOpen, setSupportOpen] = useState(false);
  const [supportName, setSupportName] = useState("");
  const [supportMessage, setSupportMessage] = useState("");
  const [supportLoading, setSupportLoading] = useState(false);

  // Selected details modal state
  const [selectedFreelancer, setSelectedFreelancer] = useState<Freelancer | null>(null);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [contactSuccess, setContactSuccess] = useState(false);
  const [contactMessage, setContactMessage] = useState("");

  // New Dedicated Page States
  const [jobsSearchQuery, setJobsSearchQuery] = useState("");
  const [jobsDomainFilter, setJobsDomainFilter] = useState("all");
  const [jobsTypeFilter, setJobsTypeFilter] = useState("all");
  const [activeDetailedJob, setActiveDetailedJob] = useState<Job | null>(null);
  
  // Custom interactive job bid state
  const [jobBidModalOpen, setJobBidModalOpen] = useState(false);
  const [jobBidAmount, setJobBidAmount] = useState("");
  const [jobBidProposal, setJobBidProposal] = useState("");
  const [jobBidSuccess, setJobBidSuccess] = useState(false);

  // Contact page states
  const [contactFormName, setContactFormName] = useState("");
  const [contactFormEmail, setContactFormEmail] = useState("");
  const [contactFormCategory, setContactFormCategory] = useState("General Support Inquiry");
  const [contactFormSubject, setContactFormSubject] = useState("");
  const [contactFormText, setContactFormText] = useState("");
  const [contactFormLoading, setContactFormLoading] = useState(false);
  const [contactFormSubmitted, setContactFormSubmitted] = useState(false);

  // Help page states
  const [helpSearch, setHelpSearch] = useState("");
  const [helpCategory, setHelpCategory] = useState("all");
  const [expandedFaqId, setExpandedFaqId] = useState<string | null>(null);

  // Navigation menu toggle for mobile
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // URL Hash Router Synchronization
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.toLowerCase();
      if (hash === "#/jobs" || hash === "#/browse-jobs") {
        setViewMode("jobs");
      } else if (hash === "#/about") {
        setViewMode("about");
      } else if (hash === "#/contact") {
        setViewMode("contact");
      } else if (hash === "#/help") {
        setViewMode("help");
      } else if (hash === "#/ai-workspace") {
        setViewMode("ai-workspace");
      } else if (hash === "#/dashboards") {
        setViewMode("dashboards");
      } else if (hash === "#/explore" || hash === "" || hash === "#/" || hash === "#/talent") {
        setViewMode("explore");
      } else if (hash.startsWith("#/")) {
        setViewMode("404");
      }
    };

    window.addEventListener("hashchange", handleHashChange);
    handleHashChange(); // Run initially

    return () => {
      window.removeEventListener("hashchange", handleHashChange);
    };
  }, []);

  useEffect(() => {
    const hash = window.location.hash.toLowerCase();
    let expectedHash = "#/explore";
    if (viewMode === "jobs") expectedHash = "#/browse-jobs";
    else if (viewMode === "about") expectedHash = "#/about";
    else if (viewMode === "contact") expectedHash = "#/contact";
    else if (viewMode === "help") expectedHash = "#/help";
    else if (viewMode === "ai-workspace") expectedHash = "#/ai-workspace";
    else if (viewMode === "dashboards") expectedHash = "#/dashboards";
    else if (viewMode === "explore") expectedHash = "#/explore";
    else if (viewMode === "404") expectedHash = "#/404";
    
    if (hash !== expectedHash && (viewMode !== "explore" || (hash !== "#/" && hash !== "" && hash !== "#/talent"))) {
      window.location.hash = expectedHash;
    }
  }, [viewMode]);

  // Load platform data from server
  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch("/api/platform-data");
        if (response.ok) {
          const data = await response.json();
          setFreelancers(data.freelancers || []);
          setJobs(data.jobs || []);
          setCompanies(data.companies || []);
        } else {
          throw new Error("Local fallback triggered");
        }
      } catch (err) {
        console.warn("Backend loading failed, executing local offline mockup data:", err);
        // Clean local fallbacks if server route failed
        setFreelancers([
          {
            id: "f-1",
            name: "Aravind Nair",
            title: "Lead Salesforce Technical Architect",
            avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
            location: "Bangalore, India",
            experience: "12 Years",
            hourlyRate: 85,
            expectedSalary: "₹3,500,000/yr",
            rating: 4.9,
            reviewsCount: 42,
            availability: "Available (30 hrs/wk)",
            skills: ["Salesforce Architect", "Apex Programming", "LWC", "Aura Components", "MuleSoft", "Agentforce"],
            certifications: ["Salesforce Certified Technical Architect (CTA)", "Platform Developer II"],
            bio: "Ex-Salesforce CTA. Specializes in multi-cloud architecture, complex MuleSoft integrations, and implementing Agentforce AI agents for enterprise Service Clouds.",
            socials: { github: "github.com/aravind-sf", linkedin: "linkedin.com/in/aravindsf" }
          },
          {
            id: "f-2",
            name: "Priya Sharma",
            title: "Senior Full-Stack React & Node.js Developer",
            avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
            location: "Mumbai, India",
            experience: "6 Years",
            hourlyRate: 50,
            expectedSalary: "₹1,800,000/yr",
            rating: 4.8,
            reviewsCount: 29,
            availability: "Available Immediately",
            skills: ["React", "Next.js", "TypeScript", "Node.js", "Express.js", "Tailwind CSS", "GraphQL"],
            certifications: ["AWS Certified Developer"],
            bio: "Passionate about building fast, highly responsive React/Next.js applications with gorgeous Tailwind interfaces. Skilled in real-time WebSockets and secure API design.",
            socials: { github: "github.com/priyadev", linkedin: "linkedin.com/in/priya-sharma" }
          },
          {
            id: "f-3",
            name: "Marcus Vance",
            title: "AI Engineering & LLM Specialist",
            avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150",
            location: "San Francisco, USA",
            experience: "5 Years",
            hourlyRate: 110,
            expectedSalary: "$165,000/yr",
            rating: 5.0,
            reviewsCount: 18,
            availability: "Part-time (20 hrs/wk)",
            skills: ["Python", "Generative AI", "LLMs", "RAG", "LangChain", "FastAPI"],
            certifications: ["Google Cloud Professional Machine Learning Engineer"],
            bio: "Specialist in building semantic search, RAG pipelines, and conversational AI agents. Expert in fine-tuning models and building production-ready GenAI backends.",
            socials: { github: "github.com/marcus-ai", linkedin: "linkedin.com/in/marcusvance" }
          }
        ]);
        setJobs([
          {
            id: "j-1",
            title: "Enterprise Salesforce Revenue Cloud (CPQ) Consultant",
            company: "CloudScale Solutions",
            location: "Remote (Worldwide)",
            type: "Contract (6 Months)",
            rate: "$75 - $90 / hr",
            budget: "$25,000+",
            skills: ["Salesforce Architect", "Revenue Cloud", "CPQ", "Flow Builder"],
            description: "Looking for an expert consultant to overhaul our current pricing logic and implement Salesforce CPQ/Revenue Cloud.",
            proposals: 14,
            postedAt: "2 days ago"
          },
          {
            id: "j-2",
            title: "Next.js 15 & Tailwind Frontend Developer for AI Platform",
            company: "BioGen AI Corp",
            location: "Remote",
            type: "Freelance",
            rate: "Fixed Price",
            budget: "$8,500",
            skills: ["React", "Next.js", "TypeScript", "Tailwind CSS"],
            description: "We are building an intuitive portal for genomic sequence visualization. Need a designer-developer hybrid who can build exceptionally clean, interactive layouts.",
            proposals: 32,
            postedAt: "1 day ago"
          }
        ]);
        setCompanies([
          { name: "CloudScale Solutions", logo: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=120&auto=format&fit=crop&q=60", domain: "CRM Consulting", size: "150-500 employees", rating: 4.8 },
          { name: "BioGen AI Corp", logo: "https://images.unsplash.com/photo-1530026405186-ed1ea0ac7a63?w=120&auto=format&fit=crop&q=60", domain: "Health Tech & AI", size: "50-100 employees", rating: 4.9 },
          { name: "ApexDigital Logistics", logo: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=120&auto=format&fit=crop&q=60", domain: "Global Shipping & ERP", size: "1000+ employees", rating: 4.5 },
          { name: "FinTech Prime", logo: "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=120&auto=format&fit=crop&q=60", domain: "Financial Services", size: "200-500 employees", rating: 4.7 },
          { name: "GrowthLab Agency", logo: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=120&auto=format&fit=crop&q=60", domain: "Marketing & SaaS", size: "10-50 employees", rating: 4.6 }
        ]);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSuccess(true);
    setTimeout(() => {
      setSelectedFreelancer(null);
      setContactSuccess(false);
      setContactMessage("");
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-[#070709] tech-grid-pattern text-slate-200 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      
      {/* Dynamic Top Announcement Bar */}
      <button 
        onClick={() => setNotificationsOpen(true)}
        className="w-full bg-[#09090b] text-slate-300 border-b border-white/5 py-2.5 px-4 text-center text-[10px] sm:text-xs relative overflow-hidden font-mono shrink-0 flex items-center justify-center gap-2 cursor-pointer hover:bg-white/[0.03] transition-colors group" 
        id="top-announcement-notification-bar"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-purple-500/5 to-indigo-500/5 pointer-events-none" />
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
        <span className="font-extrabold text-white uppercase tracking-wider text-[9px] sm:text-[10px] group-hover:text-indigo-400 transition-colors">📢 Live System Feed:</span>
        <span className="truncate text-slate-400 group-hover:text-slate-200 transition-colors">All pipelines are active. Direct support via gopiiniyavan@gmail.com is fully online. (Click to open feed)</span>
        <span className="hidden sm:inline bg-indigo-500/10 text-indigo-400 px-1.5 py-0.2 rounded border border-indigo-500/20 font-bold ml-1 text-[9px]">Sponsor: JEEVA V</span>
      </button>
      
      {/* Top Banner Navigation Bar */}
      <header className="sticky top-0 z-40 bg-[#09090b]/80 backdrop-blur-md border-b border-white/10 px-4 sm:px-6 py-3.5 flex items-center justify-between glass-bg">
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-1 hover:bg-white/5 rounded-lg text-slate-400 hover:text-slate-200 transition-colors cursor-pointer md:hidden"
            id="btn-mobile-menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2" id="logo-branding">
            <div className="w-9 h-9 rounded-xl accent-gradient flex items-center justify-center font-black text-white text-lg tracking-wider shadow-lg shadow-indigo-500/20">
              FX
            </div>
            <div>
              <div className="font-extrabold text-base tracking-tight text-white flex items-center gap-1.5 font-display">
                FreelanceX<span className="text-indigo-400 font-normal">.ai</span>
              </div>
              <span className="text-[10px] text-slate-500 font-mono tracking-widest block leading-tight">SKILLFORGE PORTAL</span>
            </div>
          </div>
        </div>

        {/* Creator & Contact Credit on the Top Side */}
        <div className="hidden lg:flex flex-col items-center text-center space-y-0.5 bg-indigo-950/20 px-4 py-1.5 rounded-lg border border-indigo-500/10 max-w-sm">
          <span className="text-[10px] text-indigo-300 font-bold tracking-wider font-mono">
            CREATED BY JEEVA V • 100% FREE PLATFORM
          </span>
          <span className="text-[10px] text-slate-400">
            Direct Support: <a href="mailto:gopiiniyavan@gmail.com" className="text-indigo-400 hover:underline">gopiiniyavan@gmail.com</a>
          </span>
        </div>

        {/* Top bar tools */}
        <div className="flex items-center gap-4">
          {/* Currency Toggle */}
          <div className="flex bg-[#141416] border border-white/10 p-0.5 rounded-lg gap-0.5" id="currency-switcher">
            <button
              onClick={() => setCurrency("USD")}
              title="Switch to US Dollar ($)"
              className={`px-2 py-1 rounded text-[9px] font-bold transition-all cursor-pointer ${
                currency === "USD"
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/15"
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              USD ($)
            </button>
            <button
              onClick={() => setCurrency("INR")}
              title="Switch to Indian Rupee (₹)"
              className={`px-2 py-1 rounded text-[9px] font-bold transition-all cursor-pointer ${
                currency === "INR"
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/15"
                  : "text-slate-500 hover:text-slate-300"
              }`}
            >
              INR (₹)
            </button>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 text-xs font-mono text-slate-400 bg-white/[0.02] px-3 py-1.5 rounded-lg border border-white/5">
            <Bot className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            Gemini Engine: <span className="text-indigo-400 font-bold uppercase">Active</span>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Persistent Login Button */}
            <button
              onClick={() => setViewMode("dashboards")}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 border ${
                isDashboardLoggedIn
                  ? "bg-emerald-950/25 text-emerald-400 border-emerald-500/20"
                  : viewMode === "dashboards"
                    ? "bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-500/20"
                    : "bg-indigo-950/40 hover:bg-indigo-900/40 text-indigo-400 border-indigo-500/20 hover:border-indigo-500/35"
              }`}
              id="persistent-header-login-btn"
              title={isDashboardLoggedIn ? "Session Active - Unrestricted Full Access" : "Navigate to secure Simulated Portals"}
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>{isDashboardLoggedIn ? "Session: Active (Full Access)" : "Login"}</span>
            </button>

            <button 
              onClick={() => setNotificationsOpen(true)}
              className="p-1.5 hover:bg-white/5 rounded-lg text-slate-400 hover:text-slate-200 transition-colors relative cursor-pointer"
              title="Open System Notifications & Escrow Alerts"
            >
              <Bell className="w-4 h-5" />
              {notificationLog.some(n => n.isNew) && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-indigo-500 rounded-full animate-pulse border border-[#09090b]" />
              )}
            </button>
            <div 
              onClick={() => setViewMode("dashboards")}
              className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-black text-xs text-indigo-400 font-mono shadow-inner cursor-pointer hover:border-indigo-500/50 transition-all" 
              title="Active Client Profile (Click to access Simulated Portals)"
            >
              GM
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-1 relative">
        
        {/* Navigation Sidebar Drawer */}
        <aside className={`
          fixed md:sticky top-[69px] bottom-0 left-0 z-30
          w-64 bg-[#09090b] border-r border-white/10 p-5
          flex flex-col justify-between shrink-0 transition-transform duration-300
          ${sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"}
        `}>
          <div className="space-y-6">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block px-3">Navigation Map</span>
              <nav className="space-y-1">
                {[
                  { id: "explore", label: "Talent & Jobs", icon: Compass },
                  { id: "jobs", label: "Browse Jobs", icon: Briefcase },
                  { id: "ai-workspace", label: "AI Workspaces", icon: Sparkles, badge: "Premium" },
                  { id: "dashboards", label: "Simulated Portals", icon: LayoutDashboard },
                  { id: "about", label: "Accreditation & Pricing", icon: Info },
                  { id: "help", label: "Help Center", icon: HelpCircle },
                  { id: "contact", label: "Contact Us", icon: Mail }
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setViewMode(item.id as ViewMode);
                        setSidebarOpen(false);
                      }}
                      className={`
                        w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer
                        ${viewMode === item.id 
                          ? "bg-white/5 text-white border border-white/10" 
                          : "text-slate-400 hover:text-slate-200 hover:bg-white/[0.02]"}
                      `}
                    >
                      <span className="flex items-center gap-2.5">
                        <Icon className={`w-4 h-4 ${viewMode === item.id ? "text-indigo-400" : "text-slate-500"}`} />
                        {item.label}
                      </span>
                      {item.badge && (
                        <span className="text-[9px] px-1.5 py-0.2 bg-indigo-500/10 text-indigo-400 rounded-full border border-indigo-500/20 font-bold">{item.badge}</span>
                      )}
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Salesforce Cloud Quick Links */}
            <div className="space-y-2 pt-4 border-t border-white/10">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block px-3">CRM Integration Vectors</span>
              <div className="space-y-1 pl-3 text-xs text-slate-400">
                <div className="flex items-center gap-2 py-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                  <span>Salesforce Clouds</span>
                </div>
                <div className="flex items-center gap-2 py-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                  <span>MuleSoft Integrations</span>
                </div>
                <div className="flex items-center gap-2 py-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-pink-400" />
                  <span>Agentforce AI Copilot</span>
                </div>
              </div>

              </div>
          </div>

          {/* Secure Escrow Protection Badge */}
          <div className="p-3 bg-[#141416] card-border rounded-xl space-y-1.5 text-xs">
            <span className="font-bold text-slate-300 flex items-center gap-1.5 font-display">
              <ShieldCheck className="w-4 h-4 text-indigo-400" /> Secure Payments
            </span>
            <p className="text-[10px] text-slate-500 leading-normal">
              All freelance and contract payouts are held securely in escrow pending milestones release.
            </p>
          </div>
        </aside>

        {/* Content Wrapper */}
        <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {loading ? (
            <div className="h-[400px] flex flex-col items-center justify-center space-y-3">
              <Loader2 className="w-10 h-10 text-indigo-400 animate-spin" />
              <span className="text-xs text-slate-500 font-mono">Initializing SkillForge Core Data...</span>
            </div>
          ) : (
            <div className="max-w-6xl mx-auto space-y-12">
              {viewMode === "explore" && (
                <ExploreTab 
                  freelancers={freelancers} 
                  jobs={jobs} 
                  companies={companies}
                  onSelectFreelancer={(f) => setSelectedFreelancer(f)}
                  onSelectJob={(j) => setSelectedJob(j)}
                  currency={currency}
                  selectedDomain={selectedDomain}
                  setSelectedDomain={setSelectedDomain}
                  searchQuery={searchQuery}
                  setSearchQuery={setSearchQuery}
                  isLoggedIn={isDashboardLoggedIn}
                />
              )}

              {viewMode === "ai-workspace" && (
                <AIWorkspaceTab 
                  onSelectFreelancer={(f) => setSelectedFreelancer(f)}
                  activeTool={activeWorkspaceTool}
                  setActiveTool={setActiveWorkspaceTool}
                  academyDomain={activeAcademyDomain}
                  setAcademyDomain={setActiveAcademyDomain}
                />
              )}

              {viewMode === "dashboards" && (
                !isDashboardLoggedIn ? (
                  <div className="space-y-6 max-w-md mx-auto" id="secure-login-gateway">
                    
                    {/* GOOGLE SIGN IN MODAL OVERLAY (Google One Tap style matching user screenshot) */}
                    {googleOneTapOpen && (
                      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
                        <div className="w-full max-w-sm bg-[#18181b] border border-[#27272a] rounded-2xl p-5 shadow-2xl relative overflow-hidden animate-in zoom-in-95 duration-300">
                          <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-blue-500 via-red-500 via-yellow-500 to-green-500" />
                          
                          {/* Header */}
                          <div className="flex items-center justify-between pb-3 border-b border-[#27272a] mb-4">
                            <div className="flex items-center gap-2">
                              {/* Custom Colored Google G Logo */}
                              <svg className="w-5 h-5" viewBox="0 0 24 24">
                                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z" />
                                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.16-4.53z" />
                              </svg>
                              <span className="text-xs text-slate-300 font-medium tracking-tight">Sign in to <strong className="text-white">skillforge.com</strong> with google.com</span>
                            </div>
                            <button 
                              onClick={() => setGoogleOneTapOpen(false)}
                              className="text-slate-400 hover:text-white hover:bg-white/5 p-1 rounded-full transition-colors cursor-pointer"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>

                          {/* Account Option */}
                          <div className="bg-white/[0.02] border border-white/5 rounded-xl p-3 flex items-center justify-between mb-5 hover:bg-white/[0.04] transition-all">
                            <div className="flex items-center gap-3">
                              {/* Elegant profile avatar simulating Jeeva V */}
                              <div className="relative">
                                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center border border-indigo-400/20 text-white font-bold text-sm shadow-md font-display overflow-hidden">
                                  JV
                                </div>
                                <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-[#18181b] flex items-center justify-center">
                                  <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                                </div>
                              </div>
                              <div className="text-left">
                                <h4 className="text-xs font-bold text-white leading-tight flex items-center gap-1">
                                  Jeeva V <span className="text-[9px] px-1 bg-indigo-500/15 text-indigo-400 border border-indigo-500/10 rounded font-normal uppercase">Owner</span>
                                </h4>
                                <span className="text-[10px] text-slate-400 font-mono">gopiiniyavan@gmail.com</span>
                              </div>
                            </div>
                            <span className="text-[10px] text-slate-500 font-mono">Active</span>
                          </div>

                          {/* Action Button */}
                          <button
                            onClick={() => {
                              setGoogleOneTapOpen(false);
                              setLoginLoading(true);
                              setLoginError("");
                              setLoginSuccessMessage("⏳ Signing in with Google One Tap...");
                              setTimeout(() => {
                                setLoginSuccessMessage("✅ Login successful.\n🔄 Redirecting to your dashboard...");
                                setTimeout(() => {
                                  setLoginLoading(false);
                                  setIsDashboardLoggedIn(true);
                                  setViewMode("dashboards");
                                  setLoginSuccessMessage("");
                                }, 1200);
                              }, 1500);
                            }}
                            className="w-full bg-[#1a73e8] hover:bg-[#1557b0] text-white font-bold py-2.5 px-4 rounded-xl text-xs transition-colors cursor-pointer shadow-lg shadow-blue-500/10 flex items-center justify-center gap-2"
                          >
                            <span>Continue as Jeeva</span>
                          </button>

                          {/* Bottom Disclaimer */}
                          <p className="text-[9px] text-slate-500 mt-4 leading-normal text-left">
                            To continue, google.com will share your name, email address, and profile picture with this site. See this site's <span className="text-indigo-400 underline cursor-pointer hover:text-indigo-300">privacy policy</span>.
                          </p>
                        </div>
                      </div>
                    )}

                    {/* CORE CREDENTIAL KEYS GATEWAY CARD (SkillForge Identity) */}
                    <div className="bg-[#141416] card-border rounded-2xl p-6 sm:p-8 space-y-6 relative overflow-hidden shadow-2xl transition-all duration-300">
                      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-500" />
                      <div className="absolute -top-12 -right-12 w-32 h-32 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

                      {/* Header ASCII-Equivalent Grid */}
                      <div className="text-center space-y-1 pb-4 border-b border-white/5">
                        <h1 className="text-2xl font-black text-white tracking-[0.25em] font-display uppercase">SKILLFORGE</h1>
                        <p className="text-[10px] text-indigo-400 font-mono font-bold uppercase tracking-[0.15em]">Learn • Build • Get Hired</p>
                        {showForgotPassword && (
                          <p className="text-[9px] text-purple-400 font-mono font-bold uppercase tracking-[0.12em] mt-1">PASSWORD RECOVERY</p>
                        )}
                        {!showForgotPassword && (
                          <div className="pt-4">
                            <h2 className="text-base font-extrabold text-slate-200">Welcome Back! 👋</h2>
                            <p className="text-xs text-slate-400">
                              {loginSuccessMessage ? "Sign in using your new password." : "Sign in to continue your learning journey."}
                            </p>
                          </div>
                        )}
                      </div>

                      {/* Diagnostic Alert Messages */}
                      {loginError && (
                        <div className="p-3 bg-red-950/20 border border-red-500/25 rounded-xl text-xs text-red-400 flex items-start gap-2 animate-shake">
                          <span className="shrink-0 font-bold mt-0.5 text-red-500">❌</span>
                          <span className="font-mono">{loginError}</span>
                        </div>
                      )}

                      {loginSuccessMessage && (
                        <div className="p-3 bg-emerald-950/20 border border-emerald-500/25 rounded-xl text-xs text-emerald-400 flex items-start gap-2 animate-in fade-in duration-300">
                          <span className="shrink-0 font-bold mt-0.5 text-emerald-400 animate-pulse">⚡</span>
                          <span className="font-mono whitespace-pre-line">{loginSuccessMessage}</span>
                        </div>
                      )}

                      {/* CONDITIONAL SUB-VIEWS */}
                      {showForgotPassword ? (
                        /* RESET PASSWORD GATEWAY WIZARD */
                        <div className="space-y-4 animate-in fade-in zoom-in-95 duration-200 text-left">
                          
                          {/* STEP 1: FORGOT PASSWORD */}
                          {recoveryStep === 0 && (
                            <div className="space-y-4">
                              <div className="p-3 bg-indigo-950/20 border border-indigo-500/20 rounded-xl">
                                <span className="text-[10px] font-extrabold text-indigo-400 uppercase tracking-wider block mb-1">
                                  FORGOT PASSWORD
                                </span>
                                <p className="text-[11px] text-slate-300">
                                  Enter your registered email address or mobile number.
                                </p>
                              </div>

                              <div className="space-y-1.5">
                                <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block">
                                  Email Address or Mobile Number *
                                </label>
                                <input
                                  type="text"
                                  value={recoveryEmail}
                                  onChange={(e) => setRecoveryEmail(e.target.value)}
                                  className="w-full bg-[#09090b] border border-[#27272a] rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono transition-colors"
                                  placeholder="Enter your registered email or mobile number"
                                />
                              </div>

                              <div className="flex gap-2">
                                <button
                                  type="button"
                                  onClick={() => { setShowForgotPassword(false); setRecoveryStep(0); setLoginError(""); }}
                                  className="flex-1 bg-[#141416] hover:bg-[#1c1c1f] text-slate-400 hover:text-white border border-white/10 rounded-xl py-2.5 text-xs font-semibold cursor-pointer transition-colors"
                                >
                                  Cancel
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setLoginError("");
                                    setLoginSuccessMessage("");

                                    if (!recoveryEmail || !recoveryEmail.trim()) {
                                      setLoginError("Please enter your registered email or mobile number.");
                                      return;
                                    }

                                    const val = recoveryEmail.trim();
                                    const isEmail = val.includes("@");
                                    const isMobile = !isEmail && /^\+?\d{7,15}$/.test(val.replace(/[^\d+]/g, ""));

                                    if (!isEmail && !isMobile) {
                                      setLoginError("Please enter a valid email address or mobile number.");
                                      return;
                                    }

                                    const lookupKey = val.toLowerCase();
                                    const accountExists = 
                                      lookupKey === "gopiiniyavan@gmail.com" || 
                                      lookupKey === "9876543210" || 
                                      customPasswordList[lookupKey] !== undefined;

                                    if (!accountExists) {
                                      setLoginError("No account found with the provided information.");
                                      return;
                                    }

                                    setRecoveryLoading(true);
                                    setTimeout(() => {
                                      setRecoveryLoading(false);
                                      
                                      const mOtp = Math.floor(100000 + Math.random() * 900000).toString();
                                      setRecoveryOtpCode(mOtp);
                                      setRecoveryType(isEmail ? "email" : "mobile");
                                      
                                      setOtpDigits(["", "", "", "", "", ""]);
                                      setResendCountdown(30);
                                      setFailedVerificationAttempts(0);
                                      setIsCodeExpired(false);
                                      
                                      setRecoveryStep(1); // Proceed to Step 2 (Verification Sent)
                                    }, 800);
                                  }}
                                  disabled={recoveryLoading}
                                  className="flex-[2] bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-lg shadow-indigo-500/10"
                                >
                                  {recoveryLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <span>CONTINUE</span>}
                                </button>
                              </div>
                            </div>
                          )}

                          {/* STEP 2: VERIFICATION SENT */}
                          {recoveryStep === 1 && (
                            <div className="space-y-4">
                              <div className="p-4 bg-[#141416]/60 border border-[#27272a] rounded-xl text-center">
                                <p className="text-xs text-slate-200 leading-relaxed font-sans">
                                  Verification message sent successfully.
                                </p>
                                <p className="text-xs text-slate-200 leading-relaxed mt-2 font-sans">
                                  Please check your registered email or mobile.
                                </p>
                              </div>

                              <div className="flex gap-2">
                                <button
                                  type="button"
                                  onClick={() => setRecoveryStep(0)}
                                  className="flex-1 bg-[#141416] hover:bg-[#1c1c1f] text-slate-400 hover:text-white border border-white/10 rounded-xl py-2.5 text-xs font-semibold cursor-pointer"
                                >
                                  Back
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setLoginError("");
                                    if (recoveryType === "mobile") {
                                      setRecoveryStep(2); // Proceed to Enter 6-digit OTP
                                    } else {
                                      setRecoveryStep(3); // Go straight to Create New Password
                                    }
                                  }}
                                  className="flex-[2] bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 rounded-xl text-xs transition-colors cursor-pointer shadow-lg shadow-indigo-500/10"
                                >
                                  {recoveryType === "email" ? "Open Password Reset Link" : "CONTINUE"}
                                </button>
                              </div>
                            </div>
                          )}

                          {/* STEP 3: VERIFY CODE */}
                          {recoveryStep === 2 && (
                            <div className="space-y-4">
                              <div className="p-3 bg-indigo-950/20 border border-indigo-500/20 rounded-xl">
                                <span className="text-[10px] font-extrabold text-indigo-400 uppercase tracking-wider block mb-1">
                                  VERIFY CODE
                                </span>
                                <p className="text-[11px] text-slate-300">
                                  Enter the 6-digit verification code.
                                </p>
                              </div>

                              {/* Interactive Digit Blocks */}
                              <div className="space-y-2">
                                <div className="flex justify-between gap-2">
                                  {[0, 1, 2, 3, 4, 5].map((idx) => (
                                    <input
                                      key={`otp-box-${idx}`}
                                      id={`otp-${idx}`}
                                      type="text"
                                      maxLength={1}
                                      value={otpDigits[idx] || ""}
                                      onChange={(e) => handleDigitChange(e.target.value, idx, "otp")}
                                      onKeyDown={(e) => handleDigitKeyDown(e, idx, "otp")}
                                      disabled={failedVerificationAttempts >= 3}
                                      className="w-10 h-10 bg-[#09090b] border border-white/10 rounded-xl text-center text-sm font-extrabold text-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono transition-all disabled:opacity-40"
                                      placeholder="_"
                                    />
                                  ))}
                                </div>
                              </div>

                              {/* Resend Code Timer */}
                              <div className="flex justify-between items-center text-xs pt-1">
                                <span className="text-slate-400 font-mono">
                                  {resendCountdown > 0 ? (
                                    <span className="text-slate-500 font-bold">
                                      Resend Code ({resendCountdown}s)
                                    </span>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const mOtp = Math.floor(100000 + Math.random() * 900000).toString();
                                        setRecoveryOtpCode(mOtp);
                                        setResendCountdown(30);
                                        setIsCodeExpired(false);
                                        setFailedVerificationAttempts(0);
                                        setLoginError("");
                                      }}
                                      className="text-indigo-400 hover:text-indigo-300 font-bold transition-colors uppercase tracking-wider"
                                    >
                                      Resend Code
                                    </button>
                                  )}
                                </span>
                              </div>


                              <div className="h-px bg-white/5 my-2"></div>

                              <div className="flex gap-2">
                                <button
                                  type="button"
                                  onClick={() => setRecoveryStep(1)}
                                  className="flex-1 bg-[#141416] hover:bg-[#1c1c1f] text-slate-400 hover:text-white border border-white/10 rounded-xl py-2.5 text-xs font-semibold cursor-pointer"
                                >
                                  BACK
                                </button>
                                <button
                                  type="button"
                                  disabled={failedVerificationAttempts >= 3}
                                  onClick={() => {
                                    if (failedVerificationAttempts >= 3) {
                                      setLoginError("Too many incorrect attempts. Please try again later.");
                                      return;
                                    }

                                    const enteredOtp = otpDigits.join("");
                                    if (enteredOtp.length === 0) {
                                      setLoginError("Please enter the verification code.");
                                      return;
                                    }

                                    if (enteredOtp.length < 6) {
                                      setLoginError("The verification code is incorrect.");
                                      return;
                                    }

                                    if (isCodeExpired) {
                                      setLoginError("The verification code has expired. Request a new one.");
                                      return;
                                    }

                                    const isCorrect = enteredOtp === recoveryOtpCode || enteredOtp === "123456";
                                    if (isCorrect) {
                                      setLoginError("");
                                      setNewPassword("");
                                      setConfirmPassword("");
                                      setRecoveryStep(3); // Proceed to Step 4 (Create New Password)
                                    } else {
                                      const nextFails = failedVerificationAttempts + 1;
                                      setFailedVerificationAttempts(nextFails);
                                      if (nextFails >= 3) {
                                        setLoginError("Too many incorrect attempts. Please try again later.");
                                      } else {
                                        setLoginError("The verification code is incorrect.");
                                      }
                                    }
                                  }}
                                  className="flex-[2] bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 rounded-xl text-xs transition-colors cursor-pointer disabled:opacity-50 shadow-lg shadow-indigo-500/10"
                                >
                                  VERIFY
                                </button>
                              </div>
                            </div>
                          )}

                          {/* STEP 4: CREATE NEW PASSWORD */}
                          {recoveryStep === 3 && (
                            <div className="space-y-4">
                              <div className="p-3 bg-indigo-950/20 border border-indigo-500/20 rounded-xl">
                                <span className="text-[10px] font-extrabold text-indigo-400 uppercase tracking-wider block mb-1">
                                  CREATE NEW PASSWORD
                                </span>
                              </div>

                              {/* New Password input */}
                              <div className="space-y-1.5">
                                <div className="flex justify-between items-center">
                                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                                    New Password
                                  </label>
                                  <button
                                    type="button"
                                    onClick={() => setShowRecoveryPassword(!showRecoveryPassword)}
                                    className="text-[9px] text-indigo-400 hover:text-indigo-300 font-extrabold transition-colors uppercase tracking-wider font-mono"
                                  >
                                    {showRecoveryPassword ? "👁 Hide" : "👁 Show"}
                                  </button>
                                </div>
                                <input
                                  type={showRecoveryPassword ? "text" : "password"}
                                  value={newPassword}
                                  onChange={(e) => setNewPassword(e.target.value)}
                                  required
                                  className="w-full bg-[#09090b] border border-white/10 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                                  placeholder="Enter new password"
                                />
                              </div>

                              {/* Confirm Password input */}
                              <div className="space-y-1.5">
                                <div className="flex justify-between items-center">
                                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                                    Confirm Password
                                  </label>
                                  <button
                                    type="button"
                                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                    className="text-[9px] text-indigo-400 hover:text-indigo-300 font-extrabold transition-colors uppercase tracking-wider font-mono"
                                  >
                                    {showConfirmPassword ? "👁 Hide" : "👁 Show"}
                                  </button>
                                </div>
                                <input
                                  type={showConfirmPassword ? "text" : "password"}
                                  value={confirmPassword}
                                  onChange={(e) => setConfirmPassword(e.target.value)}
                                  required
                                  className="w-full bg-[#09090b] border border-white/10 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                                  placeholder="Confirm new password"
                                />
                              </div>

                              {/* Password Requirements */}
                              <div className="p-3.5 bg-[#141416]/80 border border-[#27272a] rounded-xl space-y-2">
                                <span className="text-[9px] font-extrabold text-indigo-400 uppercase tracking-wider block">
                                  Password Requirements
                                </span>
                                <div className="space-y-1 text-[11px] font-mono">
                                  {/* Rule 1 */}
                                  <div className="flex items-center gap-2">
                                    <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] font-extrabold ${newPassword.length >= 8 ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-white/5 text-slate-500 border border-white/5"}`}>
                                      {newPassword.length >= 8 ? "✓" : "•"}
                                    </span>
                                    <span className={newPassword.length >= 8 ? "text-slate-300" : "text-slate-500"}>
                                      Minimum 8 characters
                                    </span>
                                  </div>

                                  {/* Rule 2 */}
                                  <div className="flex items-center gap-2">
                                    <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] font-extrabold ${/[A-Z]/.test(newPassword) ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-white/5 text-slate-500 border border-white/5"}`}>
                                      {/[A-Z]/.test(newPassword) ? "✓" : "•"}
                                    </span>
                                    <span className={/[A-Z]/.test(newPassword) ? "text-slate-300" : "text-slate-500"}>
                                      One uppercase letter
                                    </span>
                                  </div>

                                  {/* Rule 3 */}
                                  <div className="flex items-center gap-2">
                                    <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] font-extrabold ${/[a-z]/.test(newPassword) ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-white/5 text-slate-500 border border-white/5"}`}>
                                      {/[a-z]/.test(newPassword) ? "✓" : "•"}
                                    </span>
                                    <span className={/[a-z]/.test(newPassword) ? "text-slate-300" : "text-slate-500"}>
                                      One lowercase letter
                                    </span>
                                  </div>

                                  {/* Rule 4 */}
                                  <div className="flex items-center gap-2">
                                    <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] font-extrabold ${/\d/.test(newPassword) ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-white/5 text-slate-500 border border-white/5"}`}>
                                      {/\d/.test(newPassword) ? "✓" : "•"}
                                    </span>
                                    <span className={/\d/.test(newPassword) ? "text-slate-300" : "text-slate-500"}>
                                      One number
                                    </span>
                                  </div>

                                  {/* Rule 5 */}
                                  <div className="flex items-center gap-2">
                                    <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] font-extrabold ${/[!@#$%^&*(),.?":{}|<>]/.test(newPassword) ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-white/5 text-slate-500 border border-white/5"}`}>
                                      {/[!@#$%^&*(),.?":{}|<>]/.test(newPassword) ? "✓" : "•"}
                                    </span>
                                    <span className={/[!@#$%^&*(),.?":{}|<>]/.test(newPassword) ? "text-slate-300" : "text-slate-500"}>
                                      One special character
                                    </span>
                                  </div>
                                </div>
                              </div>

                              <button
                                type="button"
                                onClick={() => {
                                  if (!newPassword) {
                                    setLoginError("Please enter a new password.");
                                    return;
                                  }
                                  
                                  const minCharOk = newPassword.length >= 8;
                                  if (!minCharOk) {
                                    setLoginError("Password must be at least 8 characters long.");
                                    return;
                                  }

                                  const upperOk = /[A-Z]/.test(newPassword);
                                  if (!upperOk) {
                                    setLoginError("Include at least one uppercase letter.");
                                    return;
                                  }

                                  const lowerOk = /[a-z]/.test(newPassword);
                                  if (!lowerOk) {
                                    setLoginError("Include at least one lowercase letter.");
                                    return;
                                  }

                                  const numOk = /\d/.test(newPassword);
                                  if (!numOk) {
                                    setLoginError("Include at least one number.");
                                    return;
                                  }

                                  const specialOk = /[!@#$%^&*(),.?":{}|<>]/.test(newPassword);
                                  if (!specialOk) {
                                    setLoginError("Include at least one special character.");
                                    return;
                                  }

                                  if (newPassword !== confirmPassword) {
                                    setLoginError("Passwords do not match.");
                                    return;
                                  }

                                  // Update custom password list
                                  setCustomPasswordList({
                                    ...customPasswordList,
                                    [recoveryEmail.trim().toLowerCase()]: newPassword
                                  });

                                  setLoginEmail(recoveryEmail);
                                  setLoginPassword(newPassword);
                                  setLoginError("");
                                  setRecoveryStep(4); // Go to final confirmation screen
                                }}
                                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 rounded-xl text-xs transition-colors cursor-pointer shadow-lg shadow-indigo-500/10"
                              >
                                UPDATE PASSWORD
                              </button>
                            </div>
                          )}

                          {/* STEP 5: PASSWORD UPDATED (SUCCESS) */}
                          {recoveryStep === 4 && (
                            <div className="p-4 bg-[#141416]/90 border border-[#27272a] rounded-xl space-y-4 text-center animate-in fade-in zoom-in-95 duration-200">
                              <span className="text-[10px] font-extrabold text-emerald-400 uppercase tracking-wider block">
                                PASSWORD UPDATED
                              </span>
                              <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 text-xl mx-auto animate-bounce">
                                ✓
                              </div>
                              <p className="text-xs text-slate-200 leading-relaxed">
                                ✅ Your password has been updated successfully.
                              </p>
                              <button
                                type="button"
                                onClick={() => {
                                  setShowForgotPassword(false);
                                  setRecoveryStep(0);
                                  setOtpDigits(["", "", "", "", "", ""]);
                                  setNewPassword("");
                                  setConfirmPassword("");
                                  setLoginError("");
                                  setLoginSuccessMessage("Your password has been updated successfully.\nSign in using your new password.");
                                }}
                                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl text-xs transition-colors cursor-pointer shadow-lg shadow-emerald-500/10"
                              >
                                BACK TO LOGIN
                              </button>
                            </div>
                          )}
                        </div>
                      ) : loginStep === 0 ? (
                        /* STEP 0: Credentials Input Form */
                        <form onSubmit={handlePasswordSubmit} className="space-y-4 text-left">
                          
                          {/* Email Field */}
                          <div className="space-y-1.5">
                            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Email Address *</label>
                            <input
                              type="email"
                              value={loginEmail}
                              onChange={(e) => setLoginEmail(e.target.value)}
                              required
                              placeholder="Enter your email address"
                              className="w-full bg-[#09090b] border border-white/10 rounded-xl p-3 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-mono"
                            />
                          </div>

                          {/* Password Field with ASCII-Aligned Eye Toggle */}
                          <div className="space-y-1.5">
                            <div className="flex justify-between items-center">
                              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Password *</label>
                              <button
                                type="button"
                                onClick={() => setShowPassword(!showPassword)}
                                className="text-[10px] text-indigo-400 hover:text-indigo-300 font-bold transition-colors uppercase tracking-wider flex items-center gap-1 font-mono"
                              >
                                {showPassword ? (
                                  <>
                                    <EyeOff className="w-3.5 h-3.5" />
                                    <span>Hide</span>
                                  </>
                                ) : (
                                  <>
                                    <Eye className="w-3.5 h-3.5" />
                                    <span>Show</span>
                                  </>
                                )}
                              </button>
                            </div>
                            <input
                              type={showPassword ? "text" : "password"}
                              required
                              value={loginPassword}
                              onChange={(e) => setLoginPassword(e.target.value)}
                              placeholder="••••••••••••"
                              className="w-full bg-[#09090b] border border-white/10 rounded-xl p-3 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono transition-all"
                            />
                          </div>

                          {/* Remember me & Forgot Passcode line */}
                          <div className="flex justify-between items-center pt-1">
                            <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer select-none">
                              <input
                                type="checkbox"
                                checked={rememberMe}
                                onChange={(e) => setRememberMe(e.target.checked)}
                                className="rounded bg-[#09090b] border-white/10 text-indigo-600 focus:ring-indigo-500/20 w-4 h-4 cursor-pointer"
                              />
                              <span>Remember Me</span>
                            </label>
                            
                            <button
                              type="button"
                              onClick={() => { 
                                setShowForgotPassword(true); 
                                setRecoveryStep(0); 
                                setLoginError(""); 
                                setLoginSuccessMessage("");
                              }}
                              className="text-xs text-indigo-400 hover:text-indigo-300 hover:underline font-semibold font-mono tracking-wide cursor-pointer"
                            >
                              Forgot Password?
                            </button>
                          </div>

                          {/* Submit Button */}
                          <button
                            type="submit"
                            disabled={loginLoading}
                            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-xl text-xs sm:text-sm transition-all shadow-lg shadow-indigo-500/15 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                          >
                            {loginLoading ? (
                              <>
                                <Loader2 className="w-4 h-4 animate-spin text-white" />
                                <span>Verifying credentials...</span>
                              </>
                            ) : (
                              <>
                                <span>SIGN IN</span>
                                <ArrowUpRight className="w-4 h-4" />
                              </>
                            )}
                          </button>

                          {/* ASCII-aligned divider */}
                          <div className="flex items-center gap-3 my-4">
                            <div className="h-[1px] bg-white/5 flex-1" />
                            <span className="text-[10px] text-slate-500 font-black tracking-widest font-mono">OR</span>
                            <div className="h-[1px] bg-white/5 flex-1" />
                          </div>

                          {/* Google & GitHub Buttons */}
                          <div className="grid grid-cols-1 gap-2.5">
                            <button
                              type="button"
                              onClick={() => {
                                setLoginError("");
                                setLoginSuccessMessage("");
                                setGoogleOneTapOpen(true);
                              }}
                              className="w-full bg-[#1c1c1e]/60 hover:bg-[#1c1c1e] text-slate-200 border border-white/5 rounded-xl py-2.5 text-xs font-semibold cursor-pointer transition-all flex items-center justify-center gap-2"
                            >
                              {/* Colored G Vector Icon */}
                              <svg className="w-4 h-4" viewBox="0 0 24 24">
                                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z" />
                                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.16-4.53z" />
                              </svg>
                              <span>Continue with Google</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                setLoginLoading(true);
                                setLoginError("");
                                setLoginSuccessMessage("⏳ Authorizing with GitHub Secure Escrow...");
                                setTimeout(() => {
                                  setLoginSuccessMessage("✅ Login successful.\n🔄 Redirecting to your dashboard...");
                                  setTimeout(() => {
                                    setLoginLoading(false);
                                    setIsDashboardLoggedIn(true);
                                    setViewMode("dashboards");
                                    setLoginSuccessMessage("");
                                  }, 1200);
                                }, 1200);
                              }}
                              className="w-full bg-[#1c1c1e]/60 hover:bg-[#1c1c1e] text-slate-200 border border-white/5 rounded-xl py-2.5 text-xs font-semibold cursor-pointer transition-all flex items-center justify-center gap-2"
                            >
                              <Github className="w-4 h-4 text-slate-300" />
                              <span>Continue with GitHub</span>
                            </button>
                          </div>

                          {/* Create Account registration Option */}
                          <div className="text-center pt-3 text-xs text-slate-500">
                            <span>Don't have an account? </span>
                            <button
                              type="button"
                              onClick={() => {
                                const newMail = prompt("Enter registration email address:", "engineer@example.com");
                                if (newMail) {
                                  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                                  if (!emailRegex.test(newMail)) {
                                    alert("❌ Please enter a valid email format.");
                                    return;
                                  }
                                  const newPass = prompt("Create account password (minimum 8 characters):", "skillforge2026");
                                  if (newPass) {
                                    if (newPass.length < 8) {
                                      alert("❌ Password must be at least 8 characters.");
                                      return;
                                    }
                                    setCustomPasswordList({
                                      ...customPasswordList,
                                      [newMail.trim()]: newPass
                                    });
                                    setLoginEmail(newMail.trim());
                                    setLoginPassword(newPass);
                                    alert(`✅ Account created successfully for ${newMail}! We have prefilled it so you can login instantly.`);
                                  }
                                }
                              }}
                              className="text-indigo-400 hover:text-indigo-300 font-bold hover:underline font-mono ml-1 cursor-pointer"
                            >
                              Create Account
                            </button>
                          </div>

                        </form>
                      ) : (
                        /* STEP 1: Multi-Factor Authentication Gate (OTP verification) */
                        <form onSubmit={handleOtpSubmit} className="space-y-5 text-left">
                          <div className="p-3.5 bg-indigo-950/25 border border-indigo-500/25 rounded-xl space-y-2">
                            <div className="flex items-center gap-2 text-xs font-bold text-indigo-300">
                              <span className="animate-ping w-1.5 h-1.5 rounded-full bg-indigo-400 shrink-0" />
                              <span>OTP Token Dispatched Successfully!</span>
                            </div>
                            <p className="text-[11px] text-slate-400 leading-relaxed">
                              We have dispatched a temporary multi-factor verification token to <strong className="text-white">{loginEmail}</strong>.
                            </p>
                            <div className="pt-1.5 border-t border-white/5 flex items-center justify-between text-[11px]">
                              <span className="text-slate-400 font-medium font-mono">Your Secure OTP Code:</span>
                              <span className="font-mono text-xs font-bold text-emerald-400 bg-emerald-950/30 px-2.5 py-1 rounded border border-emerald-500/20 select-all tracking-wider">{generatedOtp}</span>
                            </div>
                          </div>

                          <div className="space-y-1.5">
                            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Enter 6-Digit Code</label>
                            <input
                              type="text"
                              maxLength={6}
                              required
                              value={loginOtp}
                              onChange={(e) => setLoginOtp(e.target.value.replace(/[^\d]/g, ""))}
                              placeholder="e.g. 540912"
                              className="w-full bg-[#09090b] border border-white/10 rounded-xl p-3 text-center text-sm font-bold tracking-widest text-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-mono"
                            />
                          </div>

                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => { setLoginStep(0); setLoginOtp(""); setLoginError(""); }}
                              className="flex-1 bg-[#141416] hover:bg-[#1c1c1f] text-slate-400 hover:text-white border border-white/10 rounded-xl py-3 text-xs sm:text-sm font-semibold cursor-pointer transition-all"
                            >
                              Back
                            </button>
                            <button
                              type="submit"
                              disabled={loginLoading}
                              className="flex-[2] bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-xl text-xs sm:text-sm transition-all shadow-lg shadow-indigo-500/10 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                            >
                              {loginLoading ? (
                                <Loader2 className="w-4 h-4 animate-spin text-white" />
                              ) : (
                                <>
                                  <span>Confirm & Unlock</span>
                                  <ArrowUpRight className="w-4 h-4" />
                                </>
                              )}
                            </button>
                          </div>
                        </form>
                      )}

                      {/* Footer Policy links */}
                      <div className="pt-4 border-t border-white/5 flex justify-center gap-3 text-[10px] text-slate-500 font-mono">
                        <span className="hover:text-slate-400 cursor-pointer">Privacy Policy</span>
                        <span>|</span>
                        <span className="hover:text-slate-400 cursor-pointer">Terms</span>
                        <span>|</span>
                        <span className="hover:text-slate-400 cursor-pointer" onClick={() => alert("Sandbox Login Assistance:\nDefault email is 'gopiiniyavan@gmail.com'.\nYou can recover password using the 'Forgot Password' link or use default Sandbox Passkey '123456'.")}>Help</span>
                      </div>

                    </div>

                    {/* INTERACTIVE SANBOX CONTROLS (Toggling simulated errors and connections) */}
                    <div className="bg-[#141416]/50 border border-white/5 rounded-2xl p-4 text-left space-y-3 shadow-md animate-in fade-in zoom-in-95 duration-500">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase text-indigo-400 font-mono tracking-widest block">Sandbox Diagnostics Panel</span>
                        <div className="flex items-center gap-1.5">
                          <span className={`w-1.5 h-1.5 rounded-full ${isOnlineSimulated ? "bg-emerald-500" : "bg-red-500"} animate-pulse`} />
                          <span className="text-[9px] font-mono font-bold text-slate-400">{isOnlineSimulated ? "Online" : "Offline"}</span>
                        </div>
                      </div>

                      <p className="text-[10px] text-slate-400 leading-normal">
                        Simulate complex authentication scenarios like lockouts, connection failure error states, or prefilled passkeys instantly.
                      </p>

                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            setIsOnlineSimulated(!isOnlineSimulated);
                            setLoginError("");
                            setLoginSuccessMessage("");
                          }}
                          className={`px-3 py-1.5 rounded-lg text-[10px] font-bold font-mono transition-all cursor-pointer flex items-center justify-center gap-1 border ${
                            isOnlineSimulated 
                              ? "bg-emerald-500/10 hover:bg-emerald-500/25 text-emerald-400 border-emerald-500/20" 
                              : "bg-red-500/10 hover:bg-red-500/25 text-red-400 border-red-500/20"
                          }`}
                        >
                          🌐 {isOnlineSimulated ? "Go Offline" : "Go Online"}
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setLoginAttempts(0);
                            setIsLocked(false);
                            setLoginError("");
                            alert("🔓 Login Lock and Failed attempts counter reset to zero!");
                          }}
                          className="px-3 py-1.5 rounded-lg text-[10px] font-bold font-mono bg-indigo-500/10 hover:bg-indigo-500/25 text-indigo-400 border border-indigo-500/20 transition-all cursor-pointer flex items-center justify-center gap-1"
                        >
                          🔓 Reset Lock
                        </button>
                      </div>

                      <div className="pt-2 border-t border-white/[0.03] space-y-1">
                        <span className="text-[9px] text-slate-500 font-bold block uppercase tracking-wide">Prefill Sandbox Keys:</span>
                        <div className="flex flex-wrap gap-1">
                          {["jeeva", "gopiiniyavan", "skillforge", "123456"].map(p => (
                            <button
                              key={p}
                              type="button"
                              onClick={() => {
                                setLoginEmail("gopiiniyavan@gmail.com");
                                setLoginPassword(p);
                                setLoginError("");
                                setLoginSuccessMessage("");
                              }}
                              className="text-[9px] bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white px-2 py-0.5 rounded font-mono border border-white/5 transition-colors"
                            >
                              {p}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                  </div>
                ) : (
                  <DashboardsTab 
                    freelancers={freelancers} 
                    jobs={jobs} 
                    currency={currency}
                    activeTab={activeDashboardTab}
                    setActiveTab={setActiveDashboardTab}
                    isLoggedIn={isDashboardLoggedIn}
                    setIsLoggedIn={setIsDashboardLoggedIn}
                  />
                )
              )}

              {viewMode === "about" && (
                <div className="space-y-12 animate-in fade-in duration-300">
                  {/* Pricing Cards */}
                  <div className="space-y-8" id="free-access-pricing-section">
                    <div className="text-center space-y-2">
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-bold border border-emerald-500/20 font-mono uppercase tracking-wide animate-pulse">
                        ★ 100% Commission-Free Vetted Marketplace ★
                      </div>
                      <h2 className="text-3xl md:text-5xl font-black text-white font-display tracking-tight">Full Access — Free</h2>
                      <p className="text-slate-400 text-xs sm:text-sm max-w-xl mx-auto">All premium features included, absolutely no restrictions. Funded entirely by direct enterprise placement sponsorships.</p>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto pt-4 items-stretch">
                      
                      {/* Left & Mid columns: Massive "Full Access — Free" Centerpiece */}
                      <div className="lg:col-span-2 bg-[#141416] border-2 border-indigo-500/40 rounded-2xl p-6 sm:p-8 flex flex-col justify-between space-y-6 relative overflow-hidden shadow-2xl shadow-indigo-500/5">
                        <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
                        <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />
                        
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-white/5 pb-6">
                          <div className="space-y-1">
                            <span className="text-[10px] bg-indigo-500/10 text-indigo-400 font-bold px-2 py-0.5 rounded border border-indigo-500/20 font-mono uppercase tracking-widest">
                              ZERO FEES GUARANTEE
                            </span>
                            <h3 className="text-2xl font-bold text-white font-display">All-Inclusive Professional Tier</h3>
                            <p className="text-xs text-slate-400">Everything you need to level up your technical career, completely unlocked.</p>
                          </div>
                          
                          <div className="text-left sm:text-right">
                            <div className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">
                              ₹0 <span className="text-lg font-normal text-slate-400">/ $0</span>
                            </div>
                            <span className="text-xs text-slate-500 font-semibold block uppercase font-mono mt-1">perpetually free</span>
                          </div>
                        </div>

                        {/* List of 14 features in a clean two-column grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                          {[
                            "Unlimited job applications",
                            "Search jobs & internships across Tier 1, 2 & 3 companies",
                            "AI-powered job matching",
                            "Public profile & portfolio builder",
                            "AI Resume Builder",
                            "AI Proposal Generator",
                            "AI Interview Coach",
                            "Skill Assessments & Certifications",
                            "Community forum & discussions",
                            "Messaging & collaboration tools",
                            "Analytics dashboard",
                            "Verified badge",
                            "Priority in search results",
                            "Video introduction"
                          ].map((feat, i) => (
                            <div key={i} className="flex items-start gap-2.5 text-xs text-slate-300 group">
                              <div className="w-4.5 h-4.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 group-hover:scale-110 transition-transform">
                                <ShieldCheck className="w-3 h-3" />
                              </div>
                              <span className="leading-tight">{feat}</span>
                            </div>
                          ))}
                        </div>

                        <div className="pt-6 border-t border-white/5">
                          <button 
                            onClick={() => {
                              setViewMode("dashboards");
                              setActiveDashboardTab("student");
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                            className="w-full bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-extrabold py-3.5 rounded-xl text-sm transition-all cursor-pointer shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2 group"
                            id="join-free-primary-btn"
                          >
                            <span>Join Free — Start Searching</span>
                            <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                          </button>
                        </div>
                      </div>

                      {/* Right column: "Work & Get Paid" & Trust Escrow Hub */}
                      <div className="bg-[#141416]/90 border border-white/10 rounded-2xl p-6 sm:p-8 flex flex-col justify-between space-y-6 relative overflow-hidden shadow-xl">
                        <div className="space-y-4">
                          <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-bold px-2 py-0.5 rounded border border-emerald-500/20 font-mono uppercase tracking-widest inline-block">
                            100% SECURE ESCROWS
                          </span>
                          
                          <div className="space-y-2">
                            <h3 className="text-xl font-bold text-white font-display">Work & Get Paid</h3>
                            <p className="text-xs text-slate-300 leading-relaxed">
                              Work with confidence using escrow-protected payments. Sponsoring MNCs and employers pre-fund each milestone before you start coding, ensuring guaranteed payouts.
                            </p>
                          </div>

                          <div className="bg-[#09090b] border border-white/5 p-4 rounded-xl space-y-3.5">
                            <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wider font-mono">SUPPORTED DISPATCH GATEWAYS</span>
                            
                            <div className="grid grid-cols-2 gap-2.5">
                              {[
                                { name: "Stripe", fee: "Instant Transfer", color: "text-indigo-400" },
                                { name: "PayPal", fee: "Global Payouts", color: "text-sky-400" },
                                { name: "Razorpay", fee: "Direct Bank", color: "text-indigo-500" },
                                { name: "UPI Auto", fee: "Real-time Payout", color: "text-emerald-400" }
                              ].map((gw, idx) => (
                                <div key={idx} className="p-2.5 bg-[#141416] border border-white/5 rounded-lg text-xs flex flex-col">
                                  <span className={`font-bold ${gw.color}`}>{gw.name}</span>
                                  <span className="text-[9px] text-slate-500 mt-0.5">{gw.fee}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="space-y-3 pt-4 border-t border-white/5">
                          <div className="flex items-center gap-2.5 text-xs text-slate-400">
                            <div className="p-1.5 rounded-full bg-slate-800 text-slate-300 shrink-0">
                              <Shield className="w-3.5 h-3.5" />
                            </div>
                            <span>Dual-signature contracts prevent payment disputes.</span>
                          </div>
                          
                          <button 
                            onClick={() => {
                              setViewMode("ai-workspace");
                              setActiveWorkspaceTool("draft-generator");
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                            className="w-full bg-transparent hover:bg-white/5 border border-white/10 hover:border-white/15 text-slate-300 hover:text-white py-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
                          >
                            <span>Explore Contract Drafter</span>
                            <ArrowUpRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* Core Platform Mission About Section */}
                  <div className="bg-white/[0.02] border border-white/5 rounded-xl p-6 sm:p-8 space-y-4 max-w-4xl mx-auto">
                    <h3 className="text-lg font-bold text-white font-display">About FreelanceX.ai</h3>
                    <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                      FreelanceX.ai is designed to solve the critical friction points of modern tech recruiting. Traditional freelance portals suffer from slow candidate vetting and high payment risks. By combining state-of-the-art Generative AI matching algorithms, automated resume parsing trackers, real-time mock technical interview pipelines, and robust dual-signature secure escrow protections, we provide a unified digital environment where certified CRM and frontend experts connect instantly with leading corporations.
                    </p>
                  </div>
                </div>
              )}

              {/* Browse Jobs Page */}
              {viewMode === "jobs" && (
                <div className="space-y-8 animate-in fade-in duration-300">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-white/5 pb-6">
                    <div className="space-y-1">
                      <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 text-[10px] font-bold border border-indigo-500/20 font-mono uppercase tracking-wider">
                        💼 Live Global Job Feed
                      </div>
                      <h2 className="text-3xl font-black text-white font-display tracking-tight">Browse Open Positions</h2>
                      <p className="text-xs text-slate-400">Discover premium freelance and contract work pre-vetted and backed by secure escrows.</p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-1 rounded font-mono font-bold">
                        ★ {jobs.length} Positions Available
                      </span>
                      <span className="text-[10px] bg-slate-800 text-slate-400 border border-white/5 px-2 py-1 rounded font-mono">
                        Direct Sponsor: JEEVA V
                      </span>
                    </div>
                  </div>

                  {/* Search and Filters row */}
                  <div className="bg-[#141416] p-4 rounded-xl border border-white/5 grid grid-cols-1 md:grid-cols-3 gap-3">
                    {/* Search field */}
                    <div className="relative">
                      <Briefcase className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                      <input
                        type="text"
                        placeholder="Search job title, company, skills..."
                        value={jobsSearchQuery}
                        onChange={(e) => setJobsSearchQuery(e.target.value)}
                        className="w-full bg-[#09090b] border border-white/10 rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors font-sans"
                      />
                    </div>

                    {/* Tech domain filter */}
                    <div>
                      <select
                        value={jobsDomainFilter}
                        onChange={(e) => setJobsDomainFilter(e.target.value)}
                        className="w-full bg-[#09090b] border border-white/10 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 transition-colors"
                      >
                        <option value="all">All Domains (Vetted)</option>
                        <option value="ai">Artificial Intelligence & ML</option>
                        <option value="webdev">Web & Software Development</option>
                        <option value="crm">Salesforce & CRM Clouds</option>
                        <option value="emerging">Emerging Tech & Blockchain</option>
                      </select>
                    </div>

                    {/* Job type filter */}
                    <div>
                      <select
                        value={jobsTypeFilter}
                        onChange={(e) => setJobsTypeFilter(e.target.value)}
                        className="w-full bg-[#09090b] border border-white/10 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 transition-colors"
                      >
                        <option value="all">All Contract Types</option>
                        <option value="Full-time">Full-time Contract</option>
                        <option value="Freelance">Freelance Milestone</option>
                        <option value="Contract">Direct Corp-to-Corp</option>
                      </select>
                    </div>
                  </div>

                  {/* Master Detail Grid */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    {/* Left pane: Jobs list */}
                    <div className="lg:col-span-5 space-y-3 max-h-[700px] overflow-y-auto pr-2">
                      {(() => {
                        const filtered = jobs.filter(job => {
                          const matchesSearch = 
                            job.title.toLowerCase().includes(jobsSearchQuery.toLowerCase()) ||
                            job.company.toLowerCase().includes(jobsSearchQuery.toLowerCase()) ||
                            job.skillsRequired.some(s => s.toLowerCase().includes(jobsSearchQuery.toLowerCase())) ||
                            job.description.toLowerCase().includes(jobsSearchQuery.toLowerCase());
                          
                          const matchesDomain = jobsDomainFilter === "all" || job.domain === jobsDomainFilter;
                          const matchesType = jobsTypeFilter === "all" || job.type === jobsTypeFilter;
                          
                          return matchesSearch && matchesDomain && matchesType;
                        });

                        if (filtered.length === 0) {
                          return (
                            <div className="bg-[#141416]/50 border border-white/5 rounded-xl p-8 text-center space-y-2">
                              <p className="text-slate-400 text-xs font-semibold">No matching job listings found.</p>
                              <p className="text-slate-500 text-[11px]">Try adjusting your search criteria or domain filters.</p>
                              <button
                                onClick={() => { setJobsSearchQuery(""); setJobsDomainFilter("all"); setJobsTypeFilter("all"); }}
                                className="text-indigo-400 hover:text-indigo-300 text-xs font-bold underline transition-colors"
                              >
                                Clear all filters
                              </button>
                            </div>
                          );
                        }

                        return filtered.map((job) => {
                          const isSelected = activeDetailedJob?.id === job.id;
                          return (
                            <div
                              key={job.id}
                              onClick={() => {
                                setActiveDetailedJob(job);
                                setJobBidSuccess(false);
                              }}
                              className={`p-4 rounded-xl border transition-all cursor-pointer text-left relative ${
                                isSelected 
                                  ? "bg-[#18181b] border-indigo-500/50 shadow-md shadow-indigo-500/5" 
                                  : "bg-[#141416] border-white/5 hover:border-white/10 hover:bg-[#151518]"
                              }`}
                            >
                              <div className="space-y-2.5">
                                <div className="flex justify-between items-start gap-2">
                                  <div>
                                    <h4 className="text-xs font-black text-slate-500 uppercase tracking-widest font-mono">{job.company}</h4>
                                    <h3 className="text-sm font-bold text-white tracking-tight mt-0.5">{job.title}</h3>
                                  </div>
                                  <span className="text-xs font-extrabold text-indigo-400 font-mono whitespace-nowrap bg-indigo-500/5 border border-indigo-500/10 px-2 py-0.5 rounded">
                                    {currency === "USD" ? `$${job.budgetUsd.toLocaleString()}` : `₹${(job.budgetUsd * 83).toLocaleString()}`}
                                  </span>
                                </div>

                                <div className="flex flex-wrap gap-1.5 pt-1">
                                  <span className="text-[9px] bg-slate-800 text-slate-300 px-1.5 py-0.2 rounded font-semibold">{job.type}</span>
                                  <span className="text-[9px] bg-slate-800 text-slate-300 px-1.5 py-0.2 rounded font-semibold">{job.location}</span>
                                  <span className="text-[9px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.2 rounded font-mono font-bold uppercase">Escrow Hold</span>
                                </div>

                                <div className="flex flex-wrap gap-1">
                                  {job.skillsRequired.slice(0, 3).map((skill, idx) => (
                                    <span key={idx} className="text-[9px] bg-indigo-950/40 text-indigo-300 px-1.5 py-0.2 rounded border border-indigo-500/10 font-mono">
                                      {skill}
                                    </span>
                                  ))}
                                  {job.skillsRequired.length > 3 && (
                                    <span className="text-[9px] text-slate-500 font-bold px-1 py-0.2 font-mono">
                                      +{job.skillsRequired.length - 3} more
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          );
                        });
                      })()}
                    </div>

                    {/* Right pane: Job details */}
                    <div className="lg:col-span-7">
                      {(() => {
                        const job = activeDetailedJob || (jobs.length > 0 ? jobs[0] : null);
                        if (!job) {
                          return (
                            <div className="bg-[#141416]/40 border border-white/5 rounded-2xl p-12 text-center text-slate-500 font-medium">
                              Select a job listing to view the description and place your contract bid.
                            </div>
                          );
                        }

                        return (
                          <div className="bg-[#141416] border border-white/5 rounded-2xl p-6 space-y-6 relative overflow-hidden text-left">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />
                            
                            <div className="space-y-4">
                              <div className="flex flex-wrap justify-between items-start gap-4 pb-4 border-b border-white/5">
                                <div className="space-y-1">
                                  <span className="text-[10px] bg-indigo-500/10 text-indigo-400 font-bold px-2 py-0.5 rounded border border-indigo-500/20 font-mono uppercase tracking-widest">
                                    {job.company}
                                  </span>
                                  <h3 className="text-xl font-bold text-white font-display tracking-tight">{job.title}</h3>
                                  <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-slate-400 font-medium pt-1">
                                    <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-slate-500" /> {job.location}</span>
                                    <span className="flex items-center gap-1"><Briefcase className="w-3.5 h-3.5 text-slate-500" /> {job.type}</span>
                                  </div>
                                </div>

                                <div className="bg-[#09090b] border border-white/5 p-3 rounded-xl text-left sm:text-right min-w-[140px]">
                                  <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider font-mono block">CONTRACT BUDGET</span>
                                  <span className="text-lg font-black text-emerald-400 font-mono block mt-0.5">
                                    {currency === "USD" ? `$${job.budgetUsd.toLocaleString()}` : `₹${(job.budgetUsd * 83).toLocaleString()}`}
                                  </span>
                                  <span className="text-[9px] text-slate-500 block uppercase font-mono mt-0.5">Dual-escrow secure</span>
                                </div>
                              </div>

                              <div className="space-y-3.5">
                                <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">Job Description</h4>
                                <p className="text-xs text-slate-300 leading-relaxed font-sans">{job.description}</p>
                              </div>

                              <div className="space-y-3.5 pt-2">
                                <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">Required Core Technical Competencies</h4>
                                <div className="flex flex-wrap gap-2">
                                  {job.skillsRequired.map((skill, idx) => (
                                    <span key={idx} className="text-xs bg-indigo-500/5 text-indigo-300 border border-indigo-500/10 px-2.5 py-1 rounded-lg font-mono">
                                      {skill}
                                    </span>
                                  ))}
                                </div>
                              </div>

                              <div className="bg-[#09090b] border border-white/5 p-4 rounded-xl space-y-2.5">
                                <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                                  <ShieldCheck className="w-4 h-4" />
                                  <span>Secure Escrow Protection Active</span>
                                </div>
                                <p className="text-[11px] text-slate-400 leading-relaxed">
                                  Upon milestone agreement, this client pre-deposits the funds into our automated contract register sponsored by <strong className="text-white">JEEVA V</strong>. Payouts are dispatched instantly to your registered Razorpay or UPI address upon review.
                                </p>
                              </div>

                              <div className="pt-4 border-t border-white/5">
                                {jobBidSuccess ? (
                                  <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-4 flex items-start gap-3 text-emerald-400 animate-in zoom-in duration-200">
                                    <ShieldCheck className="w-5 h-5 shrink-0 mt-0.5" />
                                    <div className="space-y-1">
                                      <h4 className="text-xs font-bold">Proposal Dispatched Successfully!</h4>
                                      <p className="text-[11px] text-emerald-500/80 leading-normal">
                                        Your bid of <strong>{currency === "USD" ? `$${jobBidAmount}` : `₹${jobBidAmount}`}</strong> has been registered on the server. You can monitor progress on your <strong>Simulated Portals</strong> under <em>Student/Freelancer Hub</em>.
                                      </p>
                                    </div>
                                  </div>
                                ) : jobBidModalOpen ? (
                                  <form onSubmit={(e) => {
                                    e.preventDefault();
                                    if (!jobBidAmount || !jobBidProposal) {
                                      alert("Please enter a valid bid amount and custom proposal statement.");
                                      return;
                                    }
                                    setJobBidSuccess(true);
                                    setJobBidModalOpen(false);
                                  }} className="bg-[#09090b] p-4 rounded-xl border border-white/5 space-y-4 animate-in slide-in-from-bottom duration-200">
                                    <div className="flex justify-between items-center">
                                      <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">Submit Contract Bid</h4>
                                      <button 
                                        type="button" 
                                        onClick={() => setJobBidModalOpen(false)}
                                        className="text-slate-500 hover:text-slate-300 text-xs"
                                      >
                                        Cancel
                                      </button>
                                    </div>

                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                      <div className="space-y-1">
                                        <label className="text-[10px] text-slate-400 block font-mono font-bold uppercase">YOUR BID AMOUNT ({currency})</label>
                                        <input
                                          type="text"
                                          placeholder={currency === "USD" ? "e.g., 2500" : "e.g., 200000"}
                                          value={jobBidAmount}
                                          onChange={(e) => setJobBidAmount(e.target.value)}
                                          className="w-full bg-[#141416] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500"
                                          required
                                        />
                                      </div>
                                      <div className="space-y-1">
                                        <label className="text-[10px] text-slate-400 block font-mono font-bold uppercase">ESTIMATED DELIVERY</label>
                                        <input
                                          type="text"
                                          defaultValue="14 Days"
                                          className="w-full bg-[#141416]/50 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-slate-400 cursor-not-allowed focus:outline-none"
                                          disabled
                                        />
                                      </div>
                                    </div>

                                    <div className="space-y-1">
                                      <label className="text-[10px] text-slate-400 block font-mono font-bold uppercase">PROPOSAL LETTER & APPROACH DESCRIPTION</label>
                                      <textarea
                                        rows={3}
                                        placeholder="Outline your tech stack choice, Salesforce certifications, or relevant API integration experience..."
                                        value={jobBidProposal}
                                        onChange={(e) => setJobBidProposal(e.target.value)}
                                        className="w-full bg-[#141416] border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-sans"
                                        required
                                      />
                                    </div>

                                    <button
                                      type="submit"
                                      className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 rounded-lg text-xs transition-colors"
                                    >
                                      Submit Proposal Letter (₹0 Fees)
                                    </button>
                                  </form>
                                ) : (
                                  <button
                                    onClick={() => {
                                      setJobBidAmount(currency === "USD" ? job.budgetUsd.toString() : (job.budgetUsd * 83).toString());
                                      setJobBidProposal(`Hi team! I am highly interested in this role. I have extensive experience with ${job.skillsRequired.join(", ")}. I will deliver high performance code backed by complete documentation.`);
                                      setJobBidModalOpen(true);
                                    }}
                                    className="w-full bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-extrabold py-3 rounded-xl text-xs transition-all cursor-pointer shadow-lg shadow-indigo-500/10 flex items-center justify-center gap-2 group"
                                  >
                                    <span>Submit Bid Proposal</span>
                                    <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                </div>
              )}

              {/* Contact Us Page */}
              {viewMode === "contact" && (
                <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300">
                  <div className="text-center space-y-2">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 text-xs font-bold border border-indigo-500/20 font-mono uppercase tracking-wide">
                      ✉ Support Dispatch & Sponsoring Gateway
                    </div>
                    <h2 className="text-3xl md:text-5xl font-black text-white font-display tracking-tight">Get in Touch</h2>
                    <p className="text-slate-400 text-xs sm:text-sm max-w-xl mx-auto">Have queries about secure escrows, MNC placement drives, or corporate sponsorships? Direct routing is online.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                    {/* Left: Contact Form Card */}
                    <div className="md:col-span-7 bg-[#141416] border border-white/5 rounded-2xl p-6 relative overflow-hidden text-left">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />
                      
                      {contactFormSubmitted ? (
                        <div className="text-center py-10 space-y-4 animate-in zoom-in duration-200">
                          <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                            <ShieldCheck className="w-6 h-6 animate-pulse" />
                          </div>
                          <div className="space-y-1">
                            <h3 className="text-lg font-bold text-white">Ticket Dispatched Successfully!</h3>
                            <p className="text-xs text-slate-400">Your inquiry has been directly routed onto the primary mailbox.</p>
                          </div>
                          
                          <div className="bg-[#09090b] border border-white/5 p-4 rounded-xl text-left space-y-2 max-w-sm mx-auto font-mono text-[10px] text-slate-400">
                            <div><span className="text-slate-500">TICKET_ID:</span> FX-{Math.floor(100000 + Math.random() * 900000)}</div>
                            <div><span className="text-slate-500">RECIPIENT:</span> gopiiniyavan@gmail.com</div>
                            <div><span className="text-slate-500">SPONSOR:</span> JEEVA V (Direct Placement Escalation)</div>
                            <div><span className="text-slate-500">RESPONSE_ETA:</span> &lt; 15 Minutes (Active Working Hours)</div>
                          </div>

                          <button
                            onClick={() => {
                              setContactFormSubmitted(false);
                              setContactFormName("");
                              setContactFormSubject("");
                              setContactFormText("");
                            }}
                            className="text-xs font-bold text-indigo-400 hover:text-indigo-300 underline transition-colors"
                          >
                            Submit another support request
                          </button>
                        </div>
                      ) : (
                        <form onSubmit={(e) => {
                          e.preventDefault();
                          if (!contactFormName || !contactFormEmail || !contactFormText) {
                            alert("Please fill out all the required inputs.");
                            return;
                          }
                          setContactFormLoading(true);
                          setTimeout(() => {
                            setContactFormLoading(false);
                            setContactFormSubmitted(true);
                          }, 1500);
                        }} className="space-y-4">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div className="space-y-1">
                              <label className="text-[10px] text-slate-400 block font-mono font-bold uppercase">YOUR FULL NAME *</label>
                              <input
                                type="text"
                                placeholder="e.g., Aravind Nair"
                                value={contactFormName}
                                onChange={(e) => setContactFormName(e.target.value)}
                                className="w-full bg-[#09090b] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 transition-colors"
                                required
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] text-slate-400 block font-mono font-bold uppercase">EMAIL ADDRESS *</label>
                              <input
                                type="email"
                                placeholder="e.g., professional@freelancex.ai"
                                value={contactFormEmail}
                                onChange={(e) => setContactFormEmail(e.target.value)}
                                className="w-full bg-[#09090b] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 transition-colors"
                                required
                              />
                            </div>
                          </div>

                          <div className="space-y-1">
                            <label className="text-[10px] text-slate-400 block font-mono font-bold uppercase">INQUIRY CATEGORY</label>
                            <select
                              value={contactFormCategory}
                              onChange={(e) => setContactFormCategory(e.target.value)}
                              className="w-full bg-[#09090b] border border-white/10 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 transition-colors"
                            >
                              <option value="General Support Inquiry">General Support Inquiry</option>
                              <option value="Escrow Hold Discrepancy">Escrow Hold Discrepancy</option>
                              <option value="MNC Placement Program">MNC Placement Program</option>
                              <option value="Direct Enterprise Sponsorship">Direct Enterprise Sponsorship</option>
                            </select>
                          </div>

                          <div className="space-y-1">
                            <label className="text-[10px] text-slate-400 block font-mono font-bold uppercase">SUBJECT *</label>
                            <input
                              type="text"
                              placeholder="e.g., Connecting Razorpay account or Salesforce Vetting inquiries"
                              value={contactFormSubject}
                              onChange={(e) => setContactFormSubject(e.target.value)}
                              className="w-full bg-[#09090b] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 transition-colors"
                              required
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-[10px] text-slate-400 block font-mono font-bold uppercase">MESSAGE CONTENT *</label>
                            <textarea
                              rows={5}
                              placeholder="Please describe your query in detail. Be as clear as possible..."
                              value={contactFormText}
                              onChange={(e) => setContactFormText(e.target.value)}
                              className="w-full bg-[#09090b] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 transition-colors font-sans"
                              required
                            />
                          </div>

                          <button
                            type="submit"
                            disabled={contactFormLoading}
                            className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-800 text-white font-bold py-3 rounded-lg text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                          >
                            {contactFormLoading ? (
                              <>
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                <span>Routing Support Ticket...</span>
                              </>
                            ) : (
                              <span>Dispatch Secure Ticket</span>
                            )}
                          </button>
                        </form>
                      )}
                    </div>

                    {/* Right: Direct Contacts Info */}
                    <div className="md:col-span-5 space-y-6 text-left">
                      {/* Direct Support Card */}
                      <div className="bg-[#141416]/70 border border-white/5 rounded-2xl p-5 space-y-4">
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">Direct Escalations</h4>
                        
                        <div className="space-y-3.5 text-xs text-slate-300">
                          <div className="space-y-1">
                            <span className="text-[10px] text-slate-500 uppercase tracking-widest block font-mono">Primary Mailbox</span>
                            <a href="mailto:gopiiniyavan@gmail.com" className="text-sm font-semibold text-indigo-400 hover:underline">
                              gopiiniyavan@gmail.com
                            </a>
                          </div>

                          <div className="space-y-1">
                            <span className="text-[10px] text-slate-500 uppercase tracking-widest block font-mono">Placement Sponsor</span>
                            <span className="font-semibold text-white block">
                              JEEVA V
                            </span>
                          </div>

                          <div className="space-y-1">
                            <span className="text-[10px] text-slate-500 uppercase tracking-widest block font-mono">Average Response SLA</span>
                            <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                              &lt; 15 Minutes
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Global Hubs Card */}
                      <div className="bg-[#141416]/50 border border-white/5 rounded-2xl p-5 space-y-3">
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">Sponsor Offices</h4>
                        
                        <div className="space-y-3 text-xs text-slate-400">
                          <div>
                            <strong className="text-slate-300 text-xs block">India Headquarter Hub:</strong>
                            <p className="mt-0.5">Prestige Tech Park, Outer Ring Road, Kadubeesanahalli, Bengaluru, Karnataka 560103</p>
                          </div>
                          <div className="pt-2 border-t border-white/5">
                            <strong className="text-slate-300 text-xs block">US Sponsoring Hub:</strong>
                            <p className="mt-0.5">Salesforce Tower, 415 Mission St, San Francisco, CA 94105, United States</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Help Center Page */}
              {viewMode === "help" && (
                <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300">
                  <div className="text-center space-y-2">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 text-xs font-bold border border-indigo-500/20 font-mono uppercase tracking-wide">
                      ❔ Help & Knowledge Base
                    </div>
                    <h2 className="text-3xl md:text-5xl font-black text-white font-display tracking-tight">How can we help?</h2>
                    <p className="text-slate-400 text-xs sm:text-sm max-w-xl mx-auto">Instant guides on secure payments, multi-sig escrow setups, Salesforce integrations, and vetted placement pipelines.</p>
                  </div>

                  {/* Search and category filters */}
                  <div className="bg-[#141416] p-4 rounded-xl border border-white/5 space-y-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                      <input
                        type="text"
                        placeholder="Search answers by typing keywords (e.g. escrow, Razorpay, Jeeva, Salesforce)..."
                        value={helpSearch}
                        onChange={(e) => setHelpSearch(e.target.value)}
                        className="w-full bg-[#09090b] border border-white/10 rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors font-sans"
                      />
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {[
                        { id: "all", label: "All Guides" },
                        { id: "general", label: "General & Branding" },
                        { id: "payments", label: "Escrows & Payments" },
                        { id: "vetting", label: "Salesforce & Vetting" },
                        { id: "recruiting", label: "MNC Placement Drives" }
                      ].map((cat) => (
                        <button
                          key={cat.id}
                          onClick={() => setHelpCategory(cat.id)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                            helpCategory === cat.id
                              ? "bg-indigo-600 text-white shadow"
                              : "bg-[#09090b] text-slate-400 hover:text-slate-200 border border-white/5"
                          }`}
                        >
                          {cat.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Interactive Accordion FAQs */}
                  <div className="space-y-3.5 text-left">
                    {(() => {
                      const FAQS = [
                        {
                          id: "faq-1",
                          cat: "general",
                          q: "What is FreelanceX.ai and who sponsors it?",
                          a: "FreelanceX.ai is an advanced, high-performance marketplace tailored specifically for enterprise-level technical freelancers (specializing in CRM, Salesforce LWC, AI Workspaces, and full-stack environments). The entire application's operational costs and commission-free pipelines are fully sponsored by JEEVA V. Our direct support and ticket handling are actively maintained via gopiiniyavan@gmail.com."
                        },
                        {
                          id: "faq-2",
                          cat: "payments",
                          q: "How does the Commission-Free Secure Escrow system work?",
                          a: "Unlike traditional platforms that charge a hefty 10-20% fee, we charge 0% commission. When a client hires you for a contract, they pre-deposit 100% of the milestone funds into our escrow module. Once you submit the code deliverables, these funds are instantly released to your linked bank account, Razorpay wallet, or UPI address. The payment rails are secure, instant, and verified automatically via simulated multi-sig logs."
                        },
                        {
                          id: "faq-3",
                          cat: "vetting",
                          q: "How do I take technical assessments and get the 'Verified Professional' Badge?",
                          a: "You can navigate to our Simulated Portals under the 'Student Hub' tab or click on the 'AI Workspaces' from the sidebar navigation. There you can build custom mock resumes, run deep assessment reviews, and utilize the AI Interview Coach. Scoring above 85% on these assessments triggers automatic verification status, visible on the Talent listings."
                        },
                        {
                          id: "faq-4",
                          cat: "recruiting",
                          q: "What are the direct-hire MNC placement partnerships?",
                          a: "Through direct funding and sponsorship by JEEVA V, FreelanceX.ai partners with top-tier tech giants (including Google Cloud, Salesforce Systems, and MuleSoft). Pre-vetted freelancers with certified profiles receive direct interview invites and fast-tracked placements, with typical package ranges starting at ₹2,200,000 to ₹4,800,000 per annum."
                        },
                        {
                          id: "faq-5",
                          cat: "payments",
                          q: "Can I switch the default currency for rates and payouts?",
                          a: "Yes! At the top header of the platform, you can switch seamlessly between USD ($) and Indian Rupees (₹). The exchange calculation is done automatically at a fixed rate of ₹83 per USD across the entire application interface, including portfolios, job listings, and bid calculations."
                        },
                        {
                          id: "faq-6",
                          cat: "general",
                          q: "Who should I contact if there is a payment or contract dispute?",
                          a: "Our dispute desk is monitored 24/7 by dedicated placement and support specialists. You can submit a support ticket directly via the 'Contact Us' tab from the sidebar, or send an email with your contract details to gopiiniyavan@gmail.com. Discrepancy resolutions are typically completed within 15 minutes."
                        }
                      ];

                      const filteredFaqs = FAQS.filter(faq => {
                        const matchesSearch = 
                          faq.q.toLowerCase().includes(helpSearch.toLowerCase()) ||
                          faq.a.toLowerCase().includes(helpSearch.toLowerCase());
                        
                        const matchesCategory = helpCategory === "all" || faq.cat === helpCategory;
                        
                        return matchesSearch && matchesCategory;
                      });

                      if (filteredFaqs.length === 0) {
                        return (
                          <div className="bg-[#141416]/50 border border-white/5 rounded-xl p-8 text-center text-slate-500 font-medium">
                            No matching FAQs found. Please type a different keyword.
                          </div>
                        );
                      }

                      return filteredFaqs.map((faq) => {
                        const isOpen = expandedFaqId === faq.id;
                        return (
                          <div
                            key={faq.id}
                            className="bg-[#141416] border border-white/5 rounded-xl overflow-hidden transition-all duration-200"
                          >
                            <button
                              onClick={() => setExpandedFaqId(isOpen ? null : faq.id)}
                              className="w-full px-5 py-4 flex items-center justify-between gap-4 text-left hover:bg-[#18181b] transition-colors"
                            >
                              <span className="text-xs sm:text-sm font-bold text-white tracking-tight">{faq.q}</span>
                              <span className="text-xs text-indigo-400 font-bold shrink-0">
                                {isOpen ? "✕ Close" : "＋ Expand"}
                              </span>
                            </button>
                            
                            {isOpen && (
                              <div className="px-5 pb-5 pt-1 border-t border-white/5 bg-[#09090b]/40">
                                <p className="text-xs text-slate-300 leading-relaxed font-sans">{faq.a}</p>
                              </div>
                            )}
                          </div>
                        );
                      });
                    })()}
                  </div>

                  {/* Redirection widget */}
                  <div className="bg-gradient-to-r from-indigo-950/20 via-[#141416] to-indigo-950/20 p-6 rounded-2xl border border-indigo-500/20 text-center space-y-4">
                    <h3 className="text-base font-bold text-white font-display">Still have unanswered questions?</h3>
                    <p className="text-xs text-slate-400 max-w-lg mx-auto">Get in touch directly with support desk. Sponsoring coordinators are active and ready to troubleshoot any issue in real-time.</p>
                    <div className="flex justify-center gap-3">
                      <button
                        onClick={() => { setViewMode("contact"); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                        className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-4 py-2 rounded-lg text-xs transition-colors"
                      >
                        Contact support desk
                      </button>
                      <a
                        href="mailto:gopiiniyavan@gmail.com"
                        className="bg-transparent border border-white/10 hover:bg-white/5 text-slate-300 hover:text-white font-bold px-4 py-2 rounded-lg text-xs transition-all flex items-center gap-1"
                      >
                        gopiiniyavan@gmail.com
                      </a>
                    </div>
                  </div>
                </div>
              )}

              {/* 404 Route Page */}
              {viewMode === "404" && (
                <div className="max-w-md mx-auto text-center py-16 space-y-6 animate-in zoom-in-95 duration-200">
                  <div className="space-y-2">
                    <h1 className="text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 to-indigo-400 font-mono tracking-tight select-none">404</h1>
                    <h2 className="text-xl font-bold text-white font-display">Discrepancy: Route Not Found</h2>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      The URL route hash you requested does not map onto any active vetting or placement components. Security validation has intercepted this request.
                    </p>
                  </div>

                  <div className="bg-[#141416] p-4 rounded-xl border border-white/5 text-left font-mono text-[10px] text-slate-500 space-y-1.5">
                    <div><span className="text-indigo-400 font-semibold">SECURITY_ALERT:</span> 0x8F590_DISPATCH_FAIL</div>
                    <div><span className="text-indigo-400 font-semibold">RESOLVER_URI:</span> {window.location.hash || "#/"}</div>
                    <div><span className="text-indigo-400 font-semibold">SYSTEM_SPONSOR:</span> JEEVA V (Fast Escrows)</div>
                  </div>

                  <button
                    onClick={() => { setViewMode("explore"); }}
                    className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-lg text-xs transition-colors shadow-lg shadow-indigo-500/15 cursor-pointer"
                  >
                    Return to Talent & Jobs Explore Dashboard
                  </button>
                </div>
              )}

              {/* ENTERPRISE FOOTER */}
              <footer className="border-t border-white/5 bg-[#0b0b0d] mt-16 pt-12 pb-8 px-4 sm:px-6 rounded-xl space-y-10" id="platform-enterprise-footer">
                {/* Stats Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 bg-[#141416]/50 rounded-xl border border-white/5">
                  {[
                    { value: "10M+", label: "Active Freelancers", color: "text-indigo-400" },
                    { value: "500K+", label: "Companies Hiring", color: "text-purple-400" },
                    { value: "100+", label: "Tech Domains", color: "text-emerald-400" },
                    { value: "₹200Cr+", label: "Paid to Freelancers", color: "text-amber-400" }
                  ].map((stat, idx) => (
                    <div key={idx} className="text-center space-y-1">
                      <span className={`text-2xl sm:text-3xl font-extrabold block tracking-tight ${stat.color}`}>{stat.value}</span>
                      <span className="text-[10px] sm:text-xs text-slate-500 font-medium uppercase tracking-wider">{stat.label}</span>
                    </div>
                  ))}
                </div>

                {/* Links & Contact Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
                  {/* Col 1 */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">For Freelancers</h4>
                    <ul className="space-y-2 text-xs text-slate-400">
                      <li><button onClick={() => { setViewMode("jobs"); window.scrollTo({ top: 0, behavior: "smooth" }); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Browse Jobs</button></li>
                      <li><button onClick={() => { setViewMode("dashboards"); setIsDashboardLoggedIn(true); setActiveDashboardTab("freelancer"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Create Profile</button></li>
                      <li><button onClick={() => { setViewMode("ai-workspace"); setActiveWorkspaceTool("resume-parser"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">AI Resume Builder</button></li>
                      <li><button onClick={() => { setViewMode("ai-workspace"); setActiveWorkspaceTool("interview-coach"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Skill Assessments</button></li>
                      <li><button onClick={() => { setViewMode("ai-workspace"); setActiveWorkspaceTool("draft-generator"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Portfolio Builder</button></li>
                      <li><button onClick={() => { setViewMode("dashboards"); setIsDashboardLoggedIn(true); setActiveDashboardTab("student"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Certifications</button></li>
                      <li><button onClick={() => { setViewMode("ai-workspace"); setActiveWorkspaceTool("ai-suite-directory"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Learning Paths</button></li>
                    </ul>
                  </div>

                  {/* Col 2 */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">For Companies</h4>
                    <ul className="space-y-2 text-xs text-slate-400">
                      <li><button onClick={() => { setViewMode("dashboards"); setIsDashboardLoggedIn(true); setActiveDashboardTab("company"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Post a Job</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("all"); setSearchQuery(""); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Browse Talent</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("all"); setSearchQuery("Solutions"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Companies Directory</button></li>
                      <li><button onClick={() => { setViewMode("ai-workspace"); setActiveWorkspaceTool("search"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">AI Candidate Ranking</button></li>
                      <li><button onClick={() => { setViewMode("dashboards"); setIsDashboardLoggedIn(true); setActiveDashboardTab("company"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Hiring Dashboard</button></li>
                      <li><button onClick={() => { setViewMode("dashboards"); setIsDashboardLoggedIn(true); setActiveDashboardTab("admin"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Background Verification</button></li>
                      <li><button onClick={() => { setViewMode("dashboards"); setIsDashboardLoggedIn(true); setActiveDashboardTab("recruiter"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Recruiter Tools</button></li>
                    </ul>
                  </div>

                  {/* Col 3 */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">Technologies</h4>
                    <ul className="space-y-2 text-xs text-slate-400">
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("ai"); setSearchQuery(""); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer font-medium">AI & Machine Learning</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("webdev"); setSearchQuery(""); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer font-medium">Web Development</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("emerging"); setSearchQuery("Blockchain"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer font-medium">Blockchain & Web3</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("emerging"); setSearchQuery("Cloud"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer font-medium">Cloud Computing</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("crm"); setSearchQuery(""); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer font-medium">Salesforce & CRM</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("emerging"); setSearchQuery("DevOps"); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer font-medium">DevOps</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("all"); setSearchQuery(""); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer text-indigo-400 font-semibold">All 100+ Domains</button></li>
                    </ul>
                  </div>

                  {/* Col 4 */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">Platform</h4>
                    <ul className="space-y-2 text-xs text-slate-400">
                      <li><button onClick={() => { setViewMode("about"); window.scrollTo({ top: 0, behavior: "smooth" }); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">About FreelanceX</button></li>
                      <li><button onClick={() => alert("Blog Hub: Currently displaying archived entries for Salesforce Agentforce release & Next.js 15 template styling.")} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Blog</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setSelectedDomain("all"); setSearchQuery(""); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Companies</button></li>
                      <li><button onClick={() => alert("Welcome to the Community board! Start chatting with local tech specialists using our persistent AI Copilot on the bottom-right corner.")} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Community</button></li>
                      <li><button onClick={() => { setViewMode("explore"); setTimeout(() => { const el = document.getElementById("mock-challenges-section"); if (el) el.scrollIntoView({ behavior: "smooth" }); }, 100); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Hackathons</button></li>
                      <li><button onClick={() => { setViewMode("help"); window.scrollTo({ top: 0, behavior: "smooth" }); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Help Center</button></li>
                      <li><button onClick={() => { setViewMode("contact"); window.scrollTo({ top: 0, behavior: "smooth" }); }} className="hover:text-indigo-400 transition-colors text-left cursor-pointer">Contact Us</button></li>
                    </ul>
                  </div>

                  {/* Col 5: Support / Have any queries? */}
                  <div className="col-span-2 lg:col-span-1 space-y-4 bg-[#141416] p-4 rounded-xl border border-white/5">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5 font-display">
                      <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
                      Have any queries?
                    </h4>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Reach out directly — we're happy to help.
                    </p>
                    <div className="space-y-1">
                      <a href="mailto:gopiiniyavan@gmail.com" className="text-xs font-mono text-indigo-400 hover:underline font-semibold block break-all">
                        gopiiniyavan@gmail.com
                      </a>
                      <span className="text-[9px] text-slate-500 block">Sponsor: JEEVA V</span>
                    </div>
                  </div>
                </div>

                {/* Sponsor & Escrow Payment Methods section (Downside) */}
                <div className="pt-6 border-t border-white/5 space-y-4" id="secure-payment-gateways-downside">
                  <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
                    <div className="space-y-1">
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5 font-mono">
                        <DollarSign className="w-4 h-4 text-emerald-400 animate-pulse" />
                        Platform Secure Payment & Escrow Gateways
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Our dual-signature smart contracts support direct instant dispatching across all global payment methods. Zero extra processing fees.
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 bg-[#141416]/60 px-4 py-2.5 rounded-xl border border-white/5">
                      {[
                        { name: "Visa / Mastercard", badge: "Direct" },
                        { name: "UPI AutoPay", badge: "INR" },
                        { name: "Stripe Escrow", badge: "MNCs" },
                        { name: "PayPal Global", badge: "USD" },
                        { name: "Razorpay Secure", badge: "Vetted" }
                      ].map((pay, i) => (
                        <button 
                          key={i} 
                          onClick={() => {
                            setUpiModalOpen(true);
                            setSelectedPaymentGateway(pay.name);
                            if (pay.badge === "INR" || pay.badge === "Vetted" || pay.badge === "MNCs") {
                              setUpiAmount("12500");
                            } else {
                              setUpiAmount("250");
                            }
                          }}
                          className="flex items-center gap-1.5 bg-[#09090b] hover:bg-[#141416] hover:border-indigo-500/30 px-2.5 py-1 rounded-md text-[10px] font-mono border border-white/5 cursor-pointer transition-all active:scale-95 group"
                          title={`Launch Secure ${pay.name} Escrow Portal`}
                        >
                          <span className="font-extrabold text-slate-300 group-hover:text-white transition-colors">{pay.name}</span>
                          <span className="text-[8px] bg-indigo-500/10 text-indigo-400 px-1 rounded border border-indigo-500/20 font-bold group-hover:bg-indigo-500/20 transition-colors">{pay.badge}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Legal & Author Signature Footer */}
                <div className="pt-6 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-[11px] text-slate-500">
                  <div className="space-y-1 text-center md:text-left">
                    <span>© 2026 FreelanceX, Inc. All rights reserved.</span>
                    <span className="block text-slate-400 font-semibold">Created by JEEVA V</span>
                  </div>

                  <div className="flex flex-wrap justify-center gap-4 text-slate-400">
                    <button onClick={() => alert("Privacy Policy Details: Fully secure database transactions under Indian & Global IT security norms.")} className="hover:text-white hover:underline transition-colors cursor-pointer">Privacy Policy</button>
                    <span>·</span>
                    <button onClick={() => alert("Terms of Service: Direct contracts are verified with secure multi-sig escrow systems.")} className="hover:text-white hover:underline transition-colors cursor-pointer">Terms of Service</button>
                    <span>·</span>
                    <button onClick={() => alert("Cookie Policy: Essential local browser cache storage only.")} className="hover:text-white hover:underline transition-colors cursor-pointer">Cookie Policy</button>
                    <span>·</span>
                    <button onClick={() => alert("Accessibility Policy: High-contrast palette designed for screen readers.")} className="hover:text-white hover:underline transition-colors cursor-pointer">Accessibility</button>
                  </div>
                </div>
              </footer>
            </div>
          )}
        </main>
      </div>

      {/* PERSISTENT AI CHAT DRAWER */}
      <AIChatDrawer />

      {/* DETAIL MODAL: FREELANCER DETAIL */}
      {selectedFreelancer && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-[#141416] card-border rounded-xl w-full max-w-2xl p-6 md:p-8 space-y-6 max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-200 glass-bg">
            <div className="flex justify-between items-start">
              <div className="flex gap-4">
                <img src={selectedFreelancer.avatar} alt={selectedFreelancer.name} className="w-16 h-16 rounded-lg object-cover border border-white/10 shrink-0" />
                <div>
                  <h3 className="text-xl font-bold text-white">{selectedFreelancer.name}</h3>
                  <p className="text-xs text-indigo-400 font-mono mt-0.5">{selectedFreelancer.title}</p>
                  <div className="flex items-center gap-2 mt-1.5 text-xs text-slate-400">
                    <MapPin className="w-3.5 h-3.5" />
                    {selectedFreelancer.location}
                    <span>•</span>
                    <strong className="text-slate-300">{selectedFreelancer.experience} Experience</strong>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSelectedFreelancer(null)}
                className="p-1 hover:bg-white/5 rounded text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Left col */}
              <div className="md:col-span-2 space-y-5">
                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-slate-500 uppercase">Consultant Bio</span>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{selectedFreelancer.bio}</p>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-500 uppercase block">Specialist Skills Stack</span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedFreelancer.skills.map((s, idx) => (
                      <span key={idx} className="px-2.5 py-0.5 bg-[#09090b] text-slate-400 border border-white/5 rounded text-xs font-mono">{s}</span>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-500 uppercase block">Accredited Certifications</span>
                  <div className="space-y-1.5">
                    {selectedFreelancer.certifications.map((c, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-slate-400">
                        <Award className="w-3.5 h-3.5 text-yellow-500 shrink-0" />
                        <span>{c}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right col: Contact / Hire Card */}
              <div className="space-y-4">
                <div className="bg-[#09090b] p-4 rounded-xl border border-white/10 space-y-4">
                  <div className="space-y-1 text-center">
                    <span className="text-slate-400 text-xs block">Hourly rate</span>
                    <span className="text-2xl font-black text-white">${selectedFreelancer.hourlyRate}/hr</span>
                    <span className="text-[10px] px-2 py-0.5 bg-indigo-950 text-indigo-400 rounded-full border border-indigo-900 block mt-1">{selectedFreelancer.availability}</span>
                  </div>

                  {contactSuccess ? (
                    <div className="p-3 bg-indigo-950/40 text-indigo-400 rounded-lg border border-indigo-500/30 text-center text-xs space-y-1 py-4">
                      <ShieldCheck className="w-6 h-6 mx-auto animate-bounce" />
                      <strong className="block">Message Dispatched!</strong>
                      <span className="text-[10px] opacity-80">Check your Recruiter dashboard.</span>
                    </div>
                  ) : (
                    <form onSubmit={handleContactSubmit} className="space-y-2.5">
                      <label className="block text-[11px] font-semibold text-slate-400">Secure Direct Message</label>
                      <textarea
                        rows={3}
                        required
                        value={contactMessage}
                        onChange={(e) => setContactMessage(e.target.value)}
                        placeholder={`e.g. Hi ${selectedFreelancer.name.split(" ")[0]}, we have a Salesforce task starting next week...`}
                        className="w-full bg-[#141416] border border-white/10 rounded-lg p-2.5 text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                      />
                      <button
                        type="submit"
                        className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 rounded-lg text-xs transition-all cursor-pointer shadow"
                      >
                        Send Secure Message
                      </button>
                    </form>
                  )}
                </div>

                <div className="flex gap-2 justify-center text-xs">
                  {selectedFreelancer.socials.github && (
                    <a href={`https://${selectedFreelancer.socials.github}`} target="_blank" rel="noreferrer" className="p-2 bg-[#09090b] border border-white/10 rounded-lg text-slate-400 hover:text-white transition-colors">
                      <Github className="w-4 h-4" />
                    </a>
                  )}
                  {selectedFreelancer.socials.linkedin && (
                    <a href={`https://${selectedFreelancer.socials.linkedin}`} target="_blank" rel="noreferrer" className="p-2 bg-[#09090b] border border-white/10 rounded-lg text-slate-400 hover:text-white transition-colors">
                      <Linkedin className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DETAIL MODAL: JOB DETAIL */}
      {selectedJob && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-[#141416] card-border rounded-xl w-full max-w-xl p-6 space-y-5 max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-200 glass-bg">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-bold text-white">{selectedJob.title}</h3>
                <span className="text-xs text-indigo-400 font-mono mt-0.5">{selectedJob.company} • {selectedJob.location}</span>
              </div>
              <button
                onClick={() => setSelectedJob(null)}
                className="p-1 hover:bg-white/5 rounded text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-[#09090b] rounded-lg border border-white/10 text-xs">
                <div>
                  <span className="text-slate-500 block">Rate / Pricing:</span>
                  <strong className="text-white text-sm">{selectedJob.rate}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">Target Budget:</span>
                  <strong className="text-indigo-400 text-sm">{selectedJob.budget}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">Contract Format:</span>
                  <span className="px-2 py-0.5 bg-[#141416] rounded font-semibold text-slate-400 border border-white/5 uppercase text-[10px] block mt-0.5">{selectedJob.type}</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-500 uppercase block">Project Specification</span>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{selectedJob.description}</p>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-500 uppercase block">Required Technical Accreditation</span>
                <div className="flex flex-wrap gap-1.5">
                  {selectedJob.skills.map((s, idx) => (
                    <span key={idx} className="px-2.5 py-0.5 bg-[#09090b] text-indigo-400 border border-white/5 rounded text-xs font-mono">{s}</span>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-white/10 flex justify-between items-center text-xs text-slate-500">
              <span>Posted {selectedJob.postedAt} • {selectedJob.proposals} proposals placed</span>
              <button
                onClick={() => {
                  alert("Simulated proposal submission registered in secure database. Check simulated freelancer bids page!");
                  setSelectedJob(null);
                }}
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2 rounded-lg font-bold transition-all shadow cursor-pointer"
              >
                Submit Proposal Template
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Help & Creator Support Widget */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3 font-sans" id="creator-support-widget">
        {supportOpen && (
          <div className="w-80 bg-[#141416] card-border rounded-xl p-5 shadow-2xl animate-in slide-in-from-bottom-5 duration-200 space-y-4">
            {/* Header */}
            <div className="flex justify-between items-start">
              <div className="space-y-0.5">
                <h4 className="font-bold text-sm text-white">SkillForge Partner Support</h4>
                <span className="text-[10px] text-indigo-400 font-mono tracking-wider font-semibold block uppercase">Direct Inquiry Hub</span>
              </div>
              <button
                onClick={() => setSupportOpen(false)}
                className="p-1 text-slate-500 hover:text-slate-300 rounded hover:bg-white/5 cursor-pointer transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content */}
            <p className="text-xs text-slate-400 leading-relaxed">
              Need partner onboarding, sponsorship details, or have technical queries? Contact the verified creator directly through this email:
            </p>

            {/* Verified Email Card */}
            <div className="p-3 bg-[#09090b] rounded-lg border border-white/5 space-y-1.5">
              <span className="text-[9px] text-slate-500 font-bold block uppercase">Direct Email Contact</span>
              <a
                href="mailto:gopiiniyavan@gmail.com"
                className="text-xs font-mono text-indigo-400 hover:underline hover:text-indigo-300 block break-all font-semibold"
              >
                gopiiniyavan@gmail.com
              </a>
            </div>

            {/* Short Active Inquiry Form */}
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                setSupportLoading(true);
                try {
                  const res = await fetch("/api/contact", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      name: supportName,
                      message: supportMessage,
                      email: "gopiiniyavan@gmail.com"
                    })
                  });
                  const data = await res.json();
                  if (data.status === "success") {
                    alert(`✅ Contact Ticket Dispatched!\nYour inquiry has been successfully sent to gopiiniyavan@gmail.com.`);
                    setSupportName("");
                    setSupportMessage("");
                    setSupportOpen(false);
                  } else {
                    alert("⚠️ Service notice: Could not submit ticket, please try again.");
                  }
                } catch (err) {
                  console.error("Support error:", err);
                  alert("✅ [Local Success Sandbox] Message dispatched to gopiiniyavan@gmail.com!");
                  setSupportName("");
                  setSupportMessage("");
                  setSupportOpen(false);
                } finally {
                  setSupportLoading(false);
                }
              }}
              className="space-y-2 pt-2 border-t border-white/5"
            >
              <input
                type="text"
                placeholder="Your Name / Organization"
                value={supportName}
                onChange={(e) => setSupportName(e.target.value)}
                required
                disabled={supportLoading}
                className="w-full bg-[#09090b] border border-white/10 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 disabled:opacity-50"
              />
              <textarea
                rows={2}
                placeholder="How can we help you?"
                value={supportMessage}
                onChange={(e) => setSupportMessage(e.target.value)}
                required
                disabled={supportLoading}
                className="w-full bg-[#09090b] border border-white/10 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={supportLoading}
                className="w-full accent-gradient text-white text-xs font-bold py-2 rounded-lg transition-all shadow cursor-pointer disabled:opacity-50 flex items-center justify-center gap-1.5"
              >
                {supportLoading ? (
                  <>
                    <Loader2 className="w-3 h-3 animate-spin" />
                    <span>Dispatched in progress...</span>
                  </>
                ) : (
                  <span>Send Support Ticket</span>
                )}
              </button>
            </form>

            {/* Footer Credit */}
            <div className="text-center text-[10px] text-slate-500 pt-1 border-t border-white/5 flex justify-between items-center">
              <span>Created by: <strong className="text-slate-400">Jeeva V</strong></span>
              <span className="text-[9px] bg-indigo-500/10 text-indigo-400 px-1.5 py-0.2 rounded border border-indigo-500/20 font-mono">FREE PLATFORM</span>
            </div>
          </div>
        )}

        <button
          onClick={() => setSupportOpen(!supportOpen)}
          className="accent-gradient text-white p-3 rounded-full shadow-xl shadow-indigo-500/20 transition-all hover:scale-105 active:scale-95 flex items-center gap-2 cursor-pointer font-semibold text-xs sm:text-sm"
          id="btn-support-trigger"
        >
          <MessageSquare className="w-5 h-5" />
          <span>Queries? Contact Us</span>
        </button>
      </div>

      {/* Notifications Slide-Over Panel */}
      {notificationsOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex justify-end animate-in fade-in duration-200">
          <div className="bg-[#141416] w-full max-w-md border-l border-white/10 h-full p-6 flex flex-col justify-between shadow-2xl animate-in slide-in-from-right duration-300 relative overflow-hidden font-sans">
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-indigo-500 to-purple-500" />
            
            <div className="space-y-6 overflow-y-auto flex-1 pr-1">
              {/* Header */}
              <div className="flex justify-between items-center pb-4 border-b border-white/5">
                <div className="flex items-center gap-2">
                  <Bell className="w-5 h-5 text-indigo-400 animate-bounce" />
                  <div>
                    <h3 className="font-extrabold text-sm text-white font-display">Live System & Escrow Alerts</h3>
                    <span className="text-[10px] text-slate-500 font-mono block">Direct secure telemetry channels</span>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setNotificationsOpen(false);
                    setNotificationLog(prev => prev.map(n => ({ ...n, isNew: false })));
                  }}
                  className="p-1.5 hover:bg-white/5 rounded-lg text-slate-400 hover:text-slate-200 cursor-pointer transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Notifications list */}
              <div className="space-y-3">
                {notificationLog.map(notif => (
                  <div 
                    key={notif.id} 
                    className={`p-3.5 rounded-xl border transition-all ${
                      notif.isNew 
                        ? "bg-indigo-950/10 border-indigo-500/25 shadow-sm shadow-indigo-500/5" 
                        : "bg-[#09090b] border-white/5"
                    }`}
                  >
                    <div className="flex justify-between items-start gap-2">
                      <span className="font-bold text-xs text-white leading-snug">{notif.title}</span>
                      {notif.isNew && (
                        <span className="px-1.5 py-0.5 bg-indigo-500 text-white rounded text-[8px] font-bold uppercase tracking-wider shrink-0 font-mono animate-pulse">new</span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{notif.message}</p>
                    <div className="flex justify-between items-center text-[9px] text-slate-500 pt-2 mt-2 border-t border-white/[0.03] font-mono">
                      <span className="uppercase">{notif.type}</span>
                      <span>{notif.date}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Info Note */}
              <div className="p-3 bg-white/[0.01] rounded-lg border border-white/5 space-y-2">
                <span className="text-[9px] text-slate-500 font-bold block uppercase font-mono">Quick Platform Actions</span>
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <button
                    onClick={() => {
                      setViewMode("dashboards");
                      setNotificationsOpen(false);
                    }}
                    className="bg-[#09090b] hover:bg-[#141416] p-2 rounded border border-white/5 text-center text-indigo-400 font-bold cursor-pointer hover:border-indigo-500/30 transition-all block"
                  >
                    Access Portals
                  </button>
                  <button
                    onClick={() => {
                      setUpiModalOpen(true);
                      setNotificationsOpen(false);
                    }}
                    className="bg-[#09090b] hover:bg-[#141416] p-2 rounded border border-white/5 text-center text-emerald-400 font-bold cursor-pointer hover:border-emerald-500/30 transition-all block"
                  >
                    Test UPI Escrow
                  </button>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="pt-4 border-t border-white/5 space-y-2 text-center text-[10px] text-slate-500">
              <p>Telemetry ledger authenticated by <strong className="text-slate-400">Jeeva V</strong>.</p>
              <button
                onClick={() => {
                  setNotificationLog(prev => prev.map(n => ({ ...n, isNew: false })));
                  setNotificationsOpen(false);
                }}
                className="text-xs text-indigo-400 hover:underline font-bold cursor-pointer block mx-auto font-mono uppercase tracking-wide"
              >
                Mark All as Read & Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Interactive UPI Payment & Escrow Modal */}
      {upiModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-[#141416] card-border rounded-2xl w-full max-w-md p-6 sm:p-8 space-y-5 animate-in zoom-in-95 duration-200 relative overflow-hidden glass-bg font-sans">
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-emerald-500 via-indigo-500 to-emerald-500" />
            
            {/* Header */}
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <h3 className="font-extrabold text-base text-white font-display flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                  Secure Escrow Dispatcher
                </h3>
                <p className="text-[10px] text-slate-400 font-medium">Escrow-protected multi-currency smart ledger</p>
              </div>
              <button
                onClick={() => { setUpiModalOpen(false); setUpiState("idle"); }}
                className="p-1 hover:bg-white/5 rounded-lg text-slate-400 hover:text-slate-200 cursor-pointer transition-colors font-bold"
              >
                ✕
              </button>
            </div>

            {/* Gateway Selector Tabs */}
            <div className="grid grid-cols-5 gap-1 bg-[#09090b] p-1 rounded-xl border border-white/5">
              {[
                { name: "Visa / Mastercard", label: "Visa", icon: CreditCard },
                { name: "UPI AutoPay", label: "UPI", icon: Smartphone },
                { name: "Stripe Escrow", label: "Stripe", icon: ShieldCheck },
                { name: "PayPal Global", label: "PayPal", icon: DollarSign },
                { name: "Razorpay Secure", label: "Razor", icon: Zap }
              ].map((g) => {
                const Icon = g.icon;
                const isSelected = selectedPaymentGateway === g.name;
                return (
                  <button
                    key={g.name}
                    type="button"
                    onClick={() => {
                      setSelectedPaymentGateway(g.name);
                      setUpiState("idle");
                      if (g.name === "UPI AutoPay" || g.name === "Razorpay Secure" || g.name === "Stripe Escrow") {
                        setUpiAmount("12500");
                      } else {
                        setUpiAmount("250");
                      }
                    }}
                    className={`flex flex-col items-center gap-1 py-1 px-1 rounded-lg text-[8px] font-mono transition-all cursor-pointer ${
                      isSelected 
                        ? "bg-indigo-600 text-white font-bold shadow-md shadow-indigo-500/10" 
                        : "text-slate-400 hover:text-slate-200 hover:bg-white/[0.02]"
                    }`}
                    title={g.name}
                  >
                    <Icon className="w-3 h-3 shrink-0" />
                    <span className="truncate max-w-full text-[8px]">{g.label}</span>
                  </button>
                );
              })}
            </div>

            {upiState === "success" ? (
              <div className="space-y-4 text-center py-2 animate-in zoom-in-95 duration-200">
                <div className="w-14 h-14 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto text-2xl font-bold animate-bounce shadow-lg shadow-emerald-500/10">
                  ✓
                </div>
                <div className="space-y-1">
                  <h4 className="font-black text-sm text-white">Escrow Secured Successfully!</h4>
                  <p className="text-[10px] text-slate-400">Escrow-protected dual-signature transaction logged.</p>
                </div>

                <div className="p-3 bg-white/[0.02] rounded-xl border border-white/5 text-left text-[11px] font-mono space-y-1.5">
                  <div className="flex justify-between text-slate-500">
                    <span>Gateway:</span>
                    <strong className="text-slate-300">{selectedPaymentGateway}</strong>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Ref Transaction ID:</span>
                    <strong className="text-slate-300">SF-{Math.floor(100000 + Math.random() * 900000)}</strong>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Authorized Account:</span>
                    <strong className="text-slate-300">
                      {selectedPaymentGateway === "UPI AutoPay" ? upiVpa :
                       selectedPaymentGateway === "Stripe Escrow" ? stripeEmail :
                       selectedPaymentGateway === "PayPal Global" ? paypalEmail :
                       selectedPaymentGateway === "Visa / Mastercard" ? cardName : "Vetted Indian Core"}
                    </strong>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Amount Securely Dispatched:</span>
                    <strong className="text-emerald-400 font-bold">
                      {["Visa / Mastercard", "PayPal Global"].includes(selectedPaymentGateway) ? "$" : "₹"}
                      {parseInt(upiAmount).toLocaleString(selectedPaymentGateway === "UPI AutoPay" || selectedPaymentGateway === "Razorpay Secure" ? "en-IN" : "en-US")}.00
                    </strong>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Target Pool:</span>
                    <strong className="text-indigo-400 font-bold">MNC Career Partners Escrow</strong>
                  </div>
                </div>

                <button
                  onClick={() => {
                    // Add transaction to local history ledger
                    const formattedAmount = (["Visa / Mastercard", "PayPal Global"].includes(selectedPaymentGateway) ? "$" : "₹") + parseInt(upiAmount).toLocaleString();
                    setEscrowLedger(prev => [
                      {
                        id: `tx-${Date.now()}`,
                        desc: `${selectedPaymentGateway} Escrow Lock`,
                        amount: formattedAmount,
                        status: "Active Hold",
                        date: new Date().toLocaleDateString("en-US", { month: 'long', day: 'numeric', year: 'numeric' })
                      },
                      ...prev
                    ]);
                    setUpiModalOpen(false);
                    setUpiState("idle");
                  }}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded-xl text-xs transition-all cursor-pointer shadow-lg shadow-emerald-500/20"
                >
                  Sync Smart Ledger & Close
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Dynamic Inputs */}
                <div className="space-y-3">
                  {selectedPaymentGateway === "Visa / Mastercard" && (
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-mono">Cardholder Name</label>
                        <input
                          type="text"
                          value={cardName}
                          onChange={(e) => setCardName(e.target.value)}
                          placeholder="JEEVA V"
                          className="w-full bg-[#09090b] border border-[#1c1c1f] rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-mono">Card Number</label>
                        <input
                          type="text"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          placeholder="4111 2222 3333 4444"
                          className="w-full bg-[#09090b] border border-[#1c1c1f] rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-mono">Expiry Date</label>
                          <input
                            type="text"
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            placeholder="12/29"
                            className="w-full bg-[#09090b] border border-[#1c1c1f] rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono text-center"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-mono">CVV</label>
                          <input
                            type="password"
                            maxLength={4}
                            value={cardCvv}
                            onChange={(e) => setCardCvv(e.target.value)}
                            placeholder="321"
                            className="w-full bg-[#09090b] border border-[#1c1c1f] rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono text-center"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedPaymentGateway === "UPI AutoPay" && (
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-mono">Indian UPI VPA / Phone Number</label>
                        <input
                          type="text"
                          value={upiVpa}
                          onChange={(e) => setUpiVpa(e.target.value)}
                          placeholder="gopiiniyavan@okaxis"
                          className="w-full bg-[#09090b] border border-[#1c1c1f] rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-mono">Preferred UPI App</label>
                        <select
                          value={upiProvider}
                          onChange={(e) => setUpiProvider(e.target.value)}
                          className="w-full bg-[#09090b] border border-[#1c1c1f] rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer"
                        >
                          <option value="gpay">Google Pay</option>
                          <option value="phonepe">PhonePe</option>
                          <option value="paytm">Paytm</option>
                          <option value="bhim">BHIM UPI</option>
                        </select>
                      </div>
                    </div>
                  )}

                  {selectedPaymentGateway === "Stripe Escrow" && (
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-mono">Stripe Account Email</label>
                        <input
                          type="email"
                          value={stripeEmail}
                          onChange={(e) => setStripeEmail(e.target.value)}
                          placeholder="gopiiniyavan@gmail.com"
                          className="w-full bg-[#09090b] border border-[#1c1c1f] rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                        />
                      </div>
                      <div className="p-2.5 bg-indigo-500/5 rounded-xl border border-indigo-500/10 text-[10px] text-indigo-300 leading-normal">
                        🛡️ Stripe Escrow is configured for instant smart escrow routing for Tier 1 and Tier 2 MNC partners.
                      </div>
                    </div>
                  )}

                  {selectedPaymentGateway === "PayPal Global" && (
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-mono">PayPal Account Email</label>
                        <input
                          type="email"
                          value={paypalEmail}
                          onChange={(e) => setPaypalEmail(e.target.value)}
                          placeholder="gopiiniyavan@gmail.com"
                          className="w-full bg-[#09090b] border border-[#1c1c1f] rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                        />
                      </div>
                      <div className="p-2.5 bg-indigo-500/5 rounded-xl border border-indigo-500/10 text-[10px] text-indigo-300 leading-normal">
                        🌎 PayPal Global settles contracts instantly in USD for vetted global clients.
                      </div>
                    </div>
                  )}

                  {selectedPaymentGateway === "Razorpay Secure" && (
                    <div className="space-y-3">
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-mono">Vetted Billing Phone Number / UPI</label>
                        <input
                          type="text"
                          defaultValue="+91 98765 43210"
                          className="w-full bg-[#09090b] border border-[#1c1c1f] rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                        />
                      </div>
                      <div className="p-2.5 bg-emerald-500/5 rounded-xl border border-emerald-500/10 text-[10px] text-emerald-300 leading-normal">
                        ⚡ Razorpay Secure manages Indian local payment methods under dual-signature authorization.
                      </div>
                    </div>
                  )}

                  {/* Shared Amount input field */}
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block font-mono">
                      Escrow Amount ({["Visa / Mastercard", "PayPal Global"].includes(selectedPaymentGateway) ? "USD $" : "INR ₹"})
                    </label>
                    <input
                      type="number"
                      value={upiAmount}
                      onChange={(e) => setUpiAmount(e.target.value)}
                      placeholder="12500"
                      className="w-full bg-[#09090b] border border-[#1c1c1f] rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono font-bold"
                    />
                  </div>
                </div>

                {upiState === "qr_ready" && selectedPaymentGateway === "UPI AutoPay" && (
                  <div className="p-3 bg-white/[0.01] border border-white/5 rounded-xl flex flex-col items-center gap-2.5 animate-in fade-in duration-300">
                    <span className="text-[9px] text-indigo-400 font-bold font-mono uppercase tracking-wide">Scan QR Code via Your UPI Mobile App</span>
                    <div className="w-28 h-28 bg-white p-2 rounded-xl border border-white/10 shadow flex flex-col items-center justify-center relative overflow-hidden">
                      <div className="grid grid-cols-6 gap-0.5 w-full h-full opacity-90">
                        {Array.from({ length: 36 }).map((_, i) => (
                          <div 
                            key={i} 
                            className={`rounded-sm ${(i % 2 === 0 && i % 3 === 0) || i < 6 || i % 6 === 0 || i > 30 ? "bg-black" : "bg-transparent"}`} 
                          />
                        ))}
                      </div>
                      <div className="absolute inset-0 m-auto w-8 h-8 rounded-lg bg-indigo-600 text-white font-black text-[10px] flex items-center justify-center border border-white shadow shadow-indigo-500/50">
                        UPI
                      </div>
                    </div>
                    <div className="text-center">
                      <span className="text-[9px] text-slate-500 font-mono block">Securing escrow lock of ₹{parseInt(upiAmount).toLocaleString("en-IN")}.00</span>
                      <span className="text-[8px] text-emerald-400 font-bold font-mono">AUTO-DISPATCH GATEWAY ACTIVE</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setUpiState("verifying");
                        setTimeout(() => {
                          setUpiState("success");
                        }, 1200);
                      }}
                      className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-1.5 rounded-lg text-xs transition-colors cursor-pointer"
                    >
                      Simulate Payment Confirmation
                    </button>
                  </div>
                )}

                {upiState === "verifying" && (
                  <div className="p-6 bg-white/[0.01] rounded-xl border border-white/5 flex flex-col items-center gap-2.5 justify-center text-center animate-pulse">
                    <Loader2 className="w-7 h-7 text-indigo-400 animate-spin" />
                    <div className="space-y-1">
                      <span className="text-xs text-white font-bold block">Verifying smart payment contract...</span>
                      <span className="text-[9px] text-slate-500 block font-mono">Consensus verification in progress</span>
                    </div>
                  </div>
                )}

                {upiState === "idle" && (
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedPaymentGateway === "UPI AutoPay") {
                        setUpiState("generating");
                        setTimeout(() => {
                          setUpiState("qr_ready");
                        }, 800);
                      } else {
                        setUpiState("generating");
                        setTimeout(() => {
                          setUpiState("verifying");
                          setTimeout(() => {
                            setUpiState("success");
                          }, 1200);
                        }, 800);
                      }
                    }}
                    className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 rounded-xl text-xs transition-all shadow-lg shadow-indigo-500/10 flex items-center justify-center gap-1.5 cursor-pointer font-sans"
                  >
                    <span>Generate Secure {selectedPaymentGateway} Escrow Token</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                )}

                {upiState === "generating" && (
                  <div className="p-4 bg-white/[0.01] rounded-xl border border-white/5 flex flex-col items-center gap-2 justify-center text-center">
                    <Loader2 className="w-6 h-6 text-indigo-400 animate-spin" />
                    <span className="text-xs text-slate-400 font-mono">Establishing encrypted multi-sig tunnel...</span>
                  </div>
                )}

                <div className="p-3 bg-[#09090b] rounded-xl border border-white/5 space-y-1 font-mono">
                  <span className="text-[8px] text-slate-500 font-bold block uppercase tracking-wider">Simulated Escrow Ledger Balances</span>
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="text-slate-400">Active Locked Holds:</span>
                    <strong className="text-indigo-400 font-mono">{escrowLedger.filter(tx => tx.status === "Active Hold").length} contracts</strong>
                  </div>
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="text-slate-400">Total Secured Balance (INR):</span>
                    <strong className="text-emerald-400 font-mono">₹{escrowLedger.reduce((acc, tx) => {
                      if (tx.amount.includes("₹")) {
                        return acc + parseInt(tx.amount.replace(/[^0-9]/g, ''));
                      } else if (tx.amount.includes("$")) {
                        return acc + parseInt(tx.amount.replace(/[^0-9]/g, '')) * 83; // Conversion rate
                      }
                      return acc;
                    }, 0).toLocaleString("en-IN")}</strong>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
