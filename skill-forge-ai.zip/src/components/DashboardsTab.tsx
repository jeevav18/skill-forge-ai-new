import React, { useState } from "react";
import { DashboardTab, Freelancer, Job } from "../types";
import { User, Building, Search, ShieldAlert, Sparkles, Calendar, Github, GitCommit, ListFilter, Plus, CheckCircle, Mail, MessageSquare, HardDrive, Database, Activity, RefreshCw, KeyRound, Loader2, LogOut, Globe, Send, Award, Check, Linkedin, GraduationCap, Eye, EyeOff, Lock, Shield } from "lucide-react";

interface DashboardsTabProps {
  freelancers: Freelancer[];
  jobs: Job[];
  currency: "USD" | "INR";
  activeTab?: DashboardTab;
  setActiveTab?: (tab: DashboardTab) => void;
  isLoggedIn?: boolean;
  setIsLoggedIn?: (loggedIn: boolean) => void;
}

export default function DashboardsTab({ 
  freelancers, 
  jobs, 
  currency,
  activeTab: propActiveTab,
  setActiveTab: propSetActiveTab,
  isLoggedIn: propIsLoggedIn,
  setIsLoggedIn: propSetIsLoggedIn
}: DashboardsTabProps) {
  const [localActiveTab, localSetActiveTab] = useState<DashboardTab>("freelancer");
  const activeTab = propActiveTab !== undefined ? propActiveTab : localActiveTab;
  const setActiveTab = propSetActiveTab !== undefined ? propSetActiveTab : localSetActiveTab;
  
  // --- Portal Authentication States ---
  const [localIsLoggedIn, localSetIsLoggedIn] = useState(false);
  const isLoggedIn = propIsLoggedIn !== undefined ? propIsLoggedIn : localIsLoggedIn;
  const setIsLoggedIn = propSetIsLoggedIn !== undefined ? propSetIsLoggedIn : localSetIsLoggedIn;

  const [loginEmail, setLoginEmail] = useState("gopiiniyavan@gmail.com");
  const [loginPassword, setLoginPassword] = useState("••••••••••••");
  const [loginRole, setLoginRole] = useState<DashboardTab>("freelancer");
  const [loginLoading, setLoginLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // --- Student Dashboard States ---
  const [studentQuizCompleted, setStudentQuizCompleted] = useState(false);
  const [studentSelectedAnswer, setStudentSelectedAnswer] = useState<string | null>(null);
  const [studentScore, setStudentScore] = useState(82);
  const [studentAppliedCount, setStudentAppliedCount] = useState(0);

  const formatStringRate = (rateStr: string) => {
    if (currency === "USD") {
      if (rateStr.includes("₹")) {
        return rateStr.replace(/₹([\d,]+)/g, (match, p1) => {
          const inr = parseInt(p1.replace(/,/g, ""), 10);
          return "$" + Math.round(inr / 83).toLocaleString("en-US");
        });
      }
      return rateStr;
    } else {
      if (rateStr.includes("$")) {
        return rateStr.replace(/\$([\d,]+)/g, (match, p1) => {
          const usd = parseInt(p1.replace(/,/g, ""), 10);
          return "₹" + Math.round(usd * 83).toLocaleString("en-IN");
        });
      }
      return rateStr;
    }
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginLoading(true);
    setTimeout(() => {
      setLoginLoading(false);
      setIsLoggedIn(true);
      setActiveTab(loginRole);
    }, 850);
  };

  // --- Freelancer Dashboard States ---
  const [gitSynced, setGitSynced] = useState(false);
  const [availCalendar, setAvailCalendar] = useState<boolean[]>(Array(14).fill(true));
  const [activeBids, setActiveBids] = useState([
    { id: "b-1", title: "Enterprise Salesforce Revenue Cloud (CPQ) Consultant", rate: "$80/hr", status: "Reviewing", date: "2 days ago" },
    { id: "b-2", title: "Next.js 15 & Tailwind Frontend Developer for AI Platform", rate: "$8,500 Fixed", status: "Offered", date: "1 day ago" }
  ]);

  // --- Company Dashboard States ---
  const [pipelineCandidates, setPipelineCandidates] = useState([
    { id: "c-1", name: "Aravind Nair", title: "Lead Salesforce Technical Architect", stage: "Interviewing" },
    { id: "c-2", name: "Priya Sharma", title: "Senior Full-Stack Developer", stage: "Offered" },
    { id: "c-3", name: "Sarah Lindqvist", title: "Salesforce flow Expert", stage: "Applied" },
    { id: "c-4", name: "Elena Rostova", title: "DevOps Engineer", stage: "Hired" }
  ]);
  const [offerText, setOfferText] = useState("We are delighted to offer you the contract position starting next Monday. Your Hourly rate will be finalized via secured Escrow.");

  // --- Recruiter Dashboard States ---
  const [bulkTemplate, setBulkTemplate] = useState("Hi Candidate, we reviewed your brilliant FreelanceX profile and would like to schedule a briefing for an upcoming Salesforce CPQ rollout next Tuesday. Let us know your availability!");
  const [bulkSuccess, setBulkSuccess] = useState(false);

  // --- Admin Dashboard States ---
  const [healthStatus, setHealthStatus] = useState("Excellent");
  const [logs, setLogs] = useState([
    { id: "l-1", time: "09:58:12", type: "INFO", message: "Matching indexing pipeline refreshed successfully (0.01s)" },
    { id: "l-2", time: "09:58:15", type: "ALERT", message: "Duplicate account detection scanner executed: 0 hits" },
    { id: "l-3", time: "09:58:20", type: "SECURITY", message: "Escrow account release signature authorized for Project CPQ-104" }
  ]);

  // Actions
  const toggleCalDay = (idx: number) => {
    const updated = [...availCalendar];
    updated[idx] = !updated[idx];
    setAvailCalendar(updated);
  };

  const advanceCandidate = (candId: string) => {
    setPipelineCandidates(prev => prev.map(c => {
      if (c.id !== candId) return c;
      const stages = ["Applied", "Interviewing", "Offered", "Hired"];
      const nextIdx = (stages.indexOf(c.stage) + 1) % stages.length;
      return { ...c, stage: stages[nextIdx] };
    }));
  };

  const triggerBulkMessage = (e: React.FormEvent) => {
    e.preventDefault();
    setBulkSuccess(true);
    setTimeout(() => setBulkSuccess(false), 2500);
  };

  // --- MNC Portal States ---
  const [selectedMncTier, setSelectedMncTier] = useState<"all" | 1 | 2 | 3>("all");
  const [mncSearchQuery, setMncSearchQuery] = useState("");
  const [matchingApplicationMnc, setMatchingApplicationMnc] = useState<string | null>(null);

  // --- Password Recovery States & Captcha ---
  const [showForgotPass, setShowForgotPass] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotMethod, setForgotMethod] = useState<"email" | "sms" | "auth_code">("email");
  const [captchaCode, setCaptchaCode] = useState("S8V4K");
  const [userCaptcha, setUserCaptcha] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [userOtp, setUserOtp] = useState("");
  const [generatedOtp, setGeneratedOtp] = useState("");
  const [recoverySuccess, setRecoverySuccess] = useState(false);
  const [forgotError, setForgotError] = useState("");

  // --- Professional Portal Sync ---
  const [linkedinId, setLinkedinId] = useState("linkedin.com/in/gopi-iniyavan");
  const [unstopId, setUnstopId] = useState("unstop.com/user/gopiiniyavan");
  const [githubIdState, setGithubIdState] = useState("github.com/gopiiniyavan");

  const refreshCaptcha = () => {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let code = "";
    for (let i = 0; i < 5; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setCaptchaCode(code);
    setUserCaptcha("");
    setForgotError("");
  };

  const handleRequestOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (userCaptcha.trim().toUpperCase() !== captchaCode) {
      setForgotError("Invalid CAPTCHA code. Please check and try again.");
      return;
    }
    setForgotError("");
    
    // Generate a random 6 digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(otp);
    setOtpSent(true);
    
    // Simulate dispatching based on method
    const destination = forgotMethod === "email" ? "Email" : forgotMethod === "sms" ? "Message (SMS)" : "Authenticator Code Engine";
    alert(`[SIMULATED TRANSMISSION] Secure OTP code "${otp}" dispatched to your registered ${destination} linked with ${forgotEmail}.`);
  };

  const handleVerifyOtpAndRecover = (e: React.FormEvent) => {
    e.preventDefault();
    if (userOtp.trim() !== generatedOtp) {
      setForgotError("Incorrect OTP verification code. Please check and try again.");
      return;
    }
    
    setForgotError("");
    setRecoverySuccess(true);
    alert(`Verification Successful! Your recovered password has been reset to: "FreelanceX2026!". You may now use it to authenticate.`);
    setLoginPassword("FreelanceX2026!");
    setShowForgotPass(false);
    // Reset states
    setForgotEmail("");
    setUserCaptcha("");
    setOtpSent(false);
    setUserOtp("");
    setGeneratedOtp("");
    setRecoverySuccess(false);
  };

  const MNC_PARTNERS = [
    { name: "Google Cloud", tier: 1, logo: "https://upload.wikimedia.org/wikipedia/commons/5/51/Google_Cloud_logo.svg", role: "Strategic AI Infrastructure Partner", packageRange: "₹2,400,000 - ₹4,800,000/yr", activeContracts: 32, hq: "Mountain View, USA (Multiple Indian Hubs)" },
    { name: "Salesforce Systems", tier: 1, logo: "https://upload.wikimedia.org/wikipedia/commons/f/f9/Salesforce.com_logo.svg", role: "Direct CRM Integration Sponsor", packageRange: "₹2,200,000 - ₹4,500,000/yr", activeContracts: 45, hq: "San Francisco, USA (Bangalore Hub)" },
    { name: "Microsoft Corporation", tier: 1, logo: "https://upload.wikimedia.org/wikipedia/commons/9/96/Microsoft_logo_edge_version_%282012-present%29.svg", role: "Developer Tools Integration", packageRange: "₹2,500,000 - ₹5,000,000/yr", activeContracts: 28, hq: "Redmond, USA (Hyderabad HQ)" },
    { name: "Accenture Enterprise", tier: 1, logo: "https://upload.wikimedia.org/wikipedia/commons/c/cd/Accenture.svg", role: "Global Delivery Integrator", packageRange: "₹1,800,000 - ₹3,600,000/yr", activeContracts: 110, hq: "Dublin, Ireland (Bangalore/Mumbai)" },
    { name: "Deloitte Digital", tier: 1, logo: "https://upload.wikimedia.org/wikipedia/commons/5/56/Deloitte.svg", role: "Strategic Consulting Hub", packageRange: "₹1,600,000 - ₹3,200,000/yr", activeContracts: 85, hq: "New York, USA (Hyderabad/Bangalore)" },
    { name: "Capgemini Solutions", tier: 2, logo: "https://upload.wikimedia.org/wikipedia/commons/a/aa/Capgemini_201X_logo.svg", role: "Technical Delivery Partner", packageRange: "₹1,200,000 - ₹2,800,000/yr", activeContracts: 72, hq: "Paris, France (Pune/Chennai)" },
    { name: "Cognizant Technology", tier: 2, logo: "https://upload.wikimedia.org/wikipedia/commons/0/03/Cognizant_logo_2022.svg", role: "Systems Operations Hub", packageRange: "₹1,100,000 - ₹2,600,000/yr", activeContracts: 95, hq: "Teaneck, USA (Chennai/Kolkata)" },
    { name: "PwC Digital Systems", tier: 2, logo: "https://upload.wikimedia.org/wikipedia/commons/0/05/PricewaterhouseCoopers_Logo.svg", role: "Assurance & Implementation", packageRange: "₹1,300,000 - ₹3,000,000/yr", activeContracts: 40, hq: "London, UK (Gurugram Hub)" },
    { name: "Infosys Limited", tier: 2, logo: "https://upload.wikimedia.org/wikipedia/commons/9/95/Infosys_logo.svg", role: "Global Tech Vetting Sponsor", packageRange: "₹800,000 - ₹2,200,000/yr", activeContracts: 150, hq: "Bangalore, India" },
    { name: "EY Consulting GDS", tier: 2, logo: "https://upload.wikimedia.org/wikipedia/commons/3/34/Ernst_%26_Young_logo.svg", role: "Financial Operations Escrows", packageRange: "₹1,200,000 - ₹2,900,000/yr", activeContracts: 54, hq: "London, UK (Kochi/Bangalore)" },
    { name: "Tata Consultancy Services (TCS)", tier: 3, logo: "https://upload.wikimedia.org/wikipedia/commons/b/b1/Tata_Consultancy_Services_Logo.svg", role: "Offshore Delivery Framework", packageRange: "₹600,000 - ₹1,800,000/yr", activeContracts: 210, hq: "Mumbai, India" },
    { name: "Wipro Technologies", tier: 3, logo: "https://upload.wikimedia.org/wikipedia/commons/a/a0/Wipro_Logo_New.svg", role: "Regional Resource Sourcing", packageRange: "₹650,000 - ₹1,750,000/yr", activeContracts: 135, hq: "Bangalore, India" },
    { name: "Tech Mahindra", tier: 3, logo: "https://upload.wikimedia.org/wikipedia/commons/c/cb/Tech_Mahindra_New_Logo.svg", role: "Telecom Integration Hub", packageRange: "₹700,000 - ₹1,900,000/yr", activeContracts: 80, hq: "Pune, India" },
    { name: "LTIMindtree", tier: 3, logo: "https://upload.wikimedia.org/wikipedia/commons/2/25/LTIMindtree_logo.svg", role: "Niche Digital Integrator", packageRange: "₹800,000 - ₹2,100,000/yr", activeContracts: 65, hq: "Mumbai, India" },
    { name: "HCLTech Systems", tier: 3, logo: "https://upload.wikimedia.org/wikipedia/commons/e/e0/HCL_Technologies_logo.svg", role: "Offshore Delivery Partner", packageRange: "₹600,000 - ₹1,700,000/yr", activeContracts: 95, hq: "Noida, India" },
    { name: "Mphasis Digital", tier: 3, logo: "https://upload.wikimedia.org/wikipedia/commons/0/07/Mphasis_Logo.svg", role: "Application Architecture Hub", packageRange: "₹620,000 - ₹1,800,000/yr", activeContracts: 45, hq: "Bangalore, India" },
    { name: "Genpact Enterprise", tier: 3, logo: "https://upload.wikimedia.org/wikipedia/commons/a/a2/Genpact_logo.svg", role: "Process & IT Services Hub", packageRange: "₹550,000 - ₹1,600,000/yr", activeContracts: 110, hq: "New York, USA (Gurugram/Noida Hubs)" },
    { name: "Hexaware Technologies", tier: 3, logo: "https://upload.wikimedia.org/wikipedia/commons/1/18/Hexaware_Logo.png", role: "Automation Delivery Sourcing", packageRange: "₹600,000 - ₹1,750,000/yr", activeContracts: 60, hq: "Navi Mumbai, India" },
    { name: "KPIT Technologies", tier: 3, logo: "https://upload.wikimedia.org/wikipedia/commons/c/c5/KPIT_Technologies_logo.png", role: "Automotive Software Sponsor", packageRange: "₹650,000 - ₹1,850,000/yr", activeContracts: 50, hq: "Pune, India" }
  ];

  const formatMncPackage = (rangeStr: string) => {
    if (currency === "USD") {
      if (rangeStr.includes("₹")) {
        return rangeStr.replace(/₹([\d,]+)/g, (match, p1) => {
          const inr = parseInt(p1.replace(/,/g, ""), 10);
          return "$" + Math.round(inr / 83).toLocaleString("en-US");
        });
      }
      return rangeStr;
    }
    return rangeStr;
  };

  const filteredMncPartners = MNC_PARTNERS.filter(mnc => {
    const matchesTier = selectedMncTier === "all" || mnc.tier === selectedMncTier;
    const matchesSearch = mnc.name.toLowerCase().includes(mncSearchQuery.toLowerCase()) ||
                          mnc.hq.toLowerCase().includes(mncSearchQuery.toLowerCase()) ||
                          mnc.role.toLowerCase().includes(mncSearchQuery.toLowerCase());
    return matchesTier && matchesSearch;
  });

  if (!isLoggedIn) {
    return (
      <div className="max-w-md mx-auto my-8 animate-in fade-in zoom-in-95 duration-300" id="portal-login-page">
        <div className="bg-[#141416] card-border rounded-xl p-6 sm:p-8 space-y-6 relative overflow-hidden shadow-2xl shadow-indigo-500/5">
          {/* Accent light decoration */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />

          {showForgotPass ? (
            <div className="space-y-5 animate-in fade-in duration-200" id="forgot-password-panel">
              {/* Back button */}
              <button
                type="button"
                onClick={() => {
                  setShowForgotPass(false);
                  setOtpSent(false);
                  setForgotError("");
                }}
                className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
              >
                ← Back to Login
              </button>

              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white font-display">Secure Recovery Hub</h3>
                <p className="text-xs text-slate-400">
                  Verify your identity with CAPTCHA & OTP to recover or reset your passkey instantly.
                </p>
              </div>

              {forgotError && (
                <div className="p-2.5 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-[11px] font-medium">
                  ⚠️ {forgotError}
                </div>
              )}

              {!otpSent ? (
                <form onSubmit={handleRequestOtp} className="space-y-4">
                  {/* Target Email */}
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Registered Email / User ID
                    </label>
                    <input
                      type="email"
                      required
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      placeholder="gopiiniyavan@gmail.com"
                      className="w-full bg-[#09090b] border border-white/10 rounded-lg px-3 py-2 text-slate-200 text-xs focus:outline-none focus:border-indigo-500 font-mono"
                    />
                  </div>

                  {/* Recovery Channel */}
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      OTP Dispatch Channel
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: "email", label: "Email Link" },
                        { id: "sms", label: "Direct SMS" },
                        { id: "auth_code", label: "Auth App" }
                      ].map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setForgotMethod(item.id as any)}
                          className={`p-2 rounded-lg text-[10px] font-semibold border transition-all cursor-pointer ${
                            forgotMethod === item.id
                              ? "bg-indigo-500/10 border-indigo-500 text-indigo-400 font-bold"
                              : "bg-[#09090b] border-white/5 text-slate-400 hover:text-slate-200"
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Captcha Block */}
                  <div className="space-y-1.5 bg-[#09090b] p-3 rounded-lg border border-white/5">
                    <div className="flex justify-between items-center mb-1.5">
                      <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Security CAPTCHA</span>
                      <button
                        type="button"
                        onClick={refreshCaptcha}
                        className="text-[10px] text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <RefreshCw className="w-2.5 h-2.5 animate-spin-slow" /> Refresh
                      </button>
                    </div>

                    <div className="flex items-center gap-3">
                      {/* Styled Captcha Display */}
                      <div className="bg-slate-800/80 border border-indigo-500/20 rounded px-4 py-1.5 font-mono text-sm tracking-widest text-indigo-300 font-black select-none line-through decoration-indigo-500/50 italic skew-x-12">
                        {captchaCode}
                      </div>

                      {/* Captcha Input */}
                      <input
                        type="text"
                        required
                        value={userCaptcha}
                        onChange={(e) => setUserCaptcha(e.target.value)}
                        placeholder="Type characters"
                        className="flex-1 bg-[#141416] border border-white/10 rounded-lg px-2.5 py-1.5 text-slate-200 text-xs focus:outline-none focus:border-indigo-500 font-mono uppercase"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full accent-gradient hover:opacity-95 text-white font-bold py-2 rounded-lg text-xs transition-all cursor-pointer flex items-center justify-center gap-1"
                  >
                    Send Authorization OTP
                  </button>
                </form>
              ) : (
                <form onSubmit={handleVerifyOtpAndRecover} className="space-y-4">
                  <div className="bg-indigo-950/35 border border-indigo-500/20 rounded-lg p-3 text-center space-y-1">
                    <span className="text-[10px] text-indigo-400 font-bold uppercase block tracking-wider">OTP Dispatched!</span>
                    <p className="text-slate-400 text-[11px]">
                      A 6-digit authentication OTP code has been transmitted. Please check your chosen {forgotMethod === "email" ? "Email Inbox" : forgotMethod === "sms" ? "SMS Messages" : "Authenticator App"}.
                    </p>
                  </div>

                  {/* OTP Input */}
                  <div className="space-y-1.5">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Enter 6-Digit OTP Code
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={6}
                      value={userOtp}
                      onChange={(e) => setUserOtp(e.target.value)}
                      placeholder="e.g. 123456"
                      className="w-full text-center bg-[#09090b] border border-white/10 rounded-lg px-3 py-2 text-slate-200 text-sm focus:outline-none focus:border-indigo-500 font-mono font-bold tracking-widest"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded-lg text-xs transition-all cursor-pointer flex items-center justify-center gap-1 shadow-lg shadow-emerald-500/10"
                  >
                    Confirm & Reset Passkey
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setOtpSent(false);
                      setUserCaptcha("");
                    }}
                    className="w-full text-center text-[10px] text-slate-500 hover:text-indigo-400 transition-colors cursor-pointer"
                  >
                    Didn't receive code? Change method or retry CAPTCHA
                  </button>
                </form>
              )}
            </div>
          ) : (
            <>
              {/* Title */}
              <div className="text-center space-y-2">
                <div className="mx-auto w-12 h-12 rounded-xl bg-indigo-950/40 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                  <KeyRound className="w-5 h-5 animate-pulse" />
                </div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-white font-display tracking-tight">
                  SkillForge Secure Gateway
                </h2>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Authenticate to access live dashboards, telemetry metrics, escrow accounts, and dispatch queues.
                </p>
              </div>

              {/* Free Banner */}
              <div className="bg-indigo-950/35 border border-indigo-500/20 rounded-xl p-3 text-center text-xs space-y-1">
                <span className="font-bold text-indigo-400 block uppercase tracking-wider text-[10px]">
                  ★ 100% Free Service Platform ★
                </span>
                <p className="text-slate-400 text-[11px]">
                  Direct contract placement subsidized by MNC sponsors. No platform fees.
                </p>
              </div>

              <form onSubmit={handleLoginSubmit} className="space-y-4">
                {/* Role Select visual cards */}
                <div className="space-y-2">
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Select Access Role
                  </label>
                  
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: "freelancer", label: "Freelancer", desc: "Browse jobs & build profile", icon: User },
                      { id: "student", label: "Student Pathway", desc: "Academic prep & placement", icon: GraduationCap },
                      { id: "company", label: "Enterprise Client", desc: "Post jobs & hire talent", icon: Building },
                      { id: "recruiter", label: "Recruiter Hub", desc: "Matchmaking pipelines", icon: Search },
                    ].map((role) => {
                      const Icon = role.icon;
                      const isSelected = loginRole === role.id;
                      return (
                        <button
                          key={role.id}
                          type="button"
                          onClick={() => setLoginRole(role.id as DashboardTab)}
                          className={`p-3 rounded-xl border text-left transition-all duration-200 flex flex-col justify-between h-[82px] cursor-pointer relative ${
                            isSelected
                              ? "bg-indigo-950/20 border-indigo-500 text-white shadow-lg shadow-indigo-500/5"
                              : "bg-[#09090b] border-white/5 text-slate-400 hover:text-slate-200 hover:border-white/15"
                          }`}
                        >
                          <div className="flex justify-between items-center w-full">
                            <div className={`p-1.5 rounded-lg ${isSelected ? "bg-indigo-500/20 text-indigo-400" : "bg-slate-800/40 text-slate-400"}`}>
                              <Icon className="w-3.5 h-3.5" />
                            </div>
                            {isSelected && (
                              <div className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                            )}
                          </div>
                          <div className="space-y-0.5 mt-1">
                            <span className="font-bold text-[11px] block">{role.label}</span>
                            <span className="text-[9px] text-slate-500 leading-none block truncate w-full">{role.desc}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex justify-between items-center text-[10px] text-slate-500 pt-1">
                    <span>Need administrator access?</span>
                    <button
                      type="button"
                      onClick={() => setLoginRole("admin")}
                      className={`px-2 py-1 rounded border font-semibold transition-all cursor-pointer ${
                        loginRole === "admin"
                          ? "bg-rose-950/20 border-rose-500/40 text-rose-400"
                          : "border-white/5 text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      🛡️ System Admin
                    </button>
                  </div>
                </div>

                {/* Email Input */}
                <div className="space-y-1.5">
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Query / Login Email
                  </label>
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="gopiiniyavan@gmail.com"
                    className="w-full bg-[#09090b] border border-white/10 rounded-lg px-3 py-2 text-slate-200 text-xs focus:outline-none focus:border-indigo-500 font-mono"
                  />
                </div>

                {/* Password */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center">
                    <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      Passkey Code
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setForgotEmail(loginEmail || "gopiiniyavan@gmail.com");
                        refreshCaptcha();
                        setShowForgotPass(true);
                      }}
                      className="text-[10px] text-indigo-400 hover:underline font-semibold cursor-pointer"
                    >
                      Forgot Passkey?
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="w-full bg-[#09090b] border border-white/10 rounded-lg pl-3 pr-10 py-2 text-slate-200 text-xs focus:outline-none focus:border-indigo-500 font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 p-1 cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  {loginPassword && loginPassword !== "••••••••••••" && (
                    <div className="space-y-1 pt-1">
                      <div className="flex justify-between text-[9px] text-slate-500">
                        <span>Passkey Cryptography Status</span>
                        <span className="font-semibold text-emerald-400">SHA-256 Encrypted</span>
                      </div>
                      <div className="h-1 w-full bg-[#09090b] rounded-full overflow-hidden flex gap-0.5">
                        <div className={`h-full flex-1 rounded-full ${loginPassword.length > 3 ? "bg-emerald-500" : "bg-amber-500"}`} />
                        <div className={`h-full flex-1 rounded-full ${loginPassword.length > 6 ? "bg-emerald-500" : "bg-slate-800"}`} />
                        <div className={`h-full flex-1 rounded-full ${loginPassword.length > 8 ? "bg-emerald-500" : "bg-slate-800"}`} />
                      </div>
                    </div>
                  )}
                </div>

                {/* Submit */}
                <button
                  type="submit"
                  disabled={loginLoading}
                  className="w-full accent-gradient hover:opacity-95 text-white font-bold py-2.5 rounded-lg text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-indigo-500/10"
                >
                  {loginLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Verifying Credentials...
                    </>
                  ) : (
                    <>
                      Authenticate Session
                      <KeyRound className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </form>
            </>
          )}

          {/* Quick Demo Assist */}
          <div className="text-center pt-2">
            <button
              type="button"
              onClick={() => {
                setLoginLoading(true);
                setTimeout(() => {
                  setLoginLoading(false);
                  setIsLoggedIn(true);
                  setActiveTab(loginRole);
                }, 400);
              }}
              className="text-[10px] text-slate-500 hover:text-indigo-400 font-medium transition-colors cursor-pointer"
            >
              ⚡ Fast Demo Login (Skip authorization password)
            </button>
          </div>

          {/* Creator Credit Footer */}
          <div className="pt-4 border-t border-white/5 text-center text-[10px] text-slate-500">
            Created by <strong className="text-slate-400 font-semibold">Jeeva V</strong> • Direct support: <span className="text-slate-400">gopiiniyavan@gmail.com</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Session status header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-[#141416] p-4 rounded-xl border border-white/5">
        <div className="space-y-0.5">
          <div className="text-xs text-indigo-400 font-mono font-bold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            SECURE RECRUITING CHANNEL ACTIVE
          </div>
          <span className="text-xs text-slate-400 block">
            Session: <strong className="text-white">{loginEmail}</strong> • Active Role: <strong className="text-white capitalize">{activeTab}</strong>
          </span>
        </div>
        <button
          onClick={() => setIsLoggedIn(false)}
          className="px-3 py-1.5 bg-[#09090b] hover:bg-white/5 border border-white/10 rounded-lg text-xs text-red-400 font-semibold transition-all cursor-pointer flex items-center gap-1.5"
        >
          <LogOut className="w-3.5 h-3.5" />
          Lock / Log Out
        </button>
      </div>

      {/* Sub-navigation role tabs */}
      <div className="flex border-b border-white/10 scrollbar-none overflow-x-auto gap-2">
        {[
          { id: "freelancer", label: "Freelancer Portal", icon: User },
          { id: "student", label: "Student Pathway", icon: GraduationCap },
          { id: "company", label: "Company Portal", icon: Building },
          { id: "recruiter", label: "Recruiter Search", icon: Search },
          { id: "admin", label: "System Administration", icon: ShieldAlert },
          { id: "mncs", label: "Top MNCs Portal", icon: Globe }
        ].map((role) => {
          const Icon = role.icon;
          return (
            <button
              key={role.id}
              onClick={() => setActiveTab(role.id as DashboardTab)}
              className={`flex items-center gap-2 px-5 py-3 text-xs sm:text-sm font-semibold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                activeTab === role.id
                  ? "border-indigo-500 text-indigo-400 bg-indigo-950/10"
                  : "border-transparent text-slate-400 hover:text-slate-200"
              }`}
            >
              <Icon className="w-4 h-4" />
              {role.label}
            </button>
          );
        })}
      </div>

      {/* RENDER 1: Freelancer Dashboard */}
      {activeTab === "freelancer" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in duration-300">
          
          {/* Column 1 & 2: Stats, GitHub Integration & Bids */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Quick Metrics */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-[#141416] card-border rounded-xl p-4 space-y-1">
                <span className="text-[10px] text-slate-500 font-bold block uppercase">Monthly Earnings</span>
                <span className="text-xl sm:text-2xl font-black text-white">
                  {currency === "USD" ? "$4,850" : "₹4,02,550"}
                </span>
              </div>
              <div className="bg-[#141416] card-border rounded-xl p-4 space-y-1">
                <span className="text-[10px] text-slate-500 font-bold block uppercase">Hours Logged</span>
                <span className="text-xl sm:text-2xl font-black text-indigo-400 font-mono">54 hrs</span>
              </div>
              <div className="bg-[#141416] card-border rounded-xl p-4 space-y-1">
                <span className="text-[10px] text-slate-500 font-bold block uppercase">Platform Rating</span>
                <span className="text-xl sm:text-2xl font-black text-yellow-500">★ 4.9</span>
              </div>
            </div>

            {/* GitHub Integration Simulator */}
            <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-bold text-sm text-slate-200 flex items-center gap-2 font-display">
                    <Github className="w-4 h-4 text-white" />
                    GitHub & Developer Sync
                  </h3>
                  <p className="text-[11px] text-slate-500">Sync repositories and pull requests to rank higher on matching boards</p>
                </div>
                {!gitSynced ? (
                  <button
                    onClick={() => setGitSynced(true)}
                    className="bg-white hover:bg-slate-100 text-slate-950 font-bold text-xs px-4 py-1.5 rounded-lg transition-all cursor-pointer shadow-sm flex items-center gap-1"
                  >
                    Sync Account
                  </button>
                ) : (
                  <span className="text-xs text-indigo-400 font-mono flex items-center gap-1 bg-indigo-950/20 px-2 py-0.5 rounded border border-indigo-500/20">
                    <CheckCircle className="w-3 h-3" /> Synced
                  </span>
                )}
              </div>

              {gitSynced && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-[#09090b] p-4 rounded-lg border border-white/5 animate-in fade-in duration-300 text-xs">
                  <div>
                    <span className="text-slate-500 block">Connected repo:</span>
                    <span className="text-slate-200 font-mono font-bold truncate block">sf-lwc-widgets</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Commits (30d):</span>
                    <span className="text-white font-mono font-bold flex items-center gap-1">
                      <GitCommit className="w-3.5 h-3.5 text-indigo-400" />
                      42 Commits
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">LeetCode Sync:</span>
                    <span className="text-amber-400 font-bold font-mono">142 Solved</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Rank Boost:</span>
                    <span className="text-indigo-400 font-bold">+18% Priority</span>
                  </div>
                </div>
              )}
            </div>

            {/* Active Bids Table */}
            <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
              <h3 className="font-bold text-sm text-slate-200 font-display">Active Outstanding Bids</h3>
              <div className="space-y-3">
                {activeBids.map((bid) => (
                  <div key={bid.id} className="p-3 bg-[#09090b] rounded-lg border border-white/5 flex justify-between items-center text-xs">
                    <div>
                      <span className="font-semibold text-slate-300 block leading-tight">{bid.title}</span>
                      <span className="text-[10px] text-slate-500 mt-1 block">Placed {bid.date} • {formatStringRate(bid.rate)}</span>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${
                      bid.status === 'Offered' ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                    }`}>
                      {bid.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Column 3: Availability Calendar Scheduler */}
          <div className="space-y-6">
            <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
              <div>
                <h3 className="font-bold text-sm text-slate-200 flex items-center gap-1.5 font-display">
                  <Calendar className="w-4 h-4 text-indigo-400" />
                  Availability Calendar
                </h3>
                <p className="text-[11px] text-slate-500">Toggle slots for next 2 weeks to indicate dispatch availability</p>
              </div>

              <div className="grid grid-cols-7 gap-1.5">
                {availCalendar.map((avail, idx) => (
                  <button
                    key={idx}
                    onClick={() => toggleCalDay(idx)}
                    className={`h-11 rounded-lg border flex flex-col items-center justify-center text-[10px] font-mono font-bold transition-all cursor-pointer ${
                      avail
                        ? "bg-indigo-950/20 border-indigo-500/40 text-indigo-400"
                        : "bg-[#09090b] border-white/5 text-slate-600"
                    }`}
                  >
                    <span>D{idx + 1}</span>
                    <span className="text-[8px] opacity-75">{avail ? "FREE" : "BUSY"}</span>
                  </button>
                ))}
              </div>

              <div className="pt-3 border-t border-white/5 text-xs text-slate-500 space-y-1 bg-[#09090b]/30 p-2.5 rounded-lg">
                <span className="font-bold text-slate-400 block uppercase text-[10px]">Benchmark Hourly Rate</span>
                <p>Calculated average for LWC developers: <strong className="text-white">{currency === "USD" ? "$75/hr" : "₹6,225/hr"}</strong></p>
              </div>
            </div>

            {/* Professional Portals Sync Card */}
            <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4" id="professional-portals-sync-card">
              <div>
                <h3 className="font-bold text-sm text-slate-200 flex items-center gap-1.5 font-display">
                  <Award className="w-4 h-4 text-indigo-400" />
                  Verified Recruitment Handles
                </h3>
                <p className="text-[11px] text-slate-500">Provide your official professional handles to sync credentials directly with sponsoring MNCs.</p>
              </div>

              <div className="space-y-3">
                {/* LinkedIn */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                    <Linkedin className="w-3 h-3 text-indigo-400" /> LinkedIn Professional Link
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={linkedinId}
                      onChange={(e) => setLinkedinId(e.target.value)}
                      className="flex-1 bg-[#09090b] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-indigo-500"
                      placeholder="linkedin.com/in/username"
                    />
                    <a
                      href={`https://${linkedinId}`}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 bg-indigo-950/40 hover:bg-indigo-900/40 text-indigo-400 border border-indigo-500/20 hover:border-indigo-500/35 rounded-lg flex items-center justify-center transition-all"
                      title="Open Link"
                    >
                      <Globe className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>

                {/* Unstop ID */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                    <span className="text-xs">🏆</span> Unstop Talent ID
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={unstopId}
                      onChange={(e) => setUnstopId(e.target.value)}
                      className="flex-1 bg-[#09090b] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-indigo-500"
                      placeholder="unstop.com/user/username"
                    />
                    <a
                      href={`https://${unstopId}`}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 bg-indigo-950/40 hover:bg-indigo-900/40 text-indigo-400 border border-indigo-500/20 hover:border-indigo-500/35 rounded-lg flex items-center justify-center transition-all"
                      title="Open Link"
                    >
                      <Globe className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>

                {/* GitHub */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                    <Github className="w-3 h-3 text-slate-200" /> GitHub Developers ID
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={githubIdState}
                      onChange={(e) => setGithubIdState(e.target.value)}
                      className="flex-1 bg-[#09090b] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:outline-none focus:border-indigo-500"
                      placeholder="github.com/username"
                    />
                    <a
                      href={`https://${githubIdState}`}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 bg-indigo-950/40 hover:bg-indigo-900/40 text-indigo-400 border border-indigo-500/20 hover:border-indigo-500/35 rounded-lg flex items-center justify-center transition-all"
                      title="Open Link"
                    >
                      <Globe className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  alert("Professional handles linked! Sponsoring MNCs and Recruiter Pools can now view your live synchronized portfolios.");
                }}
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs transition-all flex items-center justify-center gap-1 cursor-pointer shadow-md shadow-indigo-500/15"
              >
                <Check className="w-3.5 h-3.5" />
                Save & Link Verification
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RENDER STUDENT: Student Pathway & Placement Prep */}
      {activeTab === "student" && (
        <div className="space-y-6 animate-in fade-in duration-300" id="student-portal-root">
          
          {/* Quick Stats Header */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-[#141416] card-border rounded-xl p-4 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-500 font-bold block uppercase">AI-Vetting Rating</span>
                <span className="text-xl sm:text-2xl font-black text-white font-mono">
                  {studentScore}/100
                </span>
                <span className="text-[9px] text-emerald-400 font-bold block mt-0.5">
                  {studentQuizCompleted ? "★ Elite Vetted Expert" : "★ Qualified Generalist"}
                </span>
              </div>
              <div className="p-3 rounded-lg bg-emerald-500/10 text-emerald-400">
                <Award className="w-6 h-6" />
              </div>
            </div>

            <div className="bg-[#141416] card-border rounded-xl p-4 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-500 font-bold block uppercase">Academy Progress</span>
                <span className="text-xl sm:text-2xl font-black text-indigo-400 font-mono">
                  {studentQuizCompleted ? "98%" : "75%"}
                </span>
                <span className="text-[9px] text-slate-400 block mt-0.5">3 of 4 courses done</span>
              </div>
              <div className="p-3 rounded-lg bg-indigo-500/10 text-indigo-400">
                <GraduationCap className="w-6 h-6" />
              </div>
            </div>

            <div className="bg-[#141416] card-border rounded-xl p-4 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-500 font-bold block uppercase">Dispatched Portfolios</span>
                <span className="text-xl sm:text-2xl font-black text-purple-400 font-mono">
                  {studentAppliedCount} Applications
                </span>
                <span className="text-[9px] text-slate-400 block mt-0.5">Direct MNC pipelines</span>
              </div>
              <div className="p-3 rounded-lg bg-purple-500/10 text-purple-400">
                <Send className="w-6 h-6" />
              </div>
            </div>

            <div className="bg-[#141416] card-border rounded-xl p-4 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-500 font-bold block uppercase">Next Campus Drive</span>
                <span className="text-sm font-bold text-white block mt-1">July 25, 2026</span>
                <span className="text-[9px] text-amber-400 font-bold block mt-0.5">Salesforce Direct</span>
              </div>
              <div className="p-3 rounded-lg bg-amber-500/10 text-amber-400">
                <Calendar className="w-6 h-6" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Left Column: Interactive AI Placement Test & Active Courses */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Interactive Vetting Quiz Card */}
              <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-indigo-400 font-mono uppercase tracking-wider bg-indigo-500/10 px-2 py-0.5 rounded">LEVEL UP</span>
                    <h3 className="font-bold text-sm text-slate-200 font-display">AI Vetting Placement Quiz</h3>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Solve this real technical question to instantly raise your vetting score to **98/100** and secure premium direct MNC referral vouchers.
                  </p>
                </div>

                {!studentQuizCompleted ? (
                  <div className="space-y-4">
                    <div className="p-3 bg-[#09090b] rounded-lg border border-white/5 font-medium text-xs text-slate-200">
                      <strong>Question:</strong> How do you avoid infinite re-renders or runtime leaks when writing custom React side effects with heavy data-fetching?
                    </div>

                    <div className="space-y-2">
                      {[
                        { id: "A", text: "Invoke state modifiers directly inside the functional component body without any wrapper." },
                        { id: "B", text: "Ensure state modifiers are guarded within a useEffect block with carefully declared primitive dependency arrays or memoized callbacks." },
                        { id: "C", text: "Force synchronous sleeps in a while loop to delay rendering cycles." }
                      ].map((opt) => (
                        <button
                          key={opt.id}
                          onClick={() => setStudentSelectedAnswer(opt.id)}
                          className={`w-full p-3 rounded-lg text-left text-xs border transition-all cursor-pointer flex items-start gap-2.5 ${
                            studentSelectedAnswer === opt.id
                              ? "bg-indigo-950/20 border-indigo-500 text-indigo-300"
                              : "bg-[#09090b] border-white/5 text-slate-400 hover:text-slate-200 hover:border-white/15"
                          }`}
                        >
                          <span className={`w-4 h-4 rounded-full border flex items-center justify-center text-[10px] shrink-0 font-bold font-mono ${
                            studentSelectedAnswer === opt.id ? "bg-indigo-500 text-white border-indigo-500" : "border-slate-600"
                          }`}>
                            {opt.id}
                          </span>
                          <span className="leading-relaxed">{opt.text}</span>
                        </button>
                      ))}
                    </div>

                    <button
                      onClick={() => {
                        if (!studentSelectedAnswer) {
                          alert("Please select an answer choice before submitting.");
                          return;
                        }
                        if (studentSelectedAnswer === "B") {
                          setStudentQuizCompleted(true);
                          setStudentScore(98);
                          alert("Excellent Choice! Option B is absolutely correct. Your AI Vetting score has been boosted to 98/100. MNC Recruiters can now spot your premium rating!");
                        } else {
                          alert("Incorrect answer. Remember, state modifiers must be contained inside hooks with strict primitive dependencies to prevent cyclic re-render loops. Try again!");
                        }
                      }}
                      className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs transition-all cursor-pointer shadow-md shadow-indigo-500/15"
                    >
                      Submit & Verify Answer
                    </button>
                  </div>
                ) : (
                  <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-lg p-4 space-y-3 animate-in zoom-in-95 duration-200">
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                      <h4 className="font-bold text-xs text-emerald-400 uppercase tracking-wider">Verification Accomplished!</h4>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      You scored **98%** on the Real-time Security & React performance test. Sponsoring MNCs have received your live credential upgrade voucher.
                    </p>
                    <button
                      onClick={() => {
                        setStudentQuizCompleted(false);
                        setStudentSelectedAnswer(null);
                        setStudentScore(82);
                      }}
                      className="text-[10px] text-indigo-400 font-bold hover:underline"
                    >
                      Retake Placement Quiz
                    </button>
                  </div>
                )}
              </div>

              {/* Course Catalog & Preparation Pathway */}
              <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
                <div>
                  <h3 className="font-bold text-sm text-slate-200 flex items-center gap-1.5 font-display">
                    <span>📖</span>
                    Active Placement Prep Classes
                  </h3>
                  <p className="text-[11px] text-slate-500">Curated educational paths targeting bulk hire opportunities inside top MNCs.</p>
                </div>

                <div className="space-y-3">
                  {[
                    { title: "Enterprise CRM Systems & Salesforce Apex", duration: "12 hours", lessons: "4/5 complete", progress: 80, badge: "Popular" },
                    { title: "Next.js 15 & Tailwind Aesthetic Engineering", duration: "8 hours", lessons: "6/6 complete", progress: 100, badge: "Certified" },
                    { title: "AI Multi-Agent Escrow Design with Gemini", duration: "15 hours", lessons: "1/4 complete", progress: 25, badge: "New Core" }
                  ].map((course, idx) => (
                    <div key={idx} className="bg-[#09090b] border border-white/5 rounded-lg p-3.5 space-y-3 hover:border-indigo-500/20 transition-all">
                      <div className="flex justify-between items-start gap-2">
                        <div>
                          <h4 className="font-bold text-xs text-slate-200">{course.title}</h4>
                          <span className="text-[10px] text-slate-500">{course.duration} • {course.lessons}</span>
                        </div>
                        <span className={`text-[8px] font-extrabold uppercase px-1.5 py-0.5 rounded border ${
                          course.progress === 100
                            ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                            : "bg-indigo-500/10 text-indigo-400 border-indigo-500/20"
                        }`}>
                          {course.badge}
                        </span>
                      </div>
                      
                      {/* Custom Progress Bar */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[9px] text-slate-500">
                          <span>Syllabus Covered</span>
                          <span className="font-mono text-slate-300">{course.progress}%</span>
                        </div>
                        <div className="h-1.5 bg-[#141416] rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-indigo-600 rounded-full transition-all duration-500" 
                            style={{ width: `${course.progress}%` }} 
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column: MNC Internships & Verified Handles */}
            <div className="space-y-6">
              
              {/* Direct Internship Drives */}
              <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
                <div>
                  <h3 className="font-bold text-sm text-slate-200 flex items-center gap-1.5 font-display">
                    <Globe className="w-4 h-4 text-purple-400" />
                    Student MNC Placements
                  </h3>
                  <p className="text-[11px] text-slate-500">Apply with 1-click using your verified student portfolios.</p>
                </div>

                <div className="space-y-3">
                  {[
                    { company: "Salesforce Systems", role: "Junior LWC Developer Intern", stipend: currency === "USD" ? "$1,500/mo" : "₹1,24,500/mo", location: "Bangalore (Remote Allowed)" },
                    { company: "Accenture Enterprise", role: "Systems Integration Associate", stipend: currency === "USD" ? "$1,200/mo" : "₹99,600/mo", location: "Mumbai Hub" },
                    { company: "Capgemini Solutions", role: "Frontend UI Support Engineer", stipend: currency === "USD" ? "$950/mo" : "₹78,850/mo", location: "Pune Office" }
                  ].map((drive, idx) => (
                    <div key={idx} className="bg-[#09090b] border border-white/5 rounded-lg p-3 space-y-2.5">
                      <div className="space-y-1">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider">{drive.company}</span>
                          <span className="text-[9px] font-mono text-emerald-400">{drive.stipend}</span>
                        </div>
                        <h4 className="font-bold text-xs text-slate-200">{drive.role}</h4>
                        <p className="text-[10px] text-slate-500">📍 {drive.location}</p>
                      </div>

                      <button
                        onClick={() => {
                          setStudentAppliedCount(prev => prev + 1);
                          alert(`Application successful! Your student profile, academic certifications, and performance rating of ${studentScore}/100 have been dispatched to ${drive.company} Student Acquisition team.`);
                        }}
                        className="w-full py-1.5 bg-[#141416] hover:bg-indigo-950/30 text-indigo-400 hover:text-white border border-indigo-500/20 hover:border-indigo-500/40 rounded text-[10px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1"
                      >
                        <Send className="w-3 h-3" />
                        Apply Direct
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Verified Handles Card */}
              <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
                <div>
                  <h3 className="font-bold text-sm text-slate-200 flex items-center gap-1.5 font-display">
                    <CheckCircle className="w-4 h-4 text-indigo-400" />
                    Verified Credentials Sync
                  </h3>
                  <p className="text-[11px] text-slate-500">Add your accounts so recruiters can verify your academic scores.</p>
                </div>

                <div className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">LinkedIn Profile</label>
                    <input
                      type="text"
                      value={linkedinId}
                      onChange={(e) => setLinkedinId(e.target.value)}
                      className="w-full bg-[#09090b] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Unstop ID (Recruitment Platform)</label>
                    <input
                      type="text"
                      value={unstopId}
                      onChange={(e) => setUnstopId(e.target.value)}
                      className="w-full bg-[#09090b] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">GitHub ID</label>
                    <input
                      type="text"
                      value={githubIdState}
                      onChange={(e) => setGithubIdState(e.target.value)}
                      className="w-full bg-[#09090b] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 font-mono focus:outline-none"
                    />
                  </div>
                </div>

                <button
                  onClick={() => alert("Student academic records & verified handles synchronized! Campus hire pipelines updated successfully.")}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs transition-all cursor-pointer shadow-md"
                >
                  Save & Sync Academic Handles
                </button>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* RENDER 2: Company Dashboard */}
      {activeTab === "company" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in duration-300">
          
          {/* Columns 1 & 2: Staged Hiring pipeline board */}
          <div className="lg:col-span-2 bg-[#141416] card-border rounded-xl p-6 space-y-6">
            <div>
              <h3 className="font-bold text-base text-slate-200 flex items-center gap-2 font-display">
                <Building className="w-4 h-4 text-purple-400" />
                Enterprise Hiring Pipelines
              </h3>
              <p className="text-xs text-slate-500">Drag or click candidate cards to advance them through interview lifecycle stages</p>
            </div>

            {/* Kanban Columns */}
            <div className="grid grid-cols-4 gap-3">
              {["Applied", "Interviewing", "Offered", "Hired"].map((stage) => (
                <div key={stage} className="bg-[#09090b] p-3 rounded-lg border border-white/5 min-h-[220px] space-y-3">
                  <span className="text-[10px] font-bold text-slate-500 block uppercase tracking-wider">{stage}</span>
                  <div className="space-y-2">
                    {pipelineCandidates
                      .filter(c => c.stage === stage)
                      .map(c => (
                        <div
                          key={c.id}
                          onClick={() => advanceCandidate(c.id)}
                          className="p-2.5 bg-[#141416] card-border rounded hover:border-purple-500/40 cursor-pointer text-[11px] space-y-1.5 transition-all group"
                        >
                          <strong className="text-slate-200 block truncate leading-tight group-hover:text-purple-400">{c.name}</strong>
                          <span className="text-[10px] text-slate-500 block truncate">{c.title}</span>
                          <span className="text-[9px] text-indigo-400 font-mono block text-right group-hover:underline">Advance →</span>
                        </div>
                      ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Column 3: Offer Letters Drafting Panel */}
          <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
            <div>
              <h3 className="font-bold text-sm text-slate-200 font-display">Release Contract Offer Letter</h3>
              <p className="text-[11px] text-slate-500">Draft contract letters that tie into platform Escrow pipelines</p>
            </div>

            <textarea
              rows={6}
              value={offerText}
              onChange={(e) => setOfferText(e.target.value)}
              className="w-full bg-[#09090b] border border-white/10 rounded-lg p-3 text-slate-200 text-xs focus:outline-none focus:border-indigo-500 font-mono"
            />

            <button
              onClick={() => alert("Simulated Offer released to Priya Sharma. The contract is pending Escrow deposit verification.")}
              className="w-full accent-gradient text-white font-bold py-2 rounded-lg text-xs transition-all flex items-center justify-center gap-1 cursor-pointer shadow-md shadow-indigo-500/10"
            >
              Dispatch Verified Offer
            </button>
          </div>
        </div>
      )}

      {/* RENDER 3: Recruiter Dashboard */}
      {activeTab === "recruiter" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in duration-300">
          
          {/* Columns 1 & 2: Talent Pools */}
          <div className="lg:col-span-2 bg-[#141416] card-border rounded-xl p-6 space-y-6">
            <div>
              <h3 className="font-bold text-base text-slate-200 font-display">Talent Pool Directories</h3>
              <p className="text-xs text-slate-500">Manage targeted lists of pre-vetted consultants for recurring contracts</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { name: "Salesforce LWC/CPQ Experts", count: 18, skills: ["Apex", "LWC", "Aura", "MuleSoft"] },
                { name: "RAG & LLM Engineers", count: 12, skills: ["Python", "Generative AI", "LangChain"] },
                { name: "DevOps Platform Leads", count: 9, skills: ["Kubernetes", "Terraform", "CKA"] },
                { name: "Web3/DeFi Protocol Devs", count: 7, skills: ["Solidity", "Rust", "Ethereum"] }
              ].map((pool, idx) => (
                <div key={idx} className="p-4 bg-[#09090b] rounded-xl border border-white/5 flex justify-between items-start">
                  <div className="space-y-2 min-w-0">
                    <strong className="text-xs sm:text-sm text-white block truncate leading-tight">{pool.name}</strong>
                    <div className="flex flex-wrap gap-1">
                      {pool.skills.map((s, sIdx) => (
                        <span key={sIdx} className="px-1.5 py-0.2 bg-[#141416] text-slate-400 text-[9px] rounded font-mono border border-white/5">{s}</span>
                      ))}
                    </div>
                  </div>
                  <span className="text-xs font-bold text-purple-400 bg-purple-950/20 px-2 py-0.5 rounded border border-purple-500/20 shrink-0">
                    {pool.count} profiles
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Column 3: Bulk Outreach Messaging panel */}
          <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
            <div>
              <h3 className="font-bold text-sm text-slate-200 flex items-center gap-1.5 font-display">
                <Mail className="w-4 h-4 text-purple-400" />
                Bulk Outreach Dispatcher
              </h3>
              <p className="text-[11px] text-slate-500">Dispatch message sequence templates to selected talent pools instantly</p>
            </div>

            {bulkSuccess ? (
              <div className="bg-indigo-950/40 border border-indigo-500/30 rounded-xl p-5 text-center space-y-1.5 py-8 animate-in zoom-in-95">
                <CheckCircle className="w-10 h-10 text-indigo-400 mx-auto animate-bounce" />
                <h4 className="font-bold text-white text-xs">Bulk Outreach Dispatched!</h4>
                <p className="text-[10px] text-slate-400">Sent sequences to 18 Salesforce Specialists successfully.</p>
              </div>
            ) : (
              <form onSubmit={triggerBulkMessage} className="space-y-4">
                <div className="space-y-1">
                  <label className="block text-[11px] text-slate-400">Outreach Message Template</label>
                  <textarea
                    rows={6}
                    value={bulkTemplate}
                    onChange={(e) => setBulkTemplate(e.target.value)}
                    className="w-full bg-[#09090b] border border-white/10 rounded-lg p-2.5 text-slate-200 text-xs focus:outline-none focus:border-indigo-500 leading-relaxed font-sans"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full accent-gradient text-white font-bold py-2 rounded-lg text-xs transition-all flex items-center justify-center gap-1 cursor-pointer shadow-md shadow-indigo-500/10"
                >
                  Send Outreaches
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* RENDER 4: System Administration */}
      {activeTab === "admin" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in duration-300">
          
          {/* Columns 1 & 2: Audit Logs & Telemetry */}
          <div className="lg:col-span-2 bg-[#141416] card-border rounded-xl p-6 space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-bold text-base text-slate-200 font-display">Core Telemetry Audit Logs</h3>
                <p className="text-xs text-slate-500">Live platform operations logging ledger</p>
              </div>
              <button
                onClick={() => setLogs(prev => [
                  { id: "l-" + Date.now(), time: new Date().toLocaleTimeString(), type: "INFO", message: "Server health heartbeat verified: 100% stable." },
                  ...prev
                ])}
                className="p-1 hover:bg-white/5 text-slate-400 rounded cursor-pointer"
              >
                <RefreshCw className="w-4 h-4 animate-spin-slow" />
              </button>
            </div>

            <div className="space-y-2 bg-[#09090b] rounded-xl p-4 border border-white/5 font-mono text-[11px] max-h-[250px] overflow-y-auto">
              {logs.map((log) => (
                <div key={log.id} className="flex gap-2 text-slate-400">
                  <span className="text-slate-600 font-semibold">[{log.time}]</span>
                  <span className={`font-bold ${
                    log.type === 'ALERT' ? 'text-amber-500' : log.type === 'SECURITY' ? 'text-red-400' : 'text-indigo-400'
                  }`}>{log.type}</span>
                  <span className="text-slate-300">{log.message}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Column 3: Platform Telemetry Monitors */}
          <div className="bg-[#141416] card-border rounded-xl p-5 space-y-5">
            <div>
              <h3 className="font-bold text-sm text-slate-200 flex items-center gap-1.5 font-display">
                <Activity className="w-4 h-4 text-indigo-400" />
                Server Health Monitors
              </h3>
              <p className="text-[11px] text-slate-500">Real-time Node container instance statistics</p>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between items-center pb-2 border-b border-white/5">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <HardDrive className="w-3.5 h-3.5 text-slate-500" /> Server Port
                </span>
                <span className="text-white font-mono font-semibold bg-[#09090b] px-2 py-0.5 rounded border border-white/5">3000 (INGRESS)</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-white/5">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <Database className="w-3.5 h-3.5 text-slate-500" /> Platform API
                </span>
                <span className="text-indigo-400 font-mono font-semibold">ONLINE (100% OK)</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-white/5">
                <span className="text-slate-400">CPU Load Meter</span>
                <span className="text-slate-200 font-mono">1.2% usage</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Request Latency</span>
                <span className="text-slate-200 font-mono">12 ms (avg)</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* RENDER 5: Top MNCs Portal Section */}
      {activeTab === "mncs" && (
        <div className="space-y-6 animate-in fade-in duration-300" id="top-mncs-portal-section">
          {/* Banner */}
          <div className="bg-gradient-to-r from-indigo-950/40 via-purple-950/20 to-[#141416] card-border rounded-xl p-6 md:p-8 space-y-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
            <div className="space-y-2">
              <span className="px-2.5 py-0.5 bg-indigo-500/10 text-indigo-400 text-[10px] rounded font-bold uppercase tracking-wide border border-indigo-500/20">
                100% Subsidized Recruiting
              </span>
              <h2 className="text-xl md:text-3xl font-extrabold text-white tracking-tight font-display flex items-center gap-2">
                <Building className="w-6 h-6 text-indigo-400 animate-pulse" />
                Top MNCs Recruitment Pipeline
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
                Direct placement contracts funded fully by Tier 1, Tier 2, and Tier 3 Multinational Corporations. Zero placement fees, zero commission deductions.
              </p>
            </div>

            {/* Quick Portal Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 pt-4 border-t border-white/5">
              <div className="space-y-0.5">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Total Active Budget</span>
                <strong className="text-base text-indigo-400 font-mono">
                  {currency === "USD" ? "$24,000,000" : "₹200 Crore"}
                </strong>
              </div>
              <div className="space-y-0.5">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Live Open Positions</span>
                <strong className="text-base text-purple-400 font-mono">1,135 Active Roles</strong>
              </div>
              <div className="space-y-0.5">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Average Matching Time</span>
                <strong className="text-base text-emerald-400 font-mono">48 Hours</strong>
              </div>
              <div className="hidden sm:block space-y-0.5">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Vetted Hiring Rate</span>
                <strong className="text-base text-amber-400 font-mono">94.2% Passed</strong>
              </div>
            </div>
          </div>

          {/* Search & Filtering Toolbar */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#141416] p-4 rounded-xl border border-white/5">
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={mncSearchQuery}
                onChange={(e) => setMncSearchQuery(e.target.value)}
                placeholder="Search MNC by name, role, hq location..."
                className="w-full bg-[#09090b] border border-white/10 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Tier Filters */}
            <div className="flex bg-[#09090b] border border-white/5 p-1 rounded-lg gap-1 overflow-x-auto max-w-full scrollbar-none">
              {[
                { id: "all", label: "All Sponsoring Tiers" },
                { id: 1, label: "Tier 1 (Elite Hubs)" },
                { id: 2, label: "Tier 2 (Mid-Market)" },
                { id: 3, label: "Tier 3 (Emerging)" }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedMncTier(tab.id as any)}
                  className={`px-3 py-1.5 rounded-md text-[11px] font-semibold cursor-pointer whitespace-nowrap transition-all ${
                    selectedMncTier === tab.id
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-500/15"
                      : "text-slate-400 hover:text-slate-200 hover:bg-white/[0.02]"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* MNC Partners Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredMncPartners.map((mnc, idx) => {
              const isMatching = matchingApplicationMnc === mnc.name;
              return (
                <div
                  key={idx}
                  className="bg-[#141416] card-border hover:border-indigo-500/20 rounded-xl p-5 flex flex-col justify-between gap-5 transition-all duration-300 relative group"
                >
                  {/* Subtle hover backlight */}
                  <div className="absolute -inset-px bg-gradient-to-r from-indigo-500/0 to-purple-500/0 group-hover:from-indigo-500/5 group-hover:to-purple-500/5 rounded-xl transition-all duration-300 pointer-events-none" />

                  <div className="space-y-4">
                    {/* Card Header */}
                    <div className="flex justify-between items-start gap-2">
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="w-10 h-10 rounded-xl bg-white p-1.5 flex items-center justify-center shrink-0 shadow-inner overflow-hidden">
                          {mnc.logo.startsWith("http") ? (
                            <div className="w-full h-full relative flex items-center justify-center">
                              <img 
                                src={mnc.logo} 
                                alt={`${mnc.name} logo`} 
                                className="w-full h-full object-contain" 
                                referrerPolicy="no-referrer"
                                onError={(e) => {
                                  e.currentTarget.style.display = 'none';
                                  const sibling = e.currentTarget.nextElementSibling as HTMLElement;
                                  if (sibling) sibling.style.display = 'flex';
                                }}
                              />
                              <span className="hidden w-full h-full text-[10px] font-black bg-[#141416] text-indigo-400 rounded-lg items-center justify-center font-mono uppercase">
                                {mnc.name.split(' ').map((n) => n[0]).join('')}
                              </span>
                            </div>
                          ) : (
                            <span className="text-2xl font-bold">{mnc.logo}</span>
                          )}
                        </span>
                        <div className="min-w-0">
                          <h4 className="font-bold text-sm text-white truncate leading-tight">{mnc.name}</h4>
                          <span className="text-[10px] text-slate-500 truncate block mt-0.5">{mnc.hq}</span>
                        </div>
                      </div>
                      <span className={`px-2.5 py-0.5 rounded text-[9px] font-extrabold uppercase shrink-0 border ${
                        mnc.tier === 1
                          ? "bg-indigo-500/10 text-indigo-400 border-indigo-500/20"
                          : mnc.tier === 2
                          ? "bg-purple-500/10 text-purple-400 border-purple-500/20"
                          : "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                      }`}>
                        Tier {mnc.tier} {mnc.tier === 1 ? "Elite" : mnc.tier === 2 ? "Mid" : "Emerging"}
                      </span>
                    </div>

                    {/* Partner Role details */}
                    <div className="pt-3 border-t border-white/5 space-y-2">
                      <div>
                        <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider block">Strategic Focus</span>
                        <p className="text-xs text-slate-200 font-medium leading-relaxed">{mnc.role}</p>
                      </div>

                      <div className="flex justify-between items-center text-[11px] text-slate-400 pt-1">
                        <span>Avg Package Sourced:</span>
                        <strong className="text-indigo-400 font-mono">
                          {formatMncPackage(mnc.packageRange)}
                        </strong>
                      </div>
                    </div>
                  </div>

                  {/* Actions Area */}
                  <div className="space-y-3 pt-3 border-t border-white/5 relative z-10">
                    <div className="bg-[#09090b] rounded-lg p-2.5 border border-white/5 flex justify-between items-center text-[10px] text-slate-400 font-mono">
                      <span>Live Direct Pipelines:</span>
                      <strong className="text-white">{mnc.activeContracts} open roles</strong>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => {
                          setMatchingApplicationMnc(mnc.name);
                          setTimeout(() => {
                            alert(`Success! Your SkillForge credentials and AI Resume portfolio have been dispatched to ${mnc.name} Direct Recruitment Team. Expect a matching briefing in 24 hours.`);
                            setMatchingApplicationMnc(null);
                          }, 1000);
                        }}
                        disabled={isMatching}
                        className="py-1.5 bg-[#09090b] hover:bg-white/5 border border-white/10 rounded-lg text-[10px] font-bold text-slate-300 hover:text-white transition-all cursor-pointer flex items-center justify-center gap-1"
                      >
                        {isMatching ? (
                          <>
                            <Loader2 className="w-3 h-3 animate-spin text-indigo-400" />
                            Matching...
                          </>
                        ) : (
                          <>
                            <Award className="w-3 h-3 text-indigo-400" />
                            Apply Direct
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => {
                          alert(`Referral ticket created! We have requested a direct sponsor referral voucher for ${mnc.name}.`);
                        }}
                        className="py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-[10px] font-extrabold transition-all cursor-pointer flex items-center justify-center gap-1 shadow-md shadow-indigo-500/10"
                      >
                        <Send className="w-3 h-3" />
                        Refer Me
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}

            {filteredMncPartners.length === 0 && (
              <div className="col-span-full text-center py-12 bg-[#141416] rounded-xl border border-white/5 space-y-2">
                <Globe className="w-8 h-8 text-slate-600 mx-auto" />
                <h4 className="font-bold text-white text-sm">No Sponsoring MNCs Found</h4>
                <p className="text-xs text-slate-500">Try adjusting your filters or search keyword.</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
