import React, { useState, useRef, useEffect } from "react";
import { MessageSquare, X, Send, Bot, User, Sparkles, Loader2 } from "lucide-react";
import { ChatMessage } from "../types";

export default function AIChatDrawer() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "m-welcome",
      role: "model",
      content: "Hello! I am your **FreelanceX AI Advisor**. I specialize in helping you navigate CRM architectures (like Salesforce LWC, Einstein, MuleSoft), freelancing contract setups, and optimizing your portfolio. Ask me anything!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [offlineIndicator, setOfflineIndicator] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: "user-" + Date.now(),
      role: "user",
      content: input,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/ai-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMsg.content,
          history: messages.slice(-6).map((m) => ({ role: m.role, content: m.content }))
        })
      });

      const data = await response.json();
      if (response.ok) {
        setMessages((prev) => [
          ...prev,
          {
            id: "ai-" + Date.now(),
            role: "model",
            content: data.reply,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
        if (data.offlineMode) {
          setOfflineIndicator(true);
        } else {
          setOfflineIndicator(false);
        }
      } else {
        throw new Error(data.error || "Failed to communicate with API");
      }
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: "err-" + Date.now(),
          role: "model",
          content: "I encountered a minor connection issue. However, as an expert Salesforce & Freelancer guide, I suggest checking if you have configured your **GEMINI_API_KEY** in **Settings > Secrets**. Let's keep exploring the platform features!",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 font-sans" id="ai-support-drawer">
      {/* Floating Action Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-teal-600 to-cyan-600 text-white px-5 py-4 rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all duration-300 group cursor-pointer border border-teal-500/20"
          id="btn-open-chat"
        >
          <div className="relative">
            <MessageSquare className="w-6 h-6 animate-pulse" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-yellow-400 rounded-full animate-ping" />
          </div>
          <span className="font-semibold text-sm tracking-wide">AI Career Assistant</span>
          <Sparkles className="w-4 h-4 text-yellow-300 group-hover:rotate-12 transition-transform" />
        </button>
      )}

      {/* Actual Chat Drawer */}
      {isOpen && (
        <div className="w-96 h-[500px] bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-6 duration-300">
          {/* Header */}
          <div className="bg-gradient-to-r from-slate-950 to-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-teal-600/20 flex items-center justify-center border border-teal-500/30">
                <Bot className="w-5 h-5 text-teal-400" />
              </div>
              <div>
                <div className="font-bold text-sm text-slate-100 flex items-center gap-1.5">
                  FreelanceX AI
                  {offlineIndicator && (
                    <span className="text-[10px] px-1.5 py-0.2 bg-amber-500/10 text-amber-400 rounded-full border border-amber-500/20">Demo Mode</span>
                  )}
                </div>
                <div className="text-[10px] text-teal-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-pulse" />
                  Active Assistant
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
              id="btn-close-chat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Body */}
          <div
            className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950/60"
            ref={scrollRef}
          >
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 max-w-[85%] ${
                  msg.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto"
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 border ${
                    msg.role === "user"
                      ? "bg-slate-800 border-slate-700 text-slate-300"
                      : "bg-teal-900/40 border-teal-800 text-teal-400"
                  }`}
                >
                  {msg.role === "user" ? (
                    <User className="w-4 h-4" />
                  ) : (
                    <Bot className="w-4 h-4" />
                  )}
                </div>
                <div>
                  <div
                    className={`rounded-2xl px-3.5 py-2 text-sm leading-relaxed ${
                      msg.role === "user"
                        ? "bg-teal-600 text-white rounded-tr-none"
                        : "bg-slate-900 border border-slate-800 text-slate-300 rounded-tl-none"
                    }`}
                  >
                    {/* Basic markdown parsing helper for bold and linebreaks */}
                    {msg.content.split("\n").map((line, idx) => {
                      // bold matcher
                      const boldParts = line.split(/\*\*(.*?)\*\*/g);
                      return (
                        <p key={idx} className="mb-1 text-xs sm:text-sm">
                          {boldParts.map((part, i) =>
                            i % 2 === 1 ? <strong key={i} className="text-white font-semibold">{part}</strong> : part
                          )}
                        </p>
                      );
                    })}
                  </div>
                  <span className="text-[9px] text-slate-500 mt-1 block px-1 text-right">
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-2.5 max-w-[85%] mr-auto">
                <div className="w-7 h-7 rounded-full bg-teal-900/40 border border-teal-800 flex items-center justify-center text-teal-400 shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-none px-4 py-3 flex items-center gap-2">
                  <Loader2 className="w-4 h-4 text-teal-400 animate-spin" />
                  <span className="text-xs text-slate-400 font-mono">AI is processing...</span>
                </div>
              </div>
            )}
          </div>

          {/* Input Footer */}
          <form
            onSubmit={handleSendMessage}
            className="p-3 bg-slate-950 border-t border-slate-800 flex gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about LWC, Salesforce, freelancing..."
              className="flex-1 bg-slate-900 border border-slate-800 text-slate-100 rounded-xl px-3 py-2 text-xs sm:text-sm focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition-all font-sans placeholder-slate-500"
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="bg-teal-600 hover:bg-teal-500 disabled:bg-slate-800 text-white p-2 rounded-xl transition-all flex items-center justify-center shadow-md cursor-pointer"
              id="btn-send-chat"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
