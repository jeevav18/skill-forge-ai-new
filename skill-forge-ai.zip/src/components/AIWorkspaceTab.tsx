import React, { useState } from "react";
import { Search, FileText, UserCheck, Code, Sparkles, Loader2, ArrowRight, Brain, AlertCircle, RefreshCw, Send, CheckCircle2, ChevronRight, Copy, Check } from "lucide-react";
import { Freelancer, AIWorkspaceTool } from "../types";

interface AIWorkspaceTabProps {
  onSelectFreelancer: (freelancer: Freelancer) => void;
  activeTool?: AIWorkspaceTool;
  setActiveTool?: (tool: AIWorkspaceTool) => void;
  academyDomain?: "ai" | "webdev" | "crm" | "emerging";
  setAcademyDomain?: (domain: "ai" | "webdev" | "crm" | "emerging") => void;
}

export default function AIWorkspaceTab({ 
  onSelectFreelancer,
  activeTool: propActiveTool,
  setActiveTool: propSetActiveTool,
  academyDomain: propAcademyDomain,
  setAcademyDomain: propSetAcademyDomain
}: AIWorkspaceTabProps) {
  const [localActiveTool, localSetActiveTool] = useState<AIWorkspaceTool>("search");
  const activeTool = propActiveTool !== undefined ? propActiveTool : localActiveTool;
  const setActiveTool = propSetActiveTool !== undefined ? propSetActiveTool : localSetActiveTool;

  // 5. AI Suite & Academy States
  const [suiteFilter, setSuiteFilter] = useState<"all" | "freelancer" | "company" | "platform">("all");
  
  const [localAcademyDomain, localSetAcademyDomain] = useState<"ai" | "webdev" | "crm" | "emerging">("ai");
  const academyDomain = propAcademyDomain !== undefined ? propAcademyDomain : localAcademyDomain;
  const setAcademyDomain = propSetAcademyDomain !== undefined ? propSetAcademyDomain : localSetAcademyDomain;
  const [simulatedTool, setSimulatedTool] = useState<string | null>(null);
  const [simulatorInput, setSimulatorInput] = useState("");
  const [simulatorOutput, setSimulatorOutput] = useState("");
  const [simulatorLoading, setSimulatorLoading] = useState(false);

  // 1. Natural Search Tool States
  const [searchQuery, setSearchQuery] = useState("I need a React developer with 5 years experience in India");
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searchAnalysis, setSearchAnalysis] = useState("");
  const [suggestedSalary, setSuggestedSalary] = useState("");
  const [searchHasRun, setSearchHasRun] = useState(false);
  const [searchOfflineMode, setSearchOfflineMode] = useState(false);

  // 2. Resume Parser States
  const [resumeText, setResumeText] = useState(`Alex Mercer
alex.mercer@gmail.com | Bangalore

EXPERIENCE
Salesforce CRM Developer | ApexDigital Corp (2023 - Present)
- Developed responsive custom web interfaces using Lightning Web Components (LWC).
- Programmed robust Apex Triggers and scheduled batches, optimizing query times by 30%.
- Integrated Salesforce pipelines with internal systems using basic REST webhooks.

Frontend Developer | WebCraft LLC (2021 - 2023)
- Built modular Single Page Applications in React and TypeScript styled with Tailwind.
- Utilized Git, GitHub Actions for deployment, and performed Jest testing.

SKILLS
Salesforce Admin, Apex Programming, LWC, React, TypeScript, Tailwind CSS, Git, PostgreSQL.`);
  const [parserLoading, setParserLoading] = useState(false);
  const [parsedData, setParsedData] = useState<any>(null);

  // 3. Interview Coach States
  const [interviewDomain, setInterviewDomain] = useState("Salesforce LWC & Apex");
  const [interviewHistory, setInterviewHistory] = useState<any[]>([]);
  const [currentAnswer, setCurrentAnswer] = useState("");
  const [coachLoading, setCoachLoading] = useState(false);
  const [coachFeedback, setCoachFeedback] = useState("");
  const [coachRating, setCoachRating] = useState("");
  const [coachNextQuestion, setCoachNextQuestion] = useState("Can you explain how state transitions and attributes are managed inside a Lightning Web Component constructor, and why Apex calls shouldn't be executed in it?");
  const [interviewStarted, setInterviewStarted] = useState(false);

  // 4. Draft Generator States
  const [projectReqs, setProjectReqs] = useState("We need a secure Salesforce Experience Cloud customer portal linked with MuleSoft API for real-time invoice sync.");
  const [freelancerSpecialty, setFreelancerSpecialty] = useState("Salesforce Architect with MuleSoft accreditation");
  const [docType, setDocType] = useState<"proposal" | "contract">("proposal");
  const [genLoading, setGenLoading] = useState(false);
  const [generatedDoc, setGeneratedDoc] = useState("");
  const [copied, setCopied] = useState(false);

  // Handlers
  const handleNaturalSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setSearchLoading(true);
    setSearchHasRun(true);
    try {
      const response = await fetch("/api/natural-search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: searchQuery })
      });
      const data = await response.json();
      setSearchResults(data.results || []);
      setSearchAnalysis(data.analysis || "");
      setSuggestedSalary(data.suggestedSalary || "");
      setSearchOfflineMode(!!data.offlineMode);
    } catch (err) {
      console.error(err);
    } finally {
      setSearchLoading(false);
    }
  };

  const handleAnalyzeResume = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resumeText.trim()) return;
    setParserLoading(true);
    try {
      const response = await fetch("/api/analyze-resume", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resumeText })
      });
      const data = await response.json();
      setParsedData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setParserLoading(false);
    }
  };

  const startInterview = () => {
    setInterviewStarted(true);
    setInterviewHistory([]);
    setCoachFeedback("");
    setCoachRating("");
    setCurrentAnswer("");
    // Hardcoded initial questions based on domain to start instantly
    if (interviewDomain.includes("React")) {
      setCoachNextQuestion("Can you explain the detailed differences between React's useMemo, useCallback, and standard component-level memoization, and what issues arise when functions are added to useEffect dependencies?");
    } else if (interviewDomain.includes("Generative")) {
      setCoachNextQuestion("How does Retrieval-Augmented Generation (RAG) differ from model fine-tuning in terms of dataset updates, computational costs, and hallucination control?");
    } else {
      setCoachNextQuestion("Can you explain how state transitions and attributes are managed inside a Lightning Web Component constructor, and why Apex calls shouldn't be executed in it?");
    }
  };

  const handleCoachAnswerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentAnswer.trim() || coachLoading) return;
    setCoachLoading(true);

    const stepAnswer = currentAnswer;
    setCurrentAnswer("");

    // Save history
    const updatedHistory = [
      ...interviewHistory,
      { role: "system", content: coachNextQuestion },
      { role: "user", content: stepAnswer }
    ];
    setInterviewHistory(updatedHistory);

    try {
      const response = await fetch("/api/interview-coach", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          domain: interviewDomain,
          history: updatedHistory,
          currentAnswer: stepAnswer
        })
      });
      const data = await response.json();
      setCoachFeedback(data.feedback);
      setCoachRating(data.rating);
      setCoachNextQuestion(data.nextQuestion);
    } catch (err) {
      console.error(err);
      setCoachFeedback("Your explanation was accepted but the AI coach could not evaluate technical correctness. Try providing more specific keywords regarding framework lifecycle rules!");
      setCoachRating("6/10");
    } finally {
      setCoachLoading(false);
    }
  };

  const handleGenerateProposal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectReqs.trim()) return;
    setGenLoading(true);
    setGeneratedDoc("");
    try {
      const response = await fetch("/api/generate-proposal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projectDetails: projectReqs,
          freelancerBio: freelancerSpecialty,
          type: docType
        })
      });
      const data = await response.json();
      setGeneratedDoc(data.proposal || "");
    } catch (err) {
      console.error(err);
      setGeneratedDoc("Failed to generate document draft.");
    } finally {
      setGenLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedDoc);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const runToolSimulation = (toolName: string) => {
    setSimulatedTool(toolName);
    setSimulatorLoading(true);
    setSimulatorOutput("");
    
    // Provide nice dynamic defaults based on selected tool
    let defaultInput = "";
    if (toolName === "AI Resume Builder") defaultInput = "React developer with 3 years at tech startups, skilled in Tailwind, Node, and AWS.";
    else if (toolName === "AI Cover Letter") defaultInput = "Salesforce CPQ Consultant applying for Senior Architect role at Accenture.";
    else if (toolName === "AI Cost Estimator") defaultInput = "Build a Web3 NFT marketplace with smart contracts and a clean dashboard. Timeline: 2 months.";
    else if (toolName === "AI Salary Predictor") defaultInput = "Machine Learning Engineer, Bangalore, India, 4 years experience, PyTorch.";
    else if (toolName === "AI Career Advisor") defaultInput = "Junior Frontend Dev wanting to transition to AI Solutions Architect in 12 months.";
    else if (toolName === "AI Skill Gap Analyzer") defaultInput = "My skills: React, JavaScript. Target role: Full Stack Node/React Developer.";
    else if (toolName === "AI Job Recommendation") defaultInput = "gopiiniyavan@gmail.com";
    else defaultInput = "Analyze requirements to generate premium AI insights.";

    setSimulatorInput(defaultInput);

    setTimeout(() => {
      setSimulatorLoading(false);
      let output = "";
      if (toolName === "AI Resume Builder") {
        output = `[ATS-Score: 94/100] TAILORED SUMMARY GENERATED:\n\n"Highly motivated React Frontend Developer with 3+ years of expertise constructing responsive web architectures and bento-grid dashboards. Proven success driving visual quality and performance using modern state managers (Redux, Context API) and lightweight animations. Skilled at translating brand aesthetics into intuitive, touch-friendly client-side layouts."\n\nRecommended Additions: Add specific metric 'Optimized page load times by 35% using lazy-loaded route chunking'.`;
      } else if (toolName === "AI Cover Letter") {
        output = `Subject: Application for Senior Salesforce Architect - Accenture\n\nDear Accenture Recruiting Team,\n\nI am writing to express my strong interest in your Senior Salesforce Architect placement. With extensive accredited expertise in Salesforce CPQ, custom Lightning Web Components (LWC), and complex multi-system integrations, I have successfully subsidized corporate operations and automated billing lines for Fortune 500 partners.\n\nHaving worked with multi-sig escrow systems and custom APIs, I bring robust security compliance and optimized Apex operations. I am excited to align my technical vetting with Accenture's direct client pipelines.\n\nSincerely,\nCertified Salesforce Expert`;
      } else if (toolName === "AI Cost Estimator") {
        output = `ESTIMATED BUDGET BREAKDOWN (Web3 NFT Marketplace):\n\n- UI/UX Responsive Dashboard: $2,800 (15 days)\n- Smart Contract Security (Solidity/EVM): $3,500 (20 days)\n- Indexing & Storage (The Graph / IPFS): $1,200 (10 days)\n- Core Integration & Testing: $1,500 (15 days)\n\nTOTAL PROJECT COST: $9,000 / ₹7,47,000\nREDUCED BUFFER: 5 days included for security validation audits.`;
      } else if (toolName === "AI Salary Predictor") {
        output = `REAL-TIME DEMAND & SALARY BENCHMARK (ML Engineer, Bangalore):\n\n- Emerging Tier 1 MNC Average: ₹18,50,000 - ₹34,00,000 / year ($22,000 - $41,000)\n- Freelance Hourly Standard: $45 - $80 / hour\n- Industry Demand Index: 9.8/10 (Extremely High)\n- Top Sponsoring Hubs: Google Cloud, Microsoft India, Capgemini.`;
      } else if (toolName === "AI Career Advisor") {
        output = `PERSONALIZED 12-MONTH STRATEGIC ROADMAP:\n\n- Month 1-3: Master Advanced TypeScript & Next.js App Router server actions.\n- Month 4-6: Complete Google Cloud AI & Machine Learning Fundamentals and @google/genai SDK integration.\n- Month 7-9: Build and deploy 3 server-side GenAI production apps with vector databases (Pinecone/ChromaDB).\n- Month 10-12: Complete SkillForge mock interview loops and match with Elite Tier 1 MNCs.`;
      } else if (toolName === "AI Skill Gap Analyzer") {
        output = `SKILL GAP ANALYSIS (Target: Full Stack Node/React Developer):\n\n- Current Skills: React, JavaScript\n- Missing Core Skills identified: Node.js (Express), PostgreSQL, TypeScript type-safety rules, REST API Security.\n- Gap Score: 60% Match.\n- Recommended Action: Review the 'Web Development Academy' inside FreelanceX to master Express routing and Prisma ORM within 5 hours.`;
      } else if (toolName === "AI Job Recommendation") {
        output = `HYPER-PERSONALIZED MATCHES (Updated 1 hour ago):\n\n1. Enterprise Salesforce Developer (Salesforce Systems) • Tier 1 Hub • ₹22L - ₹45L/yr\n2. Next.js 15 UI Designer-Developer (BioGen AI) • High Growth • $8,500 budget\n3. Front-End LWC Widget Integrator • Direct Pipeline Contract • $75/hour\n\nClick 'Apply Direct' in Sponsoring MNCs to dispatch credentials.`;
      } else {
        output = `[SIMULATION RESULT FOR ${toolName.toUpperCase()}]\n\nAction: Analyzed configuration payload.\nStatus: 100% Correct.\nInsights: Model output structured using GPT-4 / DeepSeek-V3 pipelines.\nRecommendations: Your profile rating is highly optimized. Sync LinkedIn, Unstop and GitHub to deploy custom credentials instantly.`;
      }
      setSimulatorOutput(output);
    }, 1200);
  };

  return (
    <div className="space-y-8">
      {/* Workspace Selector Tabs */}
      <div className="flex border-b border-white/10 scrollbar-none overflow-x-auto gap-2">
        {[
          { id: "search", label: "AI Search Matcher", icon: Search },
          { id: "resume-parser", label: "AI Resume Parser & Roadmap", icon: FileText },
          { id: "interview-coach", label: "AI Technical Interview Coach", icon: UserCheck },
          { id: "draft-generator", label: "AI Contract & Proposal Gen", icon: Code },
          { id: "ai-suite-directory", label: "20+ AI Tools & Academy", icon: Sparkles }
        ].map((tool) => {
          const Icon = tool.icon;
          return (
            <button
              key={tool.id}
              onClick={() => setActiveTool(tool.id as AIWorkspaceTool)}
              className={`flex items-center gap-2 px-5 py-3 text-xs sm:text-sm font-semibold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                activeTool === tool.id
                  ? "border-indigo-500 text-indigo-400 bg-indigo-950/10"
                  : "border-transparent text-slate-400 hover:text-slate-200"
              }`}
            >
              <Icon className="w-4 h-4" />
              {tool.label}
            </button>
          );
        })}
      </div>

      {/* TOOL 1: AI Natural Search Matcher */}
      {activeTool === "search" && (
        <div className="space-y-6">
          <div className="bg-[#141416] card-border rounded-xl p-6 md:p-8 space-y-4">
            <div className="space-y-1">
              <h2 className="text-xl font-bold text-white flex items-center gap-2 font-display">
                <Sparkles className="w-5 h-5 text-indigo-400" />
                Natural Language Developer Matcher
              </h2>
              <p className="text-xs sm:text-sm text-slate-400">
                Type what you need in plain English. The AI parses the skills, filters geographical requirements, matches candidates with accuracy scores, and estimates project salaries.
              </p>
            </div>

            <form onSubmit={handleNaturalSearch} className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder='e.g., "I need a React developer with 5 years experience in India"'
                className="flex-1 bg-[#09090b] border border-white/10 rounded-xl px-4 py-3 text-slate-200 text-sm focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                disabled={searchLoading}
                className="accent-gradient disabled:bg-[#141416] text-white font-bold px-6 py-3 rounded-xl transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer shadow-lg shadow-indigo-500/10"
              >
                {searchLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Analyzing Request
                  </>
                ) : (
                  <>
                    AI Match
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </div>

          {searchHasRun && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in duration-300">
              {/* Left 2 Columns: Match Results */}
              <div className="lg:col-span-2 space-y-4">
                <div className="flex justify-between items-center bg-[#09090b] px-4 py-2.5 rounded-lg border border-white/5">
                  <span className="text-xs text-slate-400">AI Verified Rankings:</span>
                  {searchOfflineMode && (
                    <span className="text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded">Demo Engine Mode</span>
                  )}
                </div>

                {searchResults.length === 0 ? (
                  <div className="bg-[#141416]/30 border border-white/5 rounded-xl p-8 text-center text-slate-400 text-xs">
                    No developers matched this exact semantic criteria. Try broadening your query!
                  </div>
                ) : (
                  <div className="space-y-4">
                    {searchResults.map((dev: any) => (
                      <div
                        key={dev.id}
                        className="bg-[#141416] card-border hover:border-indigo-500/30 rounded-xl p-5 flex flex-col md:flex-row justify-between gap-4 transition-all duration-300"
                      >
                        <div className="flex gap-4">
                          <img src={dev.avatar} alt={dev.name} className="w-12 h-12 rounded-lg object-cover border border-white/5 shrink-0" />
                          <div className="space-y-1.5 min-w-0">
                            <div className="flex items-center gap-2">
                              <h3 className="font-bold text-sm sm:text-base text-white">{dev.name}</h3>
                              <span className="text-xs text-slate-400">({dev.location})</span>
                            </div>
                            <p className="text-xs text-slate-300 font-semibold">{dev.title}</p>
                            <p className="text-xs text-slate-400 leading-relaxed max-w-xl">{dev.bio}</p>
                            
                            {dev.matchReason && (
                              <p className="text-xs text-indigo-400 font-mono bg-indigo-950/20 px-2.5 py-1 rounded border border-indigo-900/30 flex items-center gap-1.5">
                                <Brain className="w-3.5 h-3.5 shrink-0" />
                                {dev.matchReason}
                              </p>
                            )}

                            <div className="flex flex-wrap gap-1">
                              {dev.skills.map((skill: string, sIdx: number) => (
                                <span key={sIdx} className="px-2 py-0.5 bg-[#09090b] text-slate-400 text-[10px] rounded border border-white/5">
                                  {skill}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Matching Score / Hiring Stats */}
                        <div className="text-right flex md:flex-col justify-between md:justify-center items-center md:items-end gap-3 shrink-0 border-t md:border-t-0 border-white/5 pt-3 md:pt-0">
                          <div>
                            <span className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400 glow-text">{dev.matchingScore}%</span>
                            <span className="text-[9px] text-slate-500 block font-bold">MATCH SCORE</span>
                          </div>
                          <button
                            onClick={() => onSelectFreelancer(dev)}
                            className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs px-4 py-2 rounded-lg transition-all cursor-pointer"
                          >
                            Review Profile
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Right 1 Column: AI Market Analysis */}
              <div className="space-y-4">
                <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
                  <h3 className="font-bold text-sm text-slate-200">AI Market Insight</h3>
                  
                  {suggestedSalary && (
                    <div className="space-y-1.5 p-3.5 bg-[#09090b] rounded-lg border border-white/5">
                      <span className="text-xs text-slate-500 block font-semibold uppercase">Predicted Salary Range</span>
                      <span className="text-lg font-bold text-indigo-400">{suggestedSalary}</span>
                    </div>
                  )}

                  {searchAnalysis && (
                    <div className="space-y-2 text-xs text-slate-400 leading-relaxed">
                      <span className="text-xs text-slate-300 font-bold block">Intent Parsing Evaluation</span>
                      <p>{searchAnalysis}</p>
                    </div>
                  )}

                  <div className="border-t border-white/5 pt-3 text-[11px] text-slate-500 space-y-1.5">
                    <span className="font-bold text-slate-400 block uppercase">Matched Parameters</span>
                    <p>✓ Geographical constraints extracted.</p>
                    <p>✓ Minimum experience boundaries matched.</p>
                    <p>✓ Technical skill hierarchy mapped.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TOOL 2: AI Resume Parser & Career Planner */}
      {activeTool === "resume-parser" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Left panel: Input Paste */}
          <div className="bg-[#141416] card-border rounded-xl p-6 space-y-4 flex flex-col justify-between">
            <div className="space-y-1.5">
              <h2 className="font-bold text-lg text-white flex items-center gap-2 font-display">
                <Brain className="w-5 h-5 text-indigo-400" />
                Resume & Profile Parser
              </h2>
              <p className="text-xs text-slate-400">
                Paste your current resume or profile. The model will parse your key skills, list certifications, find critical technology gaps for advanced roles, and chart an optimal learning roadmap.
              </p>
            </div>

            <form onSubmit={handleAnalyzeResume} className="space-y-4 flex-1 flex flex-col pt-3">
              <textarea
                value={resumeText}
                onChange={(e) => setResumeText(e.target.value)}
                placeholder="Paste profile text here..."
                rows={12}
                className="w-full flex-1 bg-[#09090b] border border-white/10 rounded-lg p-4 text-slate-200 text-xs sm:text-sm focus:outline-none focus:border-indigo-500 font-mono"
              />
              <button
                type="submit"
                disabled={parserLoading}
                className="w-full accent-gradient disabled:bg-[#09090b] text-white font-bold py-3 rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                {parserLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Evaluating Skill Taxonomy...
                  </>
                ) : (
                  <>
                    Analyze Profile
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Right panel: Parsed Outcomes */}
          <div className="bg-[#141416] card-border rounded-xl p-6 space-y-6">
            {!parsedData ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-500 space-y-2">
                <FileText className="w-12 h-12 text-slate-500/40 animate-pulse" />
                <h3 className="font-bold text-sm text-slate-400">Analysis Pending</h3>
                <p className="text-xs max-w-xs">Paste your resume and click Analyze Profile to see parsed technology charts and gaps.</p>
              </div>
            ) : (
              <div className="space-y-6 animate-in fade-in duration-300 max-h-[500px] overflow-y-auto pr-1">
                {/* Parsed Basic Info */}
                <div className="pb-4 border-b border-white/5">
                  <h3 className="text-lg font-black text-white">{parsedData.parsedName}</h3>
                  <span className="text-xs text-indigo-400 font-mono">{parsedData.parsedTitle}</span>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">{parsedData.experienceSummary}</p>
                </div>

                {/* Parsed Skills */}
                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Identified Skills</span>
                  <div className="flex flex-wrap gap-1.5">
                    {parsedData.skills.map((s: string, idx: number) => (
                      <span key={idx} className="px-2 py-0.5 bg-[#09090b] text-slate-300 rounded border border-white/5 text-[11px]">
                        ✓ {s}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Skill Gaps & Advice */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block flex items-center gap-1">
                    <AlertCircle className="w-4 h-4 text-amber-500" />
                    Critical Technology Skill Gaps
                  </span>
                  <div className="space-y-2">
                    {parsedData.skillGaps.map((gap: any, idx: number) => (
                      <div key={idx} className="p-3 bg-[#09090b] rounded-lg border border-white/5 flex gap-2.5 items-start">
                        <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border uppercase shrink-0 mt-0.5 ${
                          gap.criticality === 'High' ? 'bg-red-500/10 text-red-400 border-red-500/20' : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                        }`}>
                          {gap.criticality}
                        </span>
                        <div>
                          <strong className="text-xs text-white block">{gap.skill}</strong>
                          <span className="text-[11px] text-slate-400 block mt-0.5 leading-relaxed">{gap.advice}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Interactive Learning Roadmap steps */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Optimal Career Path & Roadmaps</span>
                  <div className="p-3.5 bg-[#09090b] rounded-lg border border-white/5 text-xs space-y-4">
                    <div>
                      <span className="text-slate-500 block">Target Aspiration:</span>
                      <span className="font-bold text-indigo-400">{parsedData.careerPath}</span>
                    </div>
                    
                    <div className="space-y-3 pt-2 border-t border-white/5">
                      {parsedData.learningRoadmap.map((road: any, rIdx: number) => (
                        <div key={rIdx} className="space-y-1.5">
                           <span className="font-bold text-slate-300 text-[11px] block">{road.phase}</span>
                          <div className="space-y-1">
                            {road.steps.map((st: string, sIdx: number) => (
                              <div key={sIdx} className="flex items-center gap-2 text-[11px] text-slate-400 pl-2">
                                <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full shrink-0" />
                                <span>{st}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TOOL 3: AI Interview Coach */}
      {activeTool === "interview-coach" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8" id="ai-interview-prep-hub-root">
          
          {/* Left Panel: Domain Selector cards & cheatsheets */}
          <div className="space-y-6">
            
            {/* Domain selector bento cards */}
            <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
              <div className="space-y-1">
                <span className="text-[9px] font-extrabold uppercase text-indigo-400 font-mono tracking-wider bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20 inline-block">
                  PREP MODE ACTIVE
                </span>
                <h3 className="font-bold text-sm text-slate-200 font-display">Configure Prep Subject</h3>
                <p className="text-[11px] text-slate-500">Pick a technology vertical to initialize the AI Mock Interview node</p>
              </div>

              <div className="space-y-2.5">
                {[
                  { name: "React Frontend Developer", desc: "React 19, RSC rendering, Vite & state lifters", diff: "Advanced", icon: "🌐" },
                  { name: "Salesforce LWC & Apex", desc: "Enterprise CRM, SOQL governor limits & Triggers", diff: "Enterprise", icon: "⚡" },
                  { name: "Generative AI LLM Specialist", desc: "Retrieval (RAG), vector databases & prompt trees", diff: "Cutting-edge", icon: "🧠" },
                  { name: "Cloud Kubernetes Platforms", desc: "Docker boundaries, namespace routing & CI/CD", diff: "Architect", icon: "🛰️" }
                ].map((dom) => {
                  const isSelected = interviewDomain === dom.name;
                  return (
                    <button
                      key={dom.name}
                      type="button"
                      disabled={interviewStarted}
                      onClick={() => setInterviewDomain(dom.name)}
                      className={`w-full p-3 rounded-xl border text-left transition-all duration-200 cursor-pointer flex gap-3 ${
                        isSelected
                          ? "bg-indigo-950/20 border-indigo-500 text-white shadow"
                          : "bg-[#09090b] border-white/5 text-slate-400 hover:text-slate-200 hover:border-white/10 disabled:opacity-50"
                      }`}
                    >
                      <span className="text-xl shrink-0 mt-0.5">{dom.icon}</span>
                      <div className="space-y-0.5 min-w-0">
                        <div className="flex justify-between items-center gap-1.5">
                          <span className="font-bold text-xs truncate">{dom.name}</span>
                          <span className={`text-[8px] font-bold px-1.5 py-0.2 rounded shrink-0 uppercase border ${
                            isSelected ? "bg-indigo-500/15 border-indigo-500/20 text-indigo-300" : "bg-[#141416] border-white/5 text-slate-500"
                          }`}>
                            {dom.diff}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-500 leading-tight truncate">{dom.desc}</p>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="pt-2">
                {!interviewStarted ? (
                  <button
                    onClick={startInterview}
                    className="w-full accent-gradient text-white font-extrabold py-3 rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-500/15 group"
                  >
                    <span>Activate Live Prep Node</span>
                    <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                  </button>
                ) : (
                  <button
                    onClick={() => setInterviewStarted(false)}
                    className="w-full bg-[#09090b] hover:bg-white/5 text-red-400 border border-white/10 py-2.5 rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer font-bold"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Reset Prep Session
                  </button>
                )}
              </div>
            </div>

            {/* Quick references cheatsheet dashboard drawer */}
            <div className="bg-[#141416] card-border rounded-xl p-5 space-y-4">
              <div className="space-y-1">
                <h4 className="font-bold text-xs text-slate-300 uppercase tracking-wider font-mono">
                  📖 Quick Reference Cheatsheet
                </h4>
                <p className="text-[11px] text-slate-500">Key benchmarks tested during sponsoring MNC evaluation rounds</p>
              </div>

              <div className="p-3.5 bg-[#09090b] border border-white/5 rounded-xl space-y-3 text-xs leading-relaxed text-slate-300">
                {interviewDomain.includes("React") && (
                  <>
                    <div>
                      <strong className="text-indigo-400 block mb-0.5">1. React rendering rules:</strong>
                      <span className="text-[11px] text-slate-400">Keep side-effects isolated in hooks with primitive dependencies. Avoid re-binding objects on every render cycle.</span>
                    </div>
                    <div>
                      <strong className="text-indigo-400 block mb-0.5">2. RSC Boundaries:</strong>
                      <span className="text-[11px] text-slate-400">Server Components render on Node and transfer JSON. Keep state modifiers on the client side with "use client" directives.</span>
                    </div>
                  </>
                )}
                {interviewDomain.includes("Salesforce") && (
                  <>
                    <div>
                      <strong className="text-indigo-400 block mb-0.5">1. Governor Limit Controls:</strong>
                      <span className="text-[11px] text-slate-400">Never execute SOQL queries or DML statements inside loop blocks. Store elements in lists to bulkify.</span>
                    </div>
                    <div>
                      <strong className="text-indigo-400 block mb-0.5">2. Apex Lifecycle:</strong>
                      <span className="text-[11px] text-slate-400">Triggers should defer logic to handler classes. Never instanciate network requests directly inside triggers.</span>
                    </div>
                  </>
                )}
                {interviewDomain.includes("Generative") && (
                  <>
                    <div>
                      <strong className="text-indigo-400 block mb-0.5">1. Retrieval-Augmented Generation (RAG):</strong>
                      <span className="text-[11px] text-slate-400">Performs real-time search on high-dimensional vector databases without expensive retraining or fine-tuning runs.</span>
                    </div>
                    <div>
                      <strong className="text-indigo-400 block mb-0.5">2. Hallucination Control:</strong>
                      <span className="text-[11px] text-slate-400">Configure strict temperature limits (e.g. 0.0), ground responses in context tokens, and utilize precise system schemas.</span>
                    </div>
                  </>
                )}
                {interviewDomain.includes("Cloud") && (
                  <>
                    <div>
                      <strong className="text-indigo-400 block mb-0.5">1. Kubernetes Namespace Limits:</strong>
                      <span className="text-[11px] text-slate-400">Route container services locally within secure namespaces. Avoid cross-namespace visual exposures unless bridged.</span>
                    </div>
                    <div>
                      <strong className="text-indigo-400 block mb-0.5">2. Self-Healing Pods:</strong>
                      <span className="text-[11px] text-slate-400">Define precise readiness and liveness endpoints so orchestrators can automatically recycle failing nodes.</span>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Right Panel: Conversation simulation interface or splash prep dashboard */}
          <div className="lg:col-span-2 space-y-6">
            {!interviewStarted ? (
              <div className="bg-[#141416] card-border rounded-xl p-6 sm:p-8 space-y-6 animate-in fade-in duration-300">
                
                {/* Visual Intro banner */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#09090b] p-5 rounded-2xl border border-white/5 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />
                  <div className="space-y-1.5 max-w-md">
                    <span className="text-[9px] font-bold text-indigo-400 font-mono uppercase bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20 inline-block">
                      MNC SPECIFIC TRAINING
                    </span>
                    <h3 className="text-lg font-bold text-white font-display">Technical Assessment Simulator</h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Evaluate your skills against active placement metrics for Google Cloud, Accenture, and Salesforce. Passing scores unlock direct recruitment priority vouchers.
                    </p>
                  </div>
                  <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20 shrink-0">
                    <Brain className="w-8 h-8 animate-pulse" />
                  </div>
                </div>

                {/* Benchmark score indicator */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="p-4 bg-[#09090b] border border-white/5 rounded-xl space-y-1 text-center">
                    <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider font-mono">Global Tier Pass</span>
                    <span className="text-2xl font-black text-emerald-400 block mt-1">85% Score</span>
                    <span className="text-[9px] text-slate-500 block">Requires thorough answers</span>
                  </div>
                  <div className="p-4 bg-[#09090b] border border-white/5 rounded-xl space-y-1 text-center">
                    <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider font-mono">Vetting Accuracy</span>
                    <span className="text-2xl font-black text-indigo-400 block mt-1">Real-Time</span>
                    <span className="text-[9px] text-slate-500 block">AI parses syntax & logic</span>
                  </div>
                  <div className="p-4 bg-[#09090b] border border-white/5 rounded-xl space-y-1 text-center">
                    <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider font-mono">Interview Depth</span>
                    <span className="text-2xl font-black text-purple-400 block mt-1">Challenging</span>
                    <span className="text-[9px] text-slate-500 block">Deep architectural rounds</span>
                  </div>
                </div>

                {/* Algorithmic Warm-up Challenge */}
                <div className="space-y-3">
                  <h4 className="font-bold text-xs text-slate-300 uppercase tracking-wider font-mono">
                    🔥 Algorithmic Warm-up Challenge
                  </h4>
                  
                  <div className="p-4.5 bg-[#09090b] rounded-xl border border-white/5 space-y-3 text-xs leading-relaxed">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-slate-200">Problem: Handling asynchronous race conditions</span>
                      <span className="text-[9px] bg-amber-500/15 text-amber-400 border border-amber-500/25 px-2 py-0.5 rounded font-mono">DUMMY QUESTION</span>
                    </div>
                    <p className="text-slate-400">
                      When dispatching multiple network requests in React, why do you need an active Boolean cleanup variable or an AbortController inside your useEffect side-effect block?
                    </p>
                    <div className="p-3 bg-[#141416] rounded-lg border border-white/5 text-slate-300 font-mono leading-relaxed text-[11px]">
                      "To signal to the browser's fetch API that previous out-of-order responses should be safely discarded, preventing stale state updates on dismounted components."
                    </div>
                  </div>
                </div>

                {/* Action button to initialize */}
                <div className="flex justify-center pt-2">
                  <button
                    onClick={startInterview}
                    className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-indigo-500/20 cursor-pointer flex items-center gap-1.5 transition-all"
                  >
                    <span>Launch AI Mock Questioner Node</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-[#141416] card-border rounded-xl p-5 min-h-[500px] flex flex-col justify-between" id="active-prep-dialogue">
                <div className="flex-1 flex flex-col justify-between gap-5">
                  
                  {/* Current Active Question Board */}
                  <div className="space-y-4">
                    <div className="flex justify-between items-center border-b border-white/5 pb-3">
                      <div className="flex items-center gap-1.5 text-xs text-indigo-400 font-mono font-bold">
                        <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                        AI COGNITIVE QUESTIONER INTERACTION
                      </div>
                      <span className="text-[10px] text-slate-500 font-bold font-mono uppercase">{interviewDomain}</span>
                    </div>

                    <div className="bg-[#09090b] rounded-xl p-4.5 border border-indigo-500/20 relative overflow-hidden space-y-2">
                      <span className="text-[9px] px-2 py-0.5 bg-indigo-900/30 text-indigo-400 rounded-full font-mono font-bold uppercase tracking-wide border border-indigo-500/20">
                        AI COCHLEATE PROMPT
                      </span>
                      <p className="text-slate-200 font-bold text-xs sm:text-sm mt-2 leading-relaxed">{coachNextQuestion}</p>
                    </div>

                    {/* Feedback and evaluation metrics dashboard */}
                    {coachFeedback && (
                      <div className="bg-[#09090b]/60 rounded-xl p-4.5 border border-white/5 space-y-3.5 animate-in slide-in-from-top-4 duration-300">
                        <div className="flex justify-between items-center border-b border-white/5 pb-2">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                            Technical Feedback Evaluator
                          </span>
                          {coachRating && (
                            <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-400">
                              <span>Rating:</span>
                              <span className="px-2 py-0.5 bg-indigo-950/40 border border-indigo-500/20 rounded font-mono">{coachRating}</span>
                            </div>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 leading-relaxed">{coachFeedback}</p>
                      </div>
                    )}
                  </div>

                  {/* Form to submit answer response */}
                  <form onSubmit={handleCoachAnswerSubmit} className="space-y-3 pt-3 border-t border-white/10">
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center text-xs">
                        <label className="font-bold text-slate-300">Your Technical Explanation or Code Solution</label>
                        <span className="text-[10px] text-slate-500 font-mono">Use descriptive language and outline edge-cases</span>
                      </div>
                      <textarea
                        value={currentAnswer}
                        onChange={(e) => setCurrentAnswer(e.target.value)}
                        placeholder="Explain your architectural design, write typescript/apex code blocks, or discuss performance optimization rules..."
                        rows={5}
                        required
                        className="w-full bg-[#09090b] border border-white/10 rounded-xl p-3.5 text-slate-200 text-xs sm:text-sm focus:outline-none focus:border-indigo-500 font-mono leading-relaxed"
                      />
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-[10px] text-slate-500 flex items-center gap-1.5">
                        <AlertCircle className="w-3.5 h-3.5 text-slate-600" />
                        Submitting prompts the evaluation node to compute syntax metrics.
                      </span>

                      <button
                        type="submit"
                        disabled={coachLoading || !currentAnswer.trim()}
                        className="accent-gradient disabled:bg-[#09090b] text-white text-xs font-bold px-6 py-3 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
                      >
                        {coachLoading ? (
                          <>
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            Evaluating Logic...
                          </>
                        ) : (
                          <>
                            Submit Assessment Answer
                            <Send className="w-3.5 h-3.5" />
                          </>
                        )}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TOOL 4: AI Proposal / Contract Generator */}
      {activeTool === "draft-generator" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Inputs Panel */}
          <div className="bg-[#141416] card-border rounded-xl p-6 space-y-5 flex flex-col justify-between">
            <div className="space-y-1.5">
              <h2 className="font-bold text-lg text-white flex items-center gap-2 font-display">
                <Code className="w-5 h-5 text-indigo-400" />
                AI Proposal & Contract Drafter
              </h2>
              <p className="text-xs text-slate-400">
                Instantly draft high-conversion freelance project proposals or legally protective contracts. Specify requirements and matching consultant skills to generate custom templates.
              </p>
            </div>

            <form onSubmit={handleGenerateProposal} className="space-y-4 flex-1 pt-2">
              <div className="flex gap-2 p-1.5 bg-[#09090b] rounded-lg border border-white/5">
                <button
                  type="button"
                  onClick={() => setDocType("proposal")}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded transition-all cursor-pointer ${
                    docType === "proposal" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  Freelance Proposal
                </button>
                <button
                  type="button"
                  onClick={() => setDocType("contract")}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded transition-all cursor-pointer ${
                    docType === "contract" ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  Independent Contract
                </button>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-300">Project / Hiring Requirements</label>
                <textarea
                  rows={3}
                  value={projectReqs}
                  onChange={(e) => setProjectReqs(e.target.value)}
                  placeholder="Enter project goals, deliverables, technologies..."
                  className="w-full bg-[#09090b] border border-white/10 rounded-lg p-3 text-slate-200 text-xs sm:text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-300">Freelancer Specialty / Bio Context</label>
                <input
                  type="text"
                  value={freelancerSpecialty}
                  onChange={(e) => setFreelancerSpecialty(e.target.value)}
                  placeholder="e.g. Salesforce Architect with MuleSoft accreditation"
                  className="w-full bg-[#09090b] border border-white/10 rounded-lg px-3 py-2 text-slate-200 text-xs sm:text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>

              <button
                type="submit"
                disabled={genLoading}
                className="w-full accent-gradient disabled:bg-[#09090b] text-white font-bold py-3 rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                {genLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Structuring Legal Clauses...
                  </>
                ) : (
                  <>
                    Generate Draft Template
                    <Sparkles className="w-4 h-4 text-yellow-300" />
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Generated Text Area Panel */}
          <div className="bg-[#141416] card-border rounded-xl p-6 flex flex-col justify-between min-h-[400px]">
            {!generatedDoc ? (
              <div className="h-full flex-1 flex flex-col items-center justify-center text-center p-8 text-slate-500 space-y-2">
                <FileText className="w-12 h-12 text-slate-500/40 animate-pulse" />
                <h3 className="font-bold text-sm text-slate-400">Template Generation Pending</h3>
                <p className="text-xs max-w-xs">Fill in project specs on the left and click Generate Draft Template to build professional documentation.</p>
              </div>
            ) : (
              <div className="flex-1 flex flex-col justify-between h-full space-y-4 animate-in fade-in duration-300">
                <div className="flex justify-between items-center bg-[#09090b] px-3 py-2 rounded border border-white/5 shrink-0">
                  <span className="text-xs font-bold text-indigo-400 font-mono uppercase">{docType} DRAFT</span>
                  <button
                    onClick={copyToClipboard}
                    className="text-xs text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    {copied ? (
                      <>
                        <Check className="w-4 h-4 text-indigo-400" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        Copy text
                      </>
                    )}
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto bg-[#09090b]/80 border border-white/5 rounded-lg p-4 font-mono text-xs text-slate-300 whitespace-pre-wrap leading-relaxed max-h-[380px]">
                  {generatedDoc}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TOOL 5: 20+ AI Tools & Academy Portal */}
      {activeTool === "ai-suite-directory" && (
        <div className="space-y-12 animate-in fade-in duration-500">
          
          {/* SIMULATION CONSOLE MODAL / BANNER */}
          {simulatedTool && (
            <div className="bg-[#141416] border-2 border-indigo-500/30 rounded-xl p-6 relative overflow-hidden animate-in zoom-in duration-200">
              <div className="absolute -top-12 -right-12 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl" />
              <button 
                onClick={() => setSimulatedTool(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white text-xs font-bold cursor-pointer"
              >
                ✕ Close Simulator
              </button>
              
              <div className="flex flex-col md:flex-row gap-6">
                <div className="md:w-1/2 space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-[10px] text-emerald-400 font-mono uppercase tracking-widest font-bold">LIVE INTELLIGENT WRAPPER ACTIVE</span>
                  </div>
                  <h3 className="text-lg font-bold text-white font-display">Active Trial: {simulatedTool}</h3>
                  <p className="text-xs text-slate-400">Interact with the real-time model output generated by FreelanceX's multi-tier orchestration layer.</p>
                  
                  <div className="space-y-2">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase">Input Payload Context</label>
                    <input 
                      type="text" 
                      value={simulatorInput} 
                      onChange={(e) => setSimulatorInput(e.target.value)}
                      className="w-full bg-[#09090b] border border-white/10 rounded-lg px-3 py-2 text-xs text-slate-200 font-mono focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <button 
                    onClick={() => runToolSimulation(simulatedTool)}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs transition-all cursor-pointer shadow-md shadow-indigo-500/10"
                  >
                    Execute AI Pipeline
                  </button>
                </div>

                <div className="md:w-1/2 bg-[#09090b] border border-white/5 rounded-lg p-4 font-mono text-xs flex flex-col justify-between min-h-[160px]">
                  <div>
                    <span className="text-[9px] text-indigo-400 uppercase font-bold tracking-widest block mb-2">SYSTEM TELEMETRY RESPONSE:</span>
                    {simulatorLoading ? (
                      <div className="flex items-center gap-2 text-slate-400 py-4">
                        <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
                        <span>Querying LLM node clusters...</span>
                      </div>
                    ) : (
                      <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">{simulatorOutput || "Execute the AI pipeline above to view live diagnostic response metrics."}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 1: 20 AI-Powered Tools Suite */}
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
              <div>
                <span className="text-xs font-bold text-indigo-400 font-mono tracking-widest uppercase">ROBUST PLATFORM SUITE</span>
                <h2 className="text-2xl font-extrabold text-white font-display">20 AI-Powered Tools & Engines</h2>
                <p className="text-slate-400 text-xs sm:text-sm mt-1 max-w-2xl">
                  From deep technical vetting to comprehensive security checks, FreelanceX integrates professional models including GPT-4, Llama, and DeepSeek.
                </p>
              </div>

              {/* Filters */}
              <div className="flex flex-wrap gap-1.5 p-1 bg-[#141416] border border-white/5 rounded-lg">
                {[
                  { id: "all", label: "All Tools" },
                  { id: "freelancer", label: "For Freelancers" },
                  { id: "company", label: "For Companies" },
                  { id: "platform", label: "Platform & Security" }
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setSuiteFilter(f.id as any)}
                    className={`px-3 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                      suiteFilter === f.id ? "bg-indigo-600 text-white shadow" : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Grid of 20 Tools */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {[
                { name: "AI Resume Builder", icon: "📄", role: "freelancer", tag: "HOT", desc: "Generate ATS-optimized resumes tailored to specific job descriptions instantly." },
                { name: "AI Interview Coach", icon: "🎙️", role: "freelancer", tag: "POPULAR", desc: "Practice domain-specific interview questions with real-time AI feedback and scoring." },
                { name: "AI Coding Assistant", icon: "💻", role: "freelancer", tag: "NEW", desc: "Resolve bugs, refactor legacy code blocks, and explain system architecture." },
                { name: "AI Portfolio Generator", icon: "✨", role: "freelancer", tag: "PRO", desc: "Compile public GitHub repositories and active contract achievements into a responsive visual showcase." },
                { name: "AI Cover Letter Writer", icon: "✉️", role: "freelancer", tag: "EASY", desc: "Drafter that translates your skills into beautiful customized introductory cover letters." },
                { name: "AI Proposal Generator", icon: "📝", role: "freelancer", tag: "FREE", desc: "Generate high-conversion freelance project proposals targeting top MNC scopes." },
                { name: "AI Contract Generator", icon: "⚖️", role: "platform", tag: "LEGAL", desc: "Structure legally protective freelance contracts with automated dispute fallback terms." },
                { name: "AI Cost Estimator", icon: "💰", role: "company", tag: "SAVING", desc: "Estimate detailed budget breakdowns for custom software requirement documents." },
                { name: "AI Freelancer Ranking", icon: "📈", role: "company", tag: "SMART", desc: "Vetting engine that reads incoming proposals and ranks talent based on proven success." },
                { name: "AI Fraud Detection", icon: "🛡️", role: "platform", tag: "SECURE", desc: "Prevent duplicate payouts, detect malicious code pushes, and protect active escrow deposits." },
                { name: "AI Duplicate Detection", icon: "🖨️", role: "platform", tag: "VETTED", desc: "Flag spam bids and duplicate developer portfolios claiming unverified certifications." },
                { name: "AI Scam Detection", icon: "⚠️", role: "platform", tag: "SHIELD", desc: "Analyze public corporate details and recruitment pipelines to shield talent from fake listings." },
                { name: "AI Salary Predictor", icon: "💵", role: "freelancer", tag: "POPULAR", desc: "Real-time global and local currency compensation analysis for major tech roles." },
                { name: "AI Career Advisor", icon: "🎯", role: "freelancer", tag: "BEST", desc: "Get tailored advice on emerging skills, certified modules, and transition roadmaps." },
                { name: "AI Skill Gap Analyzer", icon: "🔍", role: "freelancer", tag: "NEW", desc: "Scan current profiles against active enterprise job requirements to spot key educational gaps." },
                { name: "AI Learning Roadmap", icon: "🗺️", role: "freelancer", tag: "ACADEMY", desc: "Generates custom visual step-by-step learning modules based on target MNC parameters." },
                { name: "AI Job Recommendation", icon: "💡", role: "freelancer", tag: "MATCH", desc: "Intelligent matchmaking that pairs verified handles with high-paying tier-1 contracts." },
                { name: "AI Team Builder", icon: "👥", role: "company", tag: "ENTERPRISE", desc: "Assemble ready-to-work teams of engineers and cloud architects based on structured technical goals." },
                { name: "AI Timeline Generator", icon: "📅", role: "company", tag: "AESTHETIC", desc: "Automate milestones, sprint structures, and technical review timelines based on project briefs." },
                { name: "AI Resume Parser", icon: "📂", role: "company", tag: "FAST", desc: "Scan and categorize hundreds of PDF/TXT resumes in seconds with instant skills matching." }
              ]
                .filter(tool => suiteFilter === "all" || tool.role === suiteFilter)
                .map((tool, idx) => (
                  <div 
                    key={idx} 
                    className="bg-[#141416] hover:bg-[#1b1b1d] border border-white/5 rounded-xl p-4.5 flex flex-col justify-between space-y-4 hover:border-indigo-500/20 transition-all duration-300 group"
                  >
                    <div className="space-y-2.5">
                      <div className="flex justify-between items-center">
                        <span className="text-2xl">{tool.icon}</span>
                        {tool.tag && (
                          <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold border ${
                            tool.tag === "HOT" || tool.tag === "SECURE"
                              ? "bg-rose-500/10 text-rose-400 border-rose-500/20"
                              : "bg-indigo-500/10 text-indigo-400 border-indigo-500/20"
                          }`}>
                            {tool.tag}
                          </span>
                        )}
                      </div>
                      
                      <div className="space-y-1">
                        <h4 className="font-bold text-sm text-slate-200 group-hover:text-white transition-colors">{tool.name}</h4>
                        <p className="text-[11px] text-slate-500 leading-relaxed">{tool.desc}</p>
                      </div>
                    </div>

                    <button 
                      onClick={() => runToolSimulation(tool.name)}
                      className="w-full py-1.5 bg-[#09090b] hover:bg-indigo-950/20 text-slate-400 hover:text-indigo-400 border border-white/5 hover:border-indigo-500/30 text-[10px] font-bold rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <span>Interactive Live Trial</span>
                      <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  </div>
                ))}
            </div>
          </div>

          {/* SECTION 2: Study Academy & MNCs Interview Cracking */}
          <div className="bg-gradient-to-b from-[#141416] to-[#0b0b0d] border border-white/5 rounded-2xl p-6 sm:p-8 space-y-8" id="study-academy-section">
            <div className="space-y-1">
              <span className="text-xs font-bold text-indigo-400 font-mono tracking-widest uppercase">STUDY PLATFORM & PATHWAYS</span>
              <h2 className="text-xl sm:text-2xl font-extrabold text-white font-display">Learning Academy & MNC Preparation Hub</h2>
              <p className="text-slate-400 text-xs sm:text-sm">
                Unlock high-retention mock questions, step-by-step guides, and technical cheat sheets to easily crack company recruitment rounds.
              </p>
            </div>

            {/* Academy Tabs */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 border-b border-white/5 pb-4">
              {[
                { id: "ai", label: "Artificial Intelligence", desc: "ML, LLMs, Vector DBs", icon: "🧠" },
                { id: "webdev", label: "Web Development", desc: "Next.js, Node, React", icon: "🌐" },
                { id: "crm", label: "Enterprise CRM", desc: "Salesforce LWC, Apex", icon: "⚡" },
                { id: "emerging", label: "Emerging Tech", desc: "Blockchain, DevOps, Cloud", icon: "🛰️" }
              ].map((domain) => (
                <button
                  key={domain.id}
                  onClick={() => setAcademyDomain(domain.id as any)}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    academyDomain === domain.id
                      ? "bg-indigo-950/20 border-indigo-500/40 text-white shadow-lg"
                      : "bg-[#09090b] border-white/5 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{domain.icon}</span>
                    <span className="font-bold text-xs sm:text-sm truncate">{domain.label}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block font-medium">{domain.desc}</span>
                </button>
              ))}
            </div>

            {/* Academy Tab Content */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* How to Crack MNC Interviews (Column 1 & 2) */}
              <div className="lg:col-span-2 space-y-6">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-1.5 font-display">
                    <CheckCircle2 className="w-5 h-5 text-indigo-400" />
                    How to Crack Sponsoring MNCs (Step-by-Step Guide)
                  </h3>
                  <p className="text-xs text-slate-500">Tailored action plans for companies like Accenture, Capgemini, Google Cloud, and Salesforce.</p>
                </div>

                {academyDomain === "ai" && (
                  <div className="space-y-4 animate-in fade-in duration-300">
                    <div className="bg-[#09090b] p-4.5 rounded-xl border border-white/5 space-y-2.5">
                      <h4 className="text-xs font-bold text-indigo-400 uppercase font-mono">Step 1: Core Mathematical Pre-requisites</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">Ensure absolute comfort with Matrix Multiplication, backpropagation mechanics, attention weight computations, and probability basics. MNCs consistently test core neural framework foundations.</p>
                    </div>
                    <div className="bg-[#09090b] p-4.5 rounded-xl border border-white/5 space-y-2.5">
                      <h4 className="text-xs font-bold text-indigo-400 uppercase font-mono">Step 2: LLM Fine-Tuning & Prompt Pipelines</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">Be prepared to design structured retrieval pipelines. Interviewers will ask you to explain exactly how you protect against data hallucination using chunking models, system-level context windows, and vector similarity indexes.</p>
                    </div>
                    <div className="bg-[#09090b] p-4.5 rounded-xl border border-white/5 space-y-2.5">
                      <h4 className="text-xs font-bold text-indigo-400 uppercase font-mono">Step 3: Multi-Agent Architectures & Escrow Safety</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">Practice writing streaming API calls with backoff retry scripts and handling rate limits on platforms like Gemini Flash or Claude Haiku. MNC projects require highly modular server-side execution wrappers.</p>
                    </div>
                  </div>
                )}

                {academyDomain === "webdev" && (
                  <div className="space-y-4 animate-in fade-in duration-300">
                    <div className="bg-[#09090b] p-4.5 rounded-xl border border-white/5 space-y-2.5">
                      <h4 className="text-xs font-bold text-indigo-400 uppercase font-mono">Step 1: Mastery over Next.js Server Components (RSC)</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">MNC technical rounds drill heavily on rendering boundaries. Understand how React Server Components serialize data down to client bundles, and avoid passing large functions or unindexed objects across 'use client' parameters.</p>
                    </div>
                    <div className="bg-[#09090b] p-4.5 rounded-xl border border-white/5 space-y-2.5">
                      <h4 className="text-xs font-bold text-indigo-400 uppercase font-mono">Step 2: Layout & Visual Frame Refinement</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">Practice fluid layout design with Tailwind CSS. Avoid layout shifts (CLS) by utilizing explicit image proportions, lazyloading heavy modules, and configuring clean responsive grid-bento components.</p>
                    </div>
                    <div className="bg-[#09090b] p-4.5 rounded-xl border border-white/5 space-y-2.5">
                      <h4 className="text-xs font-bold text-indigo-400 uppercase font-mono">Step 3: Server-Side State Synchronization</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">Be ready to explain cookie authentication policies, CORS parameters, and secure JWT verification layers. Keep all private credential storage safe inside backend proxy routing scripts.</p>
                    </div>
                  </div>
                )}

                {academyDomain === "crm" && (
                  <div className="space-y-4 animate-in fade-in duration-300">
                    <div className="bg-[#09090b] p-4.5 rounded-xl border border-white/5 space-y-2.5">
                      <h4 className="text-xs font-bold text-indigo-400 uppercase font-mono">Step 1: Lightning Web Components Lifecycle Hooks</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">MNC Salesforce interviewers will consistently test your constructor rules. Never call wired imperative Apex methods inside the constructor; always defer network fetches to connectedCallback() or renderedCallback() hooks.</p>
                    </div>
                    <div className="bg-[#09090b] p-4.5 rounded-xl border border-white/5 space-y-2.5">
                      <h4 className="text-xs font-bold text-indigo-400 uppercase font-mono">Step 2: Governor Limits & Bulkified Triggers</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">Never write SOQL queries inside a loop block. Ensure all Apex triggers iterate over Trigger.New collections securely to prevent governor crashes on bulk enterprise staffing uploads.</p>
                    </div>
                    <div className="bg-[#09090b] p-4.5 rounded-xl border border-white/5 space-y-2.5">
                      <h4 className="text-xs font-bold text-indigo-400 uppercase font-mono">Step 3: CPQ & Revenue Cloud Logic</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">Practice structuring multi-tier pricing bundles and custom product rule constraints. Tier 1 companies regularly hire consultants to troubleshoot enterprise licensing pipelines.</p>
                    </div>
                  </div>
                )}

                {academyDomain === "emerging" && (
                  <div className="space-y-4 animate-in fade-in duration-300">
                    <div className="bg-[#09090b] p-4.5 rounded-xl border border-white/5 space-y-2.5">
                      <h4 className="text-xs font-bold text-indigo-400 uppercase font-mono">Step 1: Immutable Smart Contract Protocols</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">Learn to write Solidity scripts utilizing strict safety libraries like OpenZeppelin. MNC Web3 projects audit extensively against reentrancy vectors and overflow math bugs.</p>
                    </div>
                    <div className="bg-[#09090b] p-4.5 rounded-xl border border-white/5 space-y-2.5">
                      <h4 className="text-xs font-bold text-indigo-400 uppercase font-mono">Step 2: Kubernetes Container Orchestration</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">Understand how to write highly available deployment configurations, define precise CPU/Memory resource constraints, and route internal networking across multiple private namespaces.</p>
                    </div>
                    <div className="bg-[#09090b] p-4.5 rounded-xl border border-white/5 space-y-2.5">
                      <h4 className="text-xs font-bold text-indigo-400 uppercase font-mono">Step 3: Infrastructure-as-Code & CI/CD Pipelines</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">Master Terraform variables and modular layouts. Automate environment testing setups to enable seamless direct dispatch to live target containers.</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Study Cheat Sheets & Mock Qs (Column 3) */}
              <div className="bg-[#09090b] rounded-xl p-5 border border-white/5 space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-200 flex items-center gap-1.5 font-display">
                    <span>📖</span>
                    Cheat Sheets & Mock Qs
                  </h3>
                  <p className="text-[11px] text-slate-500">Quick-reference cheat sheets to pass technical screening rounds easily.</p>
                </div>

                <div className="space-y-4 text-xs">
                  <div className="p-3 bg-[#141416] rounded-lg border border-white/5 space-y-2">
                    <span className="text-[9px] font-bold text-amber-400 uppercase font-mono tracking-wider">MOCK INTERVIEW QUESTION 1</span>
                    <h4 className="font-semibold text-slate-200">How do you secure server-side API keys from client leakage?</h4>
                    <p className="text-[11px] text-slate-400 leading-relaxed">"By routing all queries through private `/api/*` proxies. Avoid using client prefixes like `VITE_` for sensitive API secrets, ensuring all key matching happens securely behind Node containers."</p>
                  </div>

                  <div className="p-3 bg-[#141416] rounded-lg border border-white/5 space-y-2">
                    <span className="text-[9px] font-bold text-indigo-400 uppercase font-mono tracking-wider">MOCK INTERVIEW QUESTION 2</span>
                    <h4 className="font-semibold text-slate-200">What is bulkification in enterprise Apex scripting?</h4>
                    <p className="text-[11px] text-slate-400 leading-relaxed">"The coding pattern that ensures code structures gracefully manage large DML bulk transactions (up to 200 records) by processing lists instead of singular objects inside loop triggers."</p>
                  </div>

                  <div className="p-3 bg-[#141416] border border-indigo-500/10 rounded-lg bg-indigo-950/5 space-y-2">
                    <span className="text-[9px] font-bold text-emerald-400 uppercase font-mono tracking-wider">ACADEMY VERIFICATION BADGE</span>
                    <h4 className="font-semibold text-slate-200">Take Free Placement Exam</h4>
                    <p className="text-[11px] text-slate-400">Prove your expertise. Passing the assessment adds a premium 'AI-Vetted Expert' credential visible to hiring companies.</p>
                    <button 
                      onClick={() => alert("Placement test starting! Answer 10 domain-specific questions to unlock your direct pipeline recommendation.")}
                      className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-[10px] transition-all cursor-pointer"
                    >
                      Launch Assessment Test
                    </button>
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>
      )}
    </div>
  );
}
